package com.propertymanageruae.api;

import com.propertymanageruae.api.entities.Notice;
import com.propertymanageruae.api.repositories.INoticeRepository;
import com.propertymanageruae.api.services.logger.LoggerService;
import com.propertymanageruae.api.specificaions.NoticeSpecification;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

@SpringBootTest
public class FetchNoticeDetailsTest {
    @Autowired
    private INoticeRepository noticeRepository;
    @Autowired
    private LoggerService logger;
    @Test
    void contextLoads() {
        Specification<Notice> spec = Specification
                .where(NoticeSpecification.hasSocietyId(2))
                .and(NoticeSpecification.isNotDeleted(false))
                .and(NoticeSpecification.filterByTimeline(AppConstants.NoticeTimeline.CURRENT));
        List<Notice> notice=this.noticeRepository.findAll(spec);
        logger.logInfo(notice.toString());
    }
}