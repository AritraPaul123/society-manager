package com.propertymanageruae.api;

import com.propertymanageruae.api.repositories.IApartmentRepository;
import com.propertymanageruae.api.repositories.IAreaRepository;
import com.propertymanageruae.api.repositories.IResidentRepository;
import com.propertymanageruae.api.repositories.ISocietyRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyManagerApiApplicationTests {

	@Autowired
	private IAreaRepository areaRepository;
	@Autowired
	private ISocietyRepository societyRepository;
	@Autowired
	private IApartmentRepository apartmentRepository;
	@Autowired
	private IResidentRepository residentRepository;

	@Test
	void contextLoads() {
//		Society society=societyRepository.findById(1L).orElseThrow(()->new ResourceNotFoundException(""));
//		Area a= repository.findBySocietyAndArea(society,"Unit").orElseThrow(()->new ResourceNotFoundException(""));
//		Apartment apartment = this.apartmentRepository
//				.findByAreaAndFlat(a, "101")
//				.orElseThrow(() -> new ResourceNotFoundException("apartment not found"));
//		Optional<Area> a = repository.findBySocietyAndArea(society, "Unit");
//		a.ifPresent(area -> {
//            throw new ResourceNotFoundException("Case-sensitive area not found");
//        });
//	Society sc=this.societyRepository
//				.findBySocietyEmail("ms@gmail")
//				.orElseThrow(() -> new EmailAlreadyExitException("EmailId already registered with another society"));
//		System.out.println(apartment.getFlat());
//		System.out.println("System Time: " + new java.util.Date());
//		System.out.println("Instant.now(): " + Timestamp.from(Instant.now()));
//		System.out.println("ZonedDateTime.now(UTC): " + ZonedDateTime.now(ZoneOffset.UTC));
//		List<ResidentSocietyDetailDto> residentDetails=this.residentRepository.findApartmentResidentDetailsByOwnerEmail("monish.paul2000@gmail.com","default Society","All","All");

//		Society society = this.societyRepository
//				.findById(21L)
//				.orElseThrow(() -> new ResourceNotFoundException("society not found", "", ""));
//		Area area = this.areaRepository.findBySocietyAndArea(society, "B1")
//				.orElseThrow(() -> new ResourceNotFoundException("Area Not Found"));
//
//		Apartment apartment = this.apartmentRepository.findByAreaAndFlat(area, "1")
//				.orElseThrow(() -> new ResourceNotFoundException("Apartment Not Found for block: " ));
//		System.out.println(apartment);


//		System.out.println(this.apartmentRepository.findApartmentBySocietyId(21L));

	}

}