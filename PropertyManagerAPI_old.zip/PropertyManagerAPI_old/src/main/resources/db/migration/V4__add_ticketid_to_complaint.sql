ALTER TABLE complaint
ADD COLUMN ticket_id VARCHAR(150) NOT NULL;

ALTER TABLE complaint
ADD CONSTRAINT unique_society_ticket_id UNIQUE (society_id, ticket_id);
