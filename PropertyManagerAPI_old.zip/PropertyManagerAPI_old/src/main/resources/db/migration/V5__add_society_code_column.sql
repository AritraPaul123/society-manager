ALTER TABLE society
ADD COLUMN society_code VARCHAR(100) NULL AFTER society_id;
