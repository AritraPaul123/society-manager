-- Migration: Add Emirates ID and enhanced visitor fields
-- Version: V18
-- Description: Adds Emirates ID scanning, company name, and repeat visitor intelligence

-- Add new columns to visitors table
ALTER TABLE visitors ADD COLUMN emirates_id VARCHAR(255);
ALTER TABLE visitors ADD COLUMN company_name VARCHAR(255);
ALTER TABLE visitors ADD COLUMN is_repeat_visitor BOOLEAN DEFAULT FALSE;
ALTER TABLE visitors ADD COLUMN last_visit_date DATETIME;
ALTER TABLE visitors ADD COLUMN visit_count INT DEFAULT 1;

-- Create index for Emirates ID lookups
CREATE INDEX idx_visitors_emirates_id ON visitors(emirates_id);
CREATE INDEX idx_visitors_mobile ON visitors(mobile_number);
