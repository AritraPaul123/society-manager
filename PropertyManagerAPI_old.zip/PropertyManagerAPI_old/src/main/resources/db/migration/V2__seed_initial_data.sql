-- ======================
-- ROLES
-- ======================
INSERT INTO role (id, role, title)
SELECT 1, 'MASTER_ACCESS_USER', 'Master Access'
WHERE NOT EXISTS (SELECT 1 FROM role WHERE id = 1);

INSERT INTO role (id, role, title)
SELECT 2, 'SUPERADMIN_USER', 'Super Admin'
WHERE NOT EXISTS (SELECT 1 FROM role WHERE id = 2);

INSERT INTO role (id, role, title)
SELECT 3, 'ADMIN_USER', 'Admin'
WHERE NOT EXISTS (SELECT 1 FROM role WHERE id = 3);

INSERT INTO role (id, role, title)
SELECT 4, 'STAFF_USER', 'Staff'
WHERE NOT EXISTS (SELECT 1 FROM role WHERE id = 4);

INSERT INTO role (id, role, title)
SELECT 5, 'GROUNDSTAFF_USER', 'Ground Staff'
WHERE NOT EXISTS (SELECT 1 FROM role WHERE id = 5);

INSERT INTO role (id, role, title)
SELECT 6, 'RESIDENTIAL_USER', 'Residential'
WHERE NOT EXISTS (SELECT 1 FROM role WHERE id = 6);


-- ======================
-- ASSIGNMENT TYPES
-- ======================
INSERT INTO assignment_type (id, type)
SELECT 1, 'type1'
WHERE NOT EXISTS (SELECT 1 FROM assignment_type WHERE id = 1);

INSERT INTO assignment_type (id, type)
SELECT 2, 'type2'
WHERE NOT EXISTS (SELECT 1 FROM assignment_type WHERE id = 2);


-- ======================
-- SOCIETY (DEFAULT)
-- ======================
INSERT INTO society (
   id,
   society_name,
   society_phone,
   society_email,
   society_type,
   city,
   country,
   latitude,
   longitude,
   society_id,
   is_delete
)
SELECT
   1,
   'default Society',
   '78954556865',
   'abc@gmail.com',
   'UNPUBLISH',
   'aaa',
   'India',
   '122.22',
   '445.23',
   '1',
   0
WHERE NOT EXISTS (SELECT 1 FROM society WHERE society_id = '1');

-- ======================
-- AREA
-- ======================
INSERT INTO area (area, type, society_id)
SELECT 'All Area', 'All', 1
WHERE NOT EXISTS (SELECT 1 FROM area WHERE area = 'All Area');


-- ======================
-- APARTMENT
-- ======================
INSERT INTO apartment (block, floor, flat, area_id, society_id)
SELECT
    'All',
    'All',
    'All',
    (SELECT id FROM area WHERE area = 'All Area'),
    1
WHERE NOT EXISTS (
    SELECT 1 FROM apartment
    WHERE block = 'All' AND flat = 'All'
);