--
-- Table structure for table `property`
--

DROP TABLE IF EXISTS `property`;

CREATE TABLE `property` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `building_name` varchar(255) DEFAULT NULL,
  `dewa_no` varchar(255) DEFAULT NULL,
  `makani_no` double DEFAULT NULL,
  `no_of_bedrooms` int DEFAULT NULL,
  `plot_no` varchar(255) DEFAULT NULL,
  `property_type` enum('APARTMENT','COMMERCIAL','OTHER','RESIDENTIAL','VILLA') DEFAULT NULL,
  `unit_area` double DEFAULT NULL,
  `unit_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;