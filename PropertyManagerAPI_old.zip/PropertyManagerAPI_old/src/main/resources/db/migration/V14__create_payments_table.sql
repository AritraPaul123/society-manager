--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;

CREATE TABLE `payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `annual_rent` decimal(12,2) DEFAULT NULL,
  `broker_fee` decimal(12,2) DEFAULT NULL,
  `contract_value` int DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `ejari_number` varchar(255) DEFAULT NULL,
  `graceperiod` int DEFAULT NULL,
  `installments` int DEFAULT NULL,
  `no_of_months_period` int DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_per_year` int DEFAULT NULL,
  `remaining_balance` decimal(12,2) DEFAULT NULL,
  `rent_per_sqm` int DEFAULT NULL,
  `security_deposit` decimal(12,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `total_payment_received` decimal(12,2) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `vat_tax` decimal(12,2) DEFAULT NULL,
  `lease_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK95oa6icwd4uno16mwxrgwnw8n` (`lease_id`),
  CONSTRAINT `FK95oa6icwd4uno16mwxrgwnw8n` FOREIGN KEY (`lease_id`) REFERENCES `lease` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;