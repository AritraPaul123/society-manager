-- Migration: Enhance patrol tables for offline and photo capture
-- Version: V21
-- Description: Adds offline mode, photo capture, and pause/resume functionality to patrols

-- Add columns to patrols table
ALTER TABLE patrols ADD COLUMN route_id BIGINT;
ALTER TABLE patrols ADD COLUMN is_offline BOOLEAN DEFAULT FALSE;
ALTER TABLE patrols ADD COLUMN sync_status VARCHAR(50) DEFAULT 'SYNCED';
ALTER TABLE patrols ADD COLUMN pause_time TIMESTAMP;
ALTER TABLE patrols ADD COLUMN resume_time TIMESTAMP;
ALTER TABLE patrols ADD COLUMN paused_count INT DEFAULT 0;

-- Add foreign key for route
ALTER TABLE patrols ADD CONSTRAINT fk_patrol_route 
    FOREIGN KEY (route_id) REFERENCES patrol_routes(id);

-- Add columns to patrol_logs table
ALTER TABLE patrol_logs ADD COLUMN qr_point_id BIGINT;
ALTER TABLE patrol_logs ADD COLUMN photo_url VARCHAR(500);
ALTER TABLE patrol_logs ADD COLUMN is_photo_mandatory BOOLEAN DEFAULT TRUE;
ALTER TABLE patrol_logs ADD COLUMN latitude DECIMAL(10, 8);
ALTER TABLE patrol_logs ADD COLUMN longitude DECIMAL(11, 8);
ALTER TABLE patrol_logs ADD COLUMN sync_status VARCHAR(50) DEFAULT 'SYNCED';

-- Add foreign key for QR point
ALTER TABLE patrol_logs ADD CONSTRAINT fk_patrol_log_qr_point 
    FOREIGN KEY (qr_point_id) REFERENCES qr_points(id);

-- Create indexes
CREATE INDEX idx_patrols_route ON patrols(route_id);
CREATE INDEX idx_patrols_sync_status ON patrols(sync_status);
CREATE INDEX idx_patrol_logs_qr_point ON patrol_logs(qr_point_id);
