-- Migration: Create incidents table
-- Version: V22
-- Description: Adds incident reporting functionality linked to patrols and complaints

CREATE TABLE incidents (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patrol_id BIGINT,
    guard_id BIGINT NOT NULL,
    incident_type VARCHAR(100),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    photo_url VARCHAR(500),
    location VARCHAR(255),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    priority VARCHAR(50) DEFAULT 'MEDIUM', -- LOW, MEDIUM, HIGH, CRITICAL
    status VARCHAR(50) DEFAULT 'OPEN', -- OPEN, ASSIGNED, IN_PROGRESS, RESOLVED, CLOSED
    assigned_to BIGINT,
    complaint_id BIGINT, -- Link to complaint if created
    society_id BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    resolved_at TIMESTAMP,
    FOREIGN KEY (patrol_id) REFERENCES patrols(id),
    FOREIGN KEY (guard_id) REFERENCES users(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id),
    FOREIGN KEY (complaint_id) REFERENCES complaint(id),
    FOREIGN KEY (society_id) REFERENCES society(id)
);

-- Create indexes
CREATE INDEX idx_incidents_patrol ON incidents(patrol_id);
CREATE INDEX idx_incidents_guard ON incidents(guard_id);
CREATE INDEX idx_incidents_status ON incidents(status);
CREATE INDEX idx_incidents_society ON incidents(society_id);
CREATE INDEX idx_incidents_created_at ON incidents(created_at);
