--
-- Table structure for table `payment_installments`
--
DROP TABLE IF EXISTS `payment_installments`;

CREATE TABLE `payment_installments` (
  `installment_id` bigint NOT NULL AUTO_INCREMENT,
  `amount_paid` decimal(12,2) DEFAULT NULL,
  `deposited_bank` varchar(255) DEFAULT NULL,
  `depositor_account_number` varchar(255) DEFAULT NULL,
  `installment_amount` decimal(12,2) DEFAULT NULL,
  `scheduled_date` date DEFAULT NULL,
  `installment_no` int DEFAULT NULL,
  `issuer_account_number` varchar(255) DEFAULT NULL,
  `issuer_bank` varchar(255) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `trans_ref` varchar(255) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `payment_id` bigint DEFAULT NULL,
  PRIMARY KEY (`installment_id`),
  KEY `FKdixfgdjageuu3g5x5g3waj8ye` (`payment_id`),
  CONSTRAINT `FKdixfgdjageuu3g5x5g3waj8ye` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;