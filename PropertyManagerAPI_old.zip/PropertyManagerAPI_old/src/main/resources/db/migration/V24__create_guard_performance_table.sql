-- Migration: Create guard performance analytics table
-- Version: V24
-- Description: Adds guard performance tracking and analytics

CREATE TABLE guard_performance (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    guard_id BIGINT NOT NULL,
    date DATE NOT NULL,
    patrols_assigned INT DEFAULT 0,
    patrols_completed INT DEFAULT 0,
    patrols_missed INT DEFAULT 0,
    incidents_reported INT DEFAULT 0,
    visitors_processed INT DEFAULT 0,
    attendance_status VARCHAR(50), -- PRESENT, ABSENT, HALF_DAY, LATE
    check_in_time TIMESTAMP,
    check_out_time TIMESTAMP,
    total_duty_hours DECIMAL(5, 2),
    performance_score DECIMAL(5, 2), -- Calculated score 0-100
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    FOREIGN KEY (guard_id) REFERENCES users(id),
    UNIQUE KEY unique_guard_date (guard_id, date)
);

-- Create indexes
CREATE INDEX idx_guard_performance_guard ON guard_performance(guard_id);
CREATE INDEX idx_guard_performance_date ON guard_performance(date);
CREATE INDEX idx_guard_performance_score ON guard_performance(performance_score);
