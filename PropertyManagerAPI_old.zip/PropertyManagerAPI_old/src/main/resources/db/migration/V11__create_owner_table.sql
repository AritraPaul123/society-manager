--
-- Table structure for table `owner`
--
DROP TABLE IF EXISTS `owner`;

CREATE TABLE `owner` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lessor_authority` varchar(255) DEFAULT NULL,
  `lessor_email` varchar(255) DEFAULT NULL,
  `lessor_emirates_id` varchar(255) DEFAULT NULL,
  `lessor_mobile_no` varchar(255) DEFAULT NULL,
  `lessor_name` varchar(255) DEFAULT NULL,
  `license_no` int DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKr7ak3gd5edxe19pau26ygvibo` (`lessor_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS property_owner (
    owner_id BIGINT NOT NULL,
    property_id BIGINT NOT NULL,
    PRIMARY KEY (owner_id, property_id),
    CONSTRAINT fk_owner FOREIGN KEY (owner_id) REFERENCES owner(id) ON DELETE CASCADE,
    CONSTRAINT fk_property FOREIGN KEY (property_id) REFERENCES property(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;