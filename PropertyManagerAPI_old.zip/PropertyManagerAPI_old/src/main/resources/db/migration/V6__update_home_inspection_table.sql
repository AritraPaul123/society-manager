-- =========================================
-- V6__update_inspection_tables.sql
-- Update HomeInspection, InspectionSection, SectionImage
-- =========================================

-- 1. HomeInspection Table: add new columns
ALTER TABLE home_inspection
ADD COLUMN society_name VARCHAR(255) NOT NULL;

ALTER TABLE home_inspection
ADD COLUMN unique_id VARCHAR(255);

ALTER TABLE home_inspection
ADD COLUMN is_move_in BOOLEAN DEFAULT FALSE;

-- 2. InspectionSection Table: remove description column
ALTER TABLE inspection_section
DROP COLUMN description;

-- 3. SectionImage Table: add new columns
ALTER TABLE section_image
ADD COLUMN amount DOUBLE DEFAULT 0.0 NOT NULL;

ALTER TABLE section_image
ADD COLUMN description TEXT;
