--
-- Table structure for table `lease_terms`
--
DROP TABLE IF EXISTS `lease_terms`;

CREATE TABLE `lease_terms` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `term` text NOT NULL,
  `lease_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkmrve650tj5gjyp1cib693s2d` (`lease_id`),
  CONSTRAINT `FKkmrve650tj5gjyp1cib693s2d` FOREIGN KEY (`lease_id`) REFERENCES `lease` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;