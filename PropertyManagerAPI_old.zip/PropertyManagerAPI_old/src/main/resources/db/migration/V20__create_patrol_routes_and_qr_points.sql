-- Migration: Create patrol routes and QR points
-- Version: V20
-- Description: Adds patrol route management and QR code scanning infrastructure

-- Patrol Routes Table
CREATE TABLE patrol_routes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_name VARCHAR(255) NOT NULL,
    description TEXT,
    society_id BIGINT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    frequency VARCHAR(50), -- HOURLY, DAILY, NIGHT
    created_by BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    FOREIGN KEY (society_id) REFERENCES society(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- QR Points Table
CREATE TABLE qr_points (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    qr_code VARCHAR(255) UNIQUE NOT NULL,
    location_name VARCHAR(255) NOT NULL,
    location_description TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    society_id BIGINT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (society_id) REFERENCES society(id)
);

-- Route QR Points Mapping
CREATE TABLE route_qr_points (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    route_id BIGINT NOT NULL,
    qr_point_id BIGINT NOT NULL,
    sequence_order INT NOT NULL,
    is_mandatory BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (route_id) REFERENCES patrol_routes(id) ON DELETE CASCADE,
    FOREIGN KEY (qr_point_id) REFERENCES qr_points(id) ON DELETE CASCADE,
    UNIQUE KEY unique_route_qr (route_id, qr_point_id)
);

-- Create indexes
CREATE INDEX idx_patrol_routes_society ON patrol_routes(society_id);
CREATE INDEX idx_qr_points_society ON qr_points(society_id);
CREATE INDEX idx_qr_points_code ON qr_points(qr_code);
