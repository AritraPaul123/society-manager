-- ======================
-- DEFAULT LOCATIONS
-- ======================

INSERT INTO location (id, location)
SELECT 1, 'Lobby'
WHERE NOT EXISTS (SELECT 1 FROM location WHERE id = 1);

INSERT INTO location (id, location)
SELECT 2, 'Parking'
WHERE NOT EXISTS (SELECT 1 FROM location WHERE id = 2);

INSERT INTO location (id, location)
SELECT 3, 'Club House'
WHERE NOT EXISTS (SELECT 1 FROM location WHERE id = 3);

INSERT INTO location (id, location)
SELECT 4, 'Gym'
WHERE NOT EXISTS (SELECT 1 FROM location WHERE id = 4);

INSERT INTO location (id, location)
SELECT 5, 'Garden'
WHERE NOT EXISTS (SELECT 1 FROM location WHERE id = 5);