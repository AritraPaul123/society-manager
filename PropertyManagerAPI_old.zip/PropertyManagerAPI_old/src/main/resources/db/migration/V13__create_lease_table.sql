--
-- Table structure for table `lease`
--
DROP TABLE IF EXISTS `lease`;

CREATE TABLE `lease` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `end_date` date DEFAULT NULL,
  `lease_ref` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `status` enum('CLOSED','OPEN','STEP_1','STEP_2') DEFAULT NULL,
  `property_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKpo1n2giicwdb0mvxcm6c01o0l` (`lease_ref`),
  KEY `FKh9t7nc2o2avrsrtf60doxx593` (`property_id`),
  KEY `FKobm05vq3422sfratvn8x539l2` (`tenant_id`),
  CONSTRAINT `FKh9t7nc2o2avrsrtf60doxx593` FOREIGN KEY (`property_id`) REFERENCES `property` (`id`),
  CONSTRAINT `FKobm05vq3422sfratvn8x539l2` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;