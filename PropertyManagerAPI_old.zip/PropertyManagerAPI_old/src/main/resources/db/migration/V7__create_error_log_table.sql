CREATE TABLE error_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    error_code VARCHAR(36) NOT NULL UNIQUE,
    message VARCHAR(1000),
    stack_trace TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);