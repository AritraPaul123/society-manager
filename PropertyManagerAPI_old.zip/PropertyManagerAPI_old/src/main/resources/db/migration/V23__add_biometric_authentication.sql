-- Migration: Add biometric authentication fields
-- Version: V23
-- Description: Adds Face ID and biometric authentication support

-- Add biometric fields to users table
ALTER TABLE users ADD COLUMN face_id_enrolled BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN face_id_data TEXT; -- Encrypted biometric template/hash
ALTER TABLE users ADD COLUMN passcode VARCHAR(255); -- Encrypted passcode for guards
ALTER TABLE users ADD COLUMN biometric_required BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN last_biometric_update TIMESTAMP;

-- Create index for biometric lookups
CREATE INDEX idx_users_face_id_enrolled ON users(face_id_enrolled);
