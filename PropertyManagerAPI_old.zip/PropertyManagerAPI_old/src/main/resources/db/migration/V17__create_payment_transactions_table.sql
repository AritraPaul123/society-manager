
--
-- Table structure for table `payment_transactions`
--
DROP TABLE IF EXISTS `payment_transactions`;

CREATE TABLE `payment_transactions` (
  `transaction_id` bigint NOT NULL AUTO_INCREMENT,
  `amount_paid` decimal(12,2) DEFAULT NULL,
  `deposited_bank` varchar(255) DEFAULT NULL,
  `depositor_account_number` varchar(255) DEFAULT NULL,
  `issuer_account_number` varchar(255) DEFAULT NULL,
  `issuer_bank` varchar(255) DEFAULT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `trans_ref` varchar(255) DEFAULT NULL,
  `transaction_date` datetime(6) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `installment_id` bigint DEFAULT NULL,
  `payment_id` bigint DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `FK75nuf8gfe2bmjwk3l7lx81vhu` (`installment_id`),
  KEY `FKgu8q4u0cjr8aljtknj557g2i8` (`payment_id`),
  CONSTRAINT `FK75nuf8gfe2bmjwk3l7lx81vhu` FOREIGN KEY (`installment_id`) REFERENCES `payment_installments` (`installment_id`),
  CONSTRAINT `FKgu8q4u0cjr8aljtknj557g2i8` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;