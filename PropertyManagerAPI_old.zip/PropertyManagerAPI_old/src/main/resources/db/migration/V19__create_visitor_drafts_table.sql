-- Migration: Create visitor drafts table
-- Version: V19
-- Description: Adds draft system for interrupted visitor entries

CREATE TABLE visitor_drafts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    guard_id BIGINT NOT NULL,
    name VARCHAR(255),
    emirates_id VARCHAR(255),
    mobile_number VARCHAR(255),
    company_name VARCHAR(255),
    visit_purpose VARCHAR(255),
    apartment_id BIGINT,
    photo_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    FOREIGN KEY (guard_id) REFERENCES users(id),
    FOREIGN KEY (apartment_id) REFERENCES apartment(id)
);

-- Create index for guard lookups
CREATE INDEX idx_visitor_drafts_guard ON visitor_drafts(guard_id);
CREATE INDEX idx_visitor_drafts_expires ON visitor_drafts(expires_at);
