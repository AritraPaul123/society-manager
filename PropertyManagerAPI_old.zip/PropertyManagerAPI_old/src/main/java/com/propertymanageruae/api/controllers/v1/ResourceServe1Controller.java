package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.helper.UnitHelper;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.thymeleaf.TemplateEngine;

import java.io.IOException;
import java.io.InputStream;

@RestController
@RequestMapping("/api/v${api.version}")
@Tag(name = "ResourceServe")
public class ResourceServe1Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Autowired
    private UnitService _unitService;
    @Autowired
    private UnitHelper _unitHelper;
    @Autowired
    private TemplateEngine templateEngine;

    @GetMapping(value = "/image/{imageName}", produces = MediaType.IMAGE_JPEG_VALUE)
    public void downloadImage(@PathVariable("imageName") String imageName, HttpServletResponse httpServletResponse) throws IOException {
        InputStream resource = this._unitHelper.s3FileHandler.getResource(imageName);
        httpServletResponse.setContentType(MediaType.IMAGE_JPEG_VALUE);
        StreamUtils.copy(resource, httpServletResponse.getOutputStream());
    }

    @GetMapping(value = "/pdf/{pdfName}", produces = MediaType.APPLICATION_PDF_VALUE)
    public void downloadPdf(@PathVariable("pdfName") String pdfName, HttpServletResponse response) throws IOException {
        InputStream resource = this._unitHelper.s3FileHandler.getResource(pdfName);
        response.setContentType(MediaType.APPLICATION_PDF_VALUE);
        response.setHeader("Content-Disposition", "inline; filename=\"" + pdfName + "\"");
        StreamUtils.copy(resource, response.getOutputStream());
        response.flushBuffer();
    }
}