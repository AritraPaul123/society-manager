package com.propertymanageruae.api.services.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class RealTimeNotificationService {

    private static final Logger logger = LoggerFactory.getLogger(RealTimeNotificationService.class);

    private final SimpMessagingTemplate messagingTemplate;

    public RealTimeNotificationService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    /**
     * Sends to a user's queue: /user/{principal}/queue/notifications
     * Principal.getName() must be the same as the string we pass here (we'll use userId as string).
     */
    public void sendToUser(String userPrincipalName, Object notification) {
        try {
            messagingTemplate.convertAndSendToUser(userPrincipalName, "/queue/notifications", notification);
            logger.info("Sent real-time notification to user principal {}", userPrincipalName);
        } catch (Exception e) {
            logger.error("Failed to send real-time notification: {}", e.getMessage(), e);
        }
    }

    public void broadcast(Object notification) {
        messagingTemplate.convertAndSend("/topic/broadcast", notification);
    }
}