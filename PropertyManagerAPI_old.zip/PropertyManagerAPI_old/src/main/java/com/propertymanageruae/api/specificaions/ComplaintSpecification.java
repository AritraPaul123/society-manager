package com.propertymanageruae.api.specificaions;


import com.propertymanageruae.api.entities.Complaint;
import com.propertymanageruae.api.payloads.complaint.ComplaintFilterDto;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ComplaintSpecification {

    public static Specification<Complaint> withFilters(ComplaintFilterDto filter) {
        return (root, query, builder) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (filter.getStatus() != null) {
                predicates.add(builder.equal(root.get("ticketStatus"), filter.getStatus()));
            }
            if (filter.getCategoryId() != null) {
                predicates.add(builder.equal(root.get("category").get("id"), filter.getCategoryId()));
            }
            if (filter.getPriority() != null) {
                predicates.add(builder.equal(builder.lower(root.get("priority")), filter.getPriority().toLowerCase()));
            }
            if (filter.getComplaintVisibility() != null) {
                predicates.add(builder.equal(builder.lower(root.get("complaintVisibility")), filter.getComplaintVisibility().toLowerCase()));
            }
            if (filter.getAssigneeId() != null) {
                predicates.add(builder.equal(root.get("assignedUser").get("id"), filter.getAssigneeId()));
            }
            if (filter.getLocationId() != null) {
                predicates.add(builder.equal(root.get("location").get("id"), filter.getLocationId()));
            }
            if (filter.getTicketNo() != null) {
                predicates.add(builder.equal(root.get("id"), filter.getTicketNo()));
            }
            if (filter.getAreaId() != null) {
                predicates.add(builder.equal(root.get("areaId"), filter.getAreaId()));
            }
            if (filter.getApartmentId() != null) {
                predicates.add(builder.equal(root.get("apartmentId"), filter.getApartmentId()));
            }
            if (filter.getDays() != null) {
                LocalDateTime today = LocalDateTime.now();
                LocalDateTime startDate = today.minusDays(filter.getDays());
                predicates.add(builder.greaterThanOrEqualTo(root.get("createdAt"), startDate));
            }
            if (filter.getStartDate() != null && filter.getEndDate() != null) {
                predicates.add(builder.greaterThanOrEqualTo(
                        builder.function("DATE", LocalDate.class, root.get("createdAt")), filter.getStartDate()));

                predicates.add(builder.lessThanOrEqualTo(
                        builder.function("DATE", LocalDate.class, root.get("createdAt")), filter.getEndDate()));
            }
            if (filter.getSearchText() != null && !filter.getSearchText().isEmpty()) {
                Predicate locationPredicate = builder.like(
                        builder.lower(root.join("complainer").get("name")),
                        "%" + filter.getSearchText().toLowerCase() + "%"
                );
                Predicate idPredicate = builder.like(
                        builder.toString(root.get("ticketId")),
                        "%" + filter.getSearchText() + "%"
                );
                predicates.add(builder.or(locationPredicate, idPredicate));
            }
            return builder.and(predicates.toArray(new Predicate[0]));
        };
    }

    public static Specification<Complaint> lastTicketNumber(Long societyId) {
        return (root, query, builder) -> {

            // SELECT MAX( CAST(SUBSTRING(ticket_id, LOCATE('-', ticket_id) + 1) AS UNSIGNED) )
            var substringFn = builder.function(
                    "SUBSTRING",
                    String.class,
                    root.get("ticketId"),
                    builder.sum(
                            builder.function("LOCATE", Integer.class,
                                    builder.literal("-"),
                                    root.get("ticketId")
                            ),
                            builder.literal(1)
                    )
            );

            var castFn = builder.function(
                    "CAST",
                    Integer.class,
                    builder.concat(substringFn, builder.literal(" AS UNSIGNED"))
            );

            query.multiselect(builder.max(castFn));
            return builder.equal(root.get("society").get("id"), societyId);
        };
    }
}