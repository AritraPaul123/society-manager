package com.propertymanageruae.api.payloads.complaint;

import jakarta.validation.constraints.Pattern;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ComplaintFilterDto {
    @Pattern(regexp = "^(ALL|OPEN|CLOSED|RESOLVED|IN_PROGESS|ON_HOLD|AUTO_CLOSED|ACCEPTED|REJECTED|CANCELLED)$", message = "Invalid status value")
    private String status;
    private Long categoryId;
    private String priority;
    private String complaintVisibility;
    private Long assigneeId;
    private Long locationId;
    private Long areaId;
    private Long apartmentId;
    private String searchText;
    private Long ticketNo;
    private LocalDate startDate; // Start date for custom range
    private LocalDate endDate;   // End date for custom range
    private Integer days;         // Number of days for last X days filter
    private long societyId;
}