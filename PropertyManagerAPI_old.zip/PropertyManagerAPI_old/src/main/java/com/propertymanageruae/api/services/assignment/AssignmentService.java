package com.propertymanageruae.api.services.assignment;

import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.assignment.AssignmentRuleDTO;
import com.propertymanageruae.api.payloads.assignment.AssignmentSlotDTO;
import com.propertymanageruae.api.payloads.assignment.AssignmentTypeDTO;
import com.propertymanageruae.api.repositories.*;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AssignmentService implements IAssignmentService {
    private static final Logger logger = LoggerFactory.getLogger(AssignmentService.class);
    private final IAssignmentRuleRepository assignmentRuleRepository;
    private final IAssignmentTypeRepository assignmentTypeRepository;
    private final ICategoryRepository categoryRepository;
    private final ISubCategoryRepository subCategoryRepository;
    private final IUserRepository userRepository;
    private final ModelMapper modelMapper;

    public AssignmentService
            (IAssignmentRuleRepository assignmentRuleRepository,
             IAssignmentTypeRepository assignmentTypeRepository,
             ICategoryRepository categoryRepository,
             ISubCategoryRepository subCategoryRepository,
             IUserRepository userRepository,
             ModelMapper modelMapper)
    {
        this.assignmentRuleRepository = assignmentRuleRepository;
        this.assignmentTypeRepository = assignmentTypeRepository;
        this.categoryRepository = categoryRepository;
        this.subCategoryRepository = subCategoryRepository;
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public List<AssignmentRuleDTO> getAllAssignmentRules() {
        return assignmentRuleRepository.findAllWithSlots().stream()
                .map(assignmentRule -> {
                    List<AssignmentSlotDTO> assignmentSlotDTOs = assignmentRule.getAssignmentSlots().stream()
                            .map(slot -> {
                                AssignmentTypeDTO assignmentTypeDTO = modelMapper.map(slot.getAssignmentType(), AssignmentTypeDTO.class);
                                AssignmentSlotDTO slotDTO = modelMapper.map(slot, AssignmentSlotDTO.class);
                                slotDTO.setAssignmentType(assignmentTypeDTO);
                                return slotDTO;
                            })
                            .collect(Collectors.toList());

                    AssignmentRuleDTO assignmentRuleDTO = modelMapper.map(assignmentRule, AssignmentRuleDTO.class);
                    assignmentRuleDTO.setAssignmentSlots(assignmentSlotDTOs);
                    return assignmentRuleDTO;
                })
                .collect(Collectors.toList());
    }

    // Get assignment rule by ID
    @Override
    public AssignmentRuleDTO getAssignmentRuleById(long id) {
        try {
            AssignmentRule assignmentRule = assignmentRuleRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("AssignmentRule not found with ID: ", "", ""));
            return modelMapper.map(assignmentRule, AssignmentRuleDTO.class);
        } catch (Exception ex) {
            throw ex;
        }
    }

    // Add new assignment rule
    @Transactional
    @Override
    public AssignmentRuleDTO addAssignmentRule(AssignmentRuleDTO assignmentRuleDTO) {
        try {
            // Fetch existing Category, SubCategory, User
            Category category = categoryRepository.findById(assignmentRuleDTO.getCategory().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category not found with ID: ", "", ""));
            SubCategory subCategory = subCategoryRepository.findById(assignmentRuleDTO.getSubCategory().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("SubCategory not found with ID: ", "", ""));
            User user = userRepository.findById((long) assignmentRuleDTO.getUser().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: ", "", ""));

            // Map DTO to AssignmentRule entity and set relationships
            AssignmentRule assignmentRule = modelMapper.map(assignmentRuleDTO, AssignmentRule.class);
            assignmentRule.setCategory(category);
            assignmentRule.setSubCategory(subCategory);
            assignmentRule.setUser(user);

            // Handle AssignmentSlots and set their relationship with AssignmentRule
            List<AssignmentSlot> assignmentSlots = assignmentRuleDTO.getAssignmentSlots().stream().map(slotDTO -> {
                AssignmentSlot slot = modelMapper.map(slotDTO, AssignmentSlot.class);
                AssignmentType assignmentType = assignmentTypeRepository.findById(slotDTO.getAssignmentType().getId())
                        .orElseThrow(() -> new ResourceNotFoundException("AssignmentType not found with ID: ", "", ""));
                slot.setAssignmentType(assignmentType);
                slot.setAssignmentRule(assignmentRule); // Set reverse relationship
                return slot;
            }).collect(Collectors.toList());

            assignmentRule.setAssignmentSlots(assignmentSlots);

            // Save the AssignmentRule
            AssignmentRule savedRule = assignmentRuleRepository.save(assignmentRule);
            return modelMapper.map(savedRule, AssignmentRuleDTO.class);
        } catch (Exception ex) {
            throw ex;
        }
    }

    // Update assignment rule
    @Transactional
    @Override
    public AssignmentRuleDTO updateAssignmentRule(long id, AssignmentRuleDTO assignmentRuleDTO) {
        try {
            // Fetch existing AssignmentRule
            AssignmentRule existingRule = assignmentRuleRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("AssignmentRule not found with ID: ", "", ""));

            // Fetch and update Category, SubCategory, User
            Category category = categoryRepository.findById(assignmentRuleDTO.getCategory().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category not found with ID: ", "", ""));
            SubCategory subCategory = subCategoryRepository.findById(assignmentRuleDTO.getSubCategory().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("SubCategory not found with ID: ", "", ""));
            User user = userRepository.findById((long) assignmentRuleDTO.getUser().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: ", "", ""));

            existingRule.setCategory(category);
            existingRule.setSubCategory(subCategory);
            existingRule.setUser(user);

            // Clear and update AssignmentSlots
            existingRule.getAssignmentSlots().clear();
            assignmentRuleDTO.getAssignmentSlots().forEach(slotDTO -> {
                AssignmentSlot slot = modelMapper.map(slotDTO, AssignmentSlot.class);
                AssignmentType assignmentType = assignmentTypeRepository.findById(slotDTO.getAssignmentType().getId())
                        .orElseThrow(() -> new ResourceNotFoundException("AssignmentType not found with ID: ", "", ""));
                slot.setAssignmentType(assignmentType);
                slot.setAssignmentRule(existingRule);
                existingRule.getAssignmentSlots().add(slot);
            });

            // Save updated AssignmentRule
            AssignmentRule updatedRule = assignmentRuleRepository.save(existingRule);
            return modelMapper.map(updatedRule, AssignmentRuleDTO.class);
        } catch (Exception ex) {
            throw ex;
        }
    }

    // Delete assignment rule
    @Transactional
    @Override
    public boolean deleteAssignmentRule(long id) {
        try {
            AssignmentRule assignmentRule = assignmentRuleRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("AssignmentRule not found with ID: ", "", ""));

            // Delete AssignmentRule and its related AssignmentSlots
            assignmentRuleRepository.delete(assignmentRule);
            return true;
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    public boolean addAssignmentSlots(long ruleId, List<AssignmentSlotDTO> slots) {
        return false;
    }

    @Override
    public boolean deleteAssignmentSlots(long ruleId) {
        return false;
    }

    // Get only active users for dropdown
    public List<User> getActiveUsers() {
        try {
            return userRepository.findAllByStatus(true);
        } catch (Exception ex) {
            throw ex;
        }
    }
}