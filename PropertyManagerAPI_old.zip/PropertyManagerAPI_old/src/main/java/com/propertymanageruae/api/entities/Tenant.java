package com.propertymanageruae.api.entities;

// import java.util.HashSet;
// import java.util.Set;
import java.util.List;
// import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Tenant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String mobileNo;
    private String tenantEmiratesId;
    // private String passportnumber;
    // private String lessor_name;
    // private String lessor_email;
    // private String lessor_phonenumber;
    // private String lessor_emiratesId;
    private String licenseAuthority;
    private String licenseNo;
    // private String address;
    // private String city;
    // private String country;

   @OneToMany(mappedBy = "tenant", cascade = CascadeType.ALL, orphanRemoval = true)
   private List<Lease> leases;

}
