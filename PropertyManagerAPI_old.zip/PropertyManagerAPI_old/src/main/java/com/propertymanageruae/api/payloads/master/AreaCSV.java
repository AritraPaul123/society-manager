package com.propertymanageruae.api.payloads.master;

import com.opencsv.bean.CsvBindByName;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AreaCSV {
    @CsvBindByName(column = "Area")
    private String Area;
    @CsvBindByName(column = "Type")
    private String Type;
    @CsvBindByName(column = "Cluster")
    private String Cluster;
}