package com.propertymanageruae.api.services.menu;


import com.propertymanageruae.api.entities.Menu;
import com.propertymanageruae.api.payloads.menu.EditMenuDto;

import java.util.List;

public interface IMenuService {
    List<Menu> getMenus();

    List<Menu> addParentMenu(EditMenuDto menuDto);

    List<Menu> addChildMenu(Long parentId, EditMenuDto menuDto);

    List<Menu> updateMenu(Long menuId, EditMenuDto menuDto);

    List<Menu> deleteMenu(Long menuId);

    List<Menu> moveMenuOrderUp(Long menuId);

    List<Menu> moveMenuOrderDown(Long menuId);
}