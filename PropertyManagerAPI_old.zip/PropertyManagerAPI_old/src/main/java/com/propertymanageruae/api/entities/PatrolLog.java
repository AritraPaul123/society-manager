package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Table(name = "patrol_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PatrolLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patrol_id", nullable = false)
    private Patrol patrol;

    @Column(name = "checkpoint_name")
    private String checkpointName;

    @Column(name = "scanned_time", nullable = false)
    private LocalDateTime scannedTime;
    
    @Column(name = "comments")
    private String comments;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "qr_point_id")
    private QRPoint qrPoint;

    @Column(name = "photo_url", length = 500)
    private String photoUrl;

    @Column(name = "is_photo_mandatory")
    private Boolean isPhotoMandatory = true;

    @Column(name = "latitude", precision = 10, scale = 8)
    private java.math.BigDecimal latitude;

    @Column(name = "longitude", precision = 11, scale = 8)
    private java.math.BigDecimal longitude;

    @Column(name = "sync_status")
    private String syncStatus = "SYNCED"; // SYNCED, PENDING

    @PrePersist
    protected void onCreate() {
        if(scannedTime == null) scannedTime = LocalDateTime.now();
    }
}
