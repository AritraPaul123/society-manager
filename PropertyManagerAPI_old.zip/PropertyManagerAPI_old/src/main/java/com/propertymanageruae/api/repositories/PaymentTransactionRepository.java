package com.propertymanageruae.api.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.propertymanageruae.api.entities.PaymentTransaction;

public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, Long> {

    // Find all transactions under ONE INSTALLMENT
    List<PaymentTransaction> findByInstallment_InstallmentId(Long installmentId);

    // Find all transactions under a PAYMENT (via installments)
    List<PaymentTransaction> findByInstallment_Payment_Id(Long paymentId);

    // Direct transactions attached to a payment (manual or otherwise)
    List<PaymentTransaction> findByPayment_Id(Long paymentId);
}


