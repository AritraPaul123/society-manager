package com.propertymanageruae.api.exceptions;

public class GeneralException extends RuntimeException{
    public GeneralException(String msg){
        super(msg);
    }
    public GeneralException(String msg,Throwable ex){
        super(msg,ex);
    }
}