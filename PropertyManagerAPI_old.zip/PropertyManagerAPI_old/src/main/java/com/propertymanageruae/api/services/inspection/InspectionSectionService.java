package com.propertymanageruae.api.services.inspection;

import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.entities.HomeInspection;
import com.propertymanageruae.api.entities.InspectionSection;
import com.propertymanageruae.api.payloads.inspection.InspectionSectionDTO;
import com.propertymanageruae.api.payloads.inspection.ViewInspectionSectionDTO;
import com.propertymanageruae.api.payloads.inspection.ViewSectionImageDTO;
import com.propertymanageruae.api.repositories.IHomeInspectionRepository;
import com.propertymanageruae.api.repositories.IInspectionSectionRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

@Service
public class InspectionSectionService implements IInspectionSectionService {

    private static final Logger logger = LoggerFactory.getLogger(InspectionSectionService.class);

    @Autowired
    private IInspectionSectionRepository iInspectionSection;
    @Autowired
    private IHomeInspectionRepository homeInspectionRepository;
    @Autowired
    private ModelMapper modelMapper;


    @Override
    public String createSection(InspectionSectionDTO sectionDTO) throws SQLIntegrityConstraintViolationException {
        try {
            HomeInspection homeIns = HomeInspection.builder()
                    .id(sectionDTO.getInspectionId())
                    .build();
            InspectionSection model = modelMapper.map(sectionDTO,InspectionSection.class);
            model.setTitle(sectionDTO.getTitle());
            model.setHomeInspection(homeIns);
            InspectionSection saved = iInspectionSection.save(model);

            if (saved.getId() != 0) {
                return null;
            }else{
                return AppConstants.Message.NOT_SAVED;
            }

        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while adding inspection");
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    public List<ViewInspectionSectionDTO> getSectionsByInspectionId(long inspectionId) {
        HomeInspection inspection = homeInspectionRepository.findById(inspectionId)
                .orElseThrow(() -> new RuntimeException("Inspection not found with id: " + inspectionId));
        // Map ONLY sections
        return inspection.getInspectionSections()
                .stream()
                .map(section -> {
                    ViewInspectionSectionDTO sectionDTO = modelMapper.map(section, ViewInspectionSectionDTO.class);

                    // Map images inside section
                    List<ViewSectionImageDTO> imageDTOs = section.getSectionImages()
                            .stream()
                            .map(image -> modelMapper.map(image, ViewSectionImageDTO.class))
                            .toList();
                    sectionDTO.setImages(imageDTOs);
                    return sectionDTO;
                })
                .toList();
    }




}