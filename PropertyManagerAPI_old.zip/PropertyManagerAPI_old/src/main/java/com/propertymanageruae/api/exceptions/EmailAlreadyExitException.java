package com.propertymanageruae.api.exceptions;

public class EmailAlreadyExitException extends RuntimeException{
    public EmailAlreadyExitException(String msg){
        super(msg);
    }
}