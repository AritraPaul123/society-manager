package com.propertymanageruae.api.Filter;


import com.propertymanageruae.api.services.security.SecurityService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
public class TokenDecryptFilter extends OncePerRequestFilter {

    @Autowired
    private SecurityService securityService;

    private static final List<String> SKIP_PATHS = List.of(
            "/swagger", "/docs", "/favicon", ".css", ".js", ".html", ".png", ".ico"
    );

    private boolean shouldSkip(String path) {
        return SKIP_PATHS.stream().anyMatch(path::contains);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

//        String path = request.getRequestURI();
//
//        if (shouldSkip(path)) {
//            filterChain.doFilter(request, response);
//            return;
//        }
//
//        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
//        if (authHeader == null || authHeader.isBlank()) {
//            filterChain.doFilter(request, response);
//            return;
//        }
//
//        if (authHeader.toLowerCase().startsWith("basic ")) {
//            filterChain.doFilter(request, response);
//            return;
//        }
//
//        if (!authHeader.toLowerCase().startsWith("bearer ")) {
//            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//            response.getWriter().write("Unsupported authorization scheme.");
//            return;
//        }
//
//        String encryptedToken = authHeader.substring(7).trim();
//        String decryptedJwt = securityService.decryptText(encryptedToken);
//
//        if (decryptedJwt == null || decryptedJwt.isEmpty()) {
//            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//            response.getWriter().write("Invalid credentials.");
//            return;
//        }
//
//        // Replace Authorization header with decrypted JWT
//        request = new HttpServletRequestWrapper(request) {
//            @Override
//            public String getHeader(String name) {
//                if (HttpHeaders.AUTHORIZATION.equalsIgnoreCase(name)) {
//                    return "Bearer " + decryptedJwt;
//                }
//                return super.getHeader(name);
//            }
//        };

        filterChain.doFilter(request, response);
    }
}