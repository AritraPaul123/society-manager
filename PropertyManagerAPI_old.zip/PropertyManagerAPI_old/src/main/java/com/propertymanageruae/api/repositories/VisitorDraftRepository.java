package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.VisitorDraft;
import com.propertymanageruae.api.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface VisitorDraftRepository extends JpaRepository<VisitorDraft, Long> {
    List<VisitorDraft> findByGuard(User guard);
    List<VisitorDraft> findByExpiresAtBefore(LocalDateTime now);
    void deleteByExpiresAtBefore(LocalDateTime now);
}
