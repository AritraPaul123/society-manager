package com.propertymanageruae.api.payloads.master;

import com.opencsv.bean.CsvBindByName;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApartmentCSV {

    @CsvBindByName(column = "Block")
    private String Block;

    @CsvBindByName(column = "Floor")
    private String Floor;

    @CsvBindByName(column = "Flat")
    private String Flat;

    @CsvBindByName(column = "Intercom")
    private String Intercom;

}