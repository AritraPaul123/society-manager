package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.payloads.assignment.AssignmentRuleDTO;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v${api.version}/assignment-rules")
@SecurityRequirement(name = "auth")
@Tag(name = "Assignment")
public class AssignmentRule1Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Autowired
    private UnitService _unitService;

    // Fetch all assignment rules
    @GetMapping
    public ResponseEntity<ApiResponse<List<AssignmentRuleDTO>>> getAssignmentRules() {
        try {
            List<AssignmentRuleDTO> assignmentRuleDTOs = this._unitService.assignmentService.getAllAssignmentRules();
            String message = assignmentRuleDTOs.isEmpty() ? "No Data Found" : "Data fetched successfully";
            return ResponseEntity.ok(ApiResponse.success(assignmentRuleDTOs, message,null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Database error: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    // Fetch assignment rule by ID
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<AssignmentRuleDTO>> getAssignmentRule(@PathVariable("id") long id) {
        try {
            AssignmentRuleDTO assignmentRuleDTO = this._unitService.assignmentService.getAssignmentRuleById(id);
            return ResponseEntity.ok(ApiResponse.success(assignmentRuleDTO, "Assignment Rule fetched successfully",null, HttpStatus.OK.value()));
        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Assignment Rule not found: " + ex.getMessage(), HttpStatus.NOT_FOUND.value()));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Database error: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    // Add new assignment rule
    @PostMapping("/add")
    public ResponseEntity<ApiResponse<AssignmentRuleDTO>> addAssignmentRule(@Valid @RequestBody AssignmentRuleDTO assignmentRuleDTO) {
        try {
            AssignmentRuleDTO addedAssignmentRuleDTO = this._unitService.assignmentService.addAssignmentRule(assignmentRuleDTO);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(addedAssignmentRuleDTO, "Assignment Rule added successfully",null, HttpStatus.CREATED.value()));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Database error: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    // Update assignment rule by ID
    @PutMapping("/edit/{id}")
    public ResponseEntity<ApiResponse<AssignmentRuleDTO>> editAssignmentRule(@Valid @RequestBody AssignmentRuleDTO assignmentRuleDTO, @PathVariable("id") long id) {
        try {
            AssignmentRuleDTO updatedAssignmentRuleDTO = this._unitService.assignmentService.updateAssignmentRule(id, assignmentRuleDTO);
            return ResponseEntity.ok(ApiResponse.success(updatedAssignmentRuleDTO, "Assignment Rule updated successfully",null, HttpStatus.OK.value()));
        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Assignment Rule not found: " + ex.getMessage(), HttpStatus.NOT_FOUND.value()));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Database error: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    // Delete assignment rule by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteAssignmentRule(@PathVariable("id") long id) {
        try {
            boolean isDeleted =this._unitService.assignmentService.deleteAssignmentRule(id);
            if (isDeleted) {
                return ResponseEntity.ok(ApiResponse.success(null, "Successfully deleted",null, HttpStatus.OK.value()));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(ApiResponse.error("Assignment Rule deletion failed", HttpStatus.BAD_REQUEST.value()));
            }
        } catch (ResourceNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("Assignment Rule not found: " + ex.getMessage(), HttpStatus.NOT_FOUND.value()));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Database error: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }
}