package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.CommentImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ICommentImageRepository  extends JpaRepository<CommentImage, Long> {
}