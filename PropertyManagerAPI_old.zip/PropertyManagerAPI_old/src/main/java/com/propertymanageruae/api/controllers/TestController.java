package com.propertymanageruae.api.controllers;

public class TestController {
//    @RestController
//    @RequestMapping("/files")
//    public class FileController {
//        @GetMapping("/{fileName}")
//        public ResponseEntity<Resource> downloadFile(@PathVariable String fileName) {
//            try {
//                Path filePath = fileHandler.getFilePath(fileName);
//                Resource resource = new UrlResource(filePath.toUri());
//                return ResponseEntity.ok()
//                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
//                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
//                        .body(resource);
//            } catch (IOException e) {
//                throw new RuntimeException("File not found: " + fileName, e);
///}
//}
//    }
//@GetMapping("/all-users")
//@PreAuthorize("hasRole('ADMIN') or hasRole('SUPERADMIN')")
//public ResponseEntity<?> getAllUsers() {
//    return ResponseEntity.ok(userService.getAllUsers());
//}

//    @PostMapping("/create")
//    @PreAuthorize("hasRole('MASTER_ACCESS_USER')")
//    public ResponseEntity<?> createSomething() {
//        // only master access users allowed
//    }

}