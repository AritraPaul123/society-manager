package com.propertymanageruae.api.services.ExternalService;

import java.io.IOException;

public interface IGmailTokenService {
    String getAccessToken() throws IOException;
}