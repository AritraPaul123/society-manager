package com.propertymanageruae.api.helper;

import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Random;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

@Component
public class AppHelper {
    public static String generateUniqueId() {
        String randomString = generateRandomString(9); // Adjust the length as needed
        long currentTimeMillis = System.currentTimeMillis();
        return randomString + "_" + currentTimeMillis;
    }

    private static String generateRandomString(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder randomString = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            randomString.append(characters.charAt(random.nextInt(characters.length())));
        }
        return randomString.toString();
    }


    public static byte[] compressHtml(String htmlContent) {
        if (htmlContent == null || htmlContent.isEmpty()) {
            return null;
        }
        try (ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
             GZIPOutputStream gzipStream = new GZIPOutputStream(byteStream)) {
            gzipStream.write(htmlContent.getBytes(StandardCharsets.UTF_8));
            gzipStream.finish();
            return byteStream.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    public static String decompressHtml(byte[] compressedHtml) {
        if (compressedHtml == null || compressedHtml.length == 0) {
            return "";
        }
        try (ByteArrayInputStream byteStream = new ByteArrayInputStream(compressedHtml);
             GZIPInputStream gzipStream = new GZIPInputStream(byteStream);
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = gzipStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            return outputStream.toString(StandardCharsets.UTF_8); // Ensure correct encoding
        } catch (Exception e) {
            throw new RuntimeException("Error decompressing HTML", e); // Better error handling
        }
    }

    public static LocalDateTime convertToUserZone(Instant utcInstant, String userZoneId) {
        if (utcInstant == null) return null;
        try {
            return utcInstant.atZone(ZoneId.of(userZoneId)).toLocalDateTime();
        } catch (Exception e) {
            return utcInstant.atZone(ZoneId.of("UTC")).toLocalDateTime();
        }
    }


}