package com.propertymanageruae.api.services.member;

import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.exceptions.AuthException;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.AppHelper;
import com.propertymanageruae.api.helper.S3FileHandler;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.location.LocationDTO;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.member.AddMemberDto;
import com.propertymanageruae.api.payloads.member.MemberRevokeDto;
import com.propertymanageruae.api.payloads.member.UpdateMemberDto;
import com.propertymanageruae.api.payloads.member.ViewMemberDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import com.propertymanageruae.api.payloads.utils.SocietyRoleDto;
import com.propertymanageruae.api.repositories.*;
import com.propertymanageruae.api.services.user.ICustomUserDetailService;
import com.propertymanageruae.api.specificaions.MemberSpecification;
import com.propertymanageruae.api.specificaions.ResidentSpecification;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MemberService implements IMemberService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private ILocationRepository locationRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private IRoleRepository roleRepository;
    @Autowired
    private ISocietyRepository societyRepository;
    @Autowired
    private ICustomUserDetailService customUserDetailService;
    @Autowired
    private IAreaRepository areaRepository;
    @Autowired
    private IApartmentRepository apartmentRepository;
    @Autowired
    private IResidentRepository residentRepository;

    @Autowired
    private S3FileHandler s3Service;

    @Autowired
    private IUserRoleMappingRepository _userRoleMappingRepository;

    @Override
    @Transactional
    public String addMember(AddMemberDto memberDto) throws SQLIntegrityConstraintViolationException {
        try {
            Society society = this.societyRepository
                    .findById(memberDto.getSocietyId())
                    .orElseThrow(() -> new ResourceNotFoundException("Society Not Found"));
            Optional<Resident> resi = this.residentRepository.findByOwnerEmailAndSocietyIdAndIsDelete(memberDto.getEmail(), society.getId(), false);
            if (resi.isPresent()) {
                throw new AuthException("You have aleady accessed on " + society.getSocietyName());
            }
            String memberId = AppHelper.generateUniqueId();
            Role role = null;
            Optional<User> existingUser = this.userRepository.findByEmail(memberDto.getEmail());
            role = this.roleRepository.findById(memberDto.getRoleId())
                    .orElseThrow(() -> new ResourceNotFoundException("Role not exists"));
            User user = null;
            if (!existingUser.isPresent()) {
                user = this.modelMapper.map(memberDto, User.class);
                user.setEmail(memberDto.getEmail());
//            user.setSociety(society);
                user.setPassword(passwordEncoder.encode(memberDto.getPassword()));
//            user.getRoles().add(role);
                user.setMemberId(memberId);
                user.setStatus(true);
                this.userRepository.save(user);

                // ✅ Create UserRoleMapping instead of adding to user.getRoles()
                boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, role, society);
                if (!roleExists) {
                    UserRoleMapping mapping = UserRoleMapping.builder()
                            .user(user)
                            .role(role)
                            .society(society)
                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                            .build();
                    this._userRoleMappingRepository.save(mapping);
                }

            } else {
                User exitsUser = existingUser.get();
//            exitsUser.getRoles().add(role);
                this.userRepository.save(exitsUser);
                // ✅ Create UserRoleMapping instead of adding to user.getRoles()
                boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(exitsUser, role, society);
                if (!roleExists) {
                    UserRoleMapping mapping = UserRoleMapping.builder()
                            .user(exitsUser)
                            .role(role)
                            .society(society)
                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                            .build();
                    this._userRoleMappingRepository.save(mapping);
                }
                memberId = exitsUser.getMemberId();
            }


            Area area = this.areaRepository
                    .findById(memberDto.getAreaId())
                    .orElseThrow(() -> new ResourceNotFoundException("Area Not Found"));
            Apartment apartment = this.apartmentRepository
                    .findById(memberDto.getApartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("some apartments not found with  " + area.getId()));
            LocalDateTime possessionDate = null;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            String possessionDateStr = LocalDateTime.now().format(formatter).toString();
            if (possessionDateStr != null && !possessionDateStr.isEmpty()) {
                try {
                    possessionDate = LocalDateTime.parse(possessionDateStr, formatter);
                } catch (DateTimeParseException e) {
                    throw new AuthException("Can not parse data");
                }
            }
            User u = this.userRepository.findByMemberId(memberId);
            Resident r = Resident.builder()
                    .password(passwordEncoder.encode(memberDto.getPassword()))
                    .society(society)
                    .apartment(apartment)
                    .area(area)
                    .ownerName(memberDto.getName())
                    .ownerEmail(memberDto.getEmail())
                    .ownerPhone(memberDto.getContactNumber())
                    .residentType("VACANT")
                    .user(u)
                    .status(true)
                    .roles(role.getTitle())
                    .roleId(role.getId())
                    .build();
            this.residentRepository.save(r);
            return null;
        } catch (Exception ex) {
            return ex.getMessage();
        }

    }

    @Override
    @Transactional
    public String updateMember(UpdateMemberDto memberDto, long id) throws SQLIntegrityConstraintViolationException {
        User existingUser = this.userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Id not found", "User", String.valueOf(id)));
        Optional<User> existingEmailUser = this.userRepository.findByEmailAndIsDeleteNot(memberDto.getEmail(), true);
        if (existingEmailUser.isPresent() && existingEmailUser.get().getId() != id) {
            return "Email already exists.";
        }
        Role role = this.roleRepository.findById(memberDto.getRoleId())
                .orElseThrow(() -> new ResourceNotFoundException("Role not exists", "Role", String.valueOf(memberDto.getRoleId())));
        existingUser.setContactNumber(memberDto.getContactNumber());
        existingUser.setEmail(memberDto.getEmail());
        existingUser.setPassword(passwordEncoder.encode(memberDto.getPassword()));
        existingUser.setName(memberDto.getName());

        existingUser.setAge(memberDto.getAge());
        existingUser.setLocation(memberDto.getLocation());
        existingUser.setOccupation(memberDto.getOccupation());
        existingUser.setInterests(memberDto.getInterests());
        existingUser.setBio(memberDto.getBio());

//        existingUser.getRoles().clear();
//        existingUser.getRoles().add(role);
//        List<Resident> residents = this.residentRepository.findByUserMemberId(memberDto.getMemberId());//
//        if (residents.stream().count() > 0) {
//            List<Resident> r = residents.stream().filter(x -> x.getSociety().getId() == memberDto.getSocietyId()).map(x -> {
//                x.setOwnerEmail(memberDto.getEmail());
//                x.setOwnerName(memberDto.getName());
//                x.setOwnerPhone(memberDto.getContactNumber());
//                x.setRoles(role.getTitle());
//                x.setStatus(existingUser.isStatus());
//                return x;
//            }).toList();
//            this.residentRepository.saveAll(r);
//        }
        this.userRepository.save(existingUser);

        Society society = this.societyRepository.findById(memberDto.getSocietyId())
                .orElseThrow(() -> new ResourceNotFoundException("Society Not Found"));

        // ✅ Update UserRoleMapping instead of modifying roles directly
        List<UserRoleMapping> mappings = this._userRoleMappingRepository.findByUserAndSociety(existingUser, society);

        if (mappings.isEmpty()) {
            // If no mapping exists, create a new one
            UserRoleMapping newMapping = UserRoleMapping.builder()
                    .user(existingUser)
                    .role(role)
                    .society(society)
                    .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                    .build();
            this._userRoleMappingRepository.save(newMapping);
        } else {
            // Update existing mapping(s)
            for (UserRoleMapping mapping : mappings) {
                mapping.setRole(role);
                mapping.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
                this._userRoleMappingRepository.save(mapping);
            }
        }

        Resident resi1 = this.residentRepository
                .findByOwnerEmailAndSocietyIdAndIsDelete(memberDto.getEmail(), memberDto.getSocietyId(), false)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for update"));

//        Optional<Resident> resi = Optional.ofNullable(this.residentRepository.findByOwnerEmailAndSocietyIdAndIsDelete(memberDto.getEmail(), memberDto.getSocietyId(), false)
//                .orElseThrow(() -> new ResourceNotFoundException("Resident not found for update")));
//        Resident resi1 = resi.get();
        resi1.setOwnerEmail(memberDto.getEmail());
        resi1.setOwnerName(memberDto.getName());
        resi1.setOwnerPhone(memberDto.getContactNumber());
        resi1.setRoles(role.getTitle());
        resi1.setStatus(existingUser.isStatus());
        this.residentRepository.save(resi1);

        return null;
    }

    @Override
    public String addMemberWithProfile(AddMemberDto memberDto, MultipartFile profileImage) throws SQLIntegrityConstraintViolationException {
        try {
            Society society = this.societyRepository
                    .findById(memberDto.getSocietyId())
                    .orElseThrow(() -> new ResourceNotFoundException("Society Not Found"));
            Optional<Resident> resi = this.residentRepository.findByOwnerEmailAndSocietyIdAndIsDelete(memberDto.getEmail(), society.getId(), false);
            if (resi.isPresent()) {
                throw new AuthException("You have aleady accessed on " + society.getSocietyName());
            }
            String memberId = AppHelper.generateUniqueId();
            Role role = null;
            Optional<User> existingUser = this.userRepository.findByEmail(memberDto.getEmail());
            role = this.roleRepository.findById(memberDto.getRoleId())
                    .orElseThrow(() -> new ResourceNotFoundException("Role not exists"));
            User user = null;
            if (existingUser.isEmpty()) {
                user = this.modelMapper.map(memberDto, User.class);
                user.setEmail(memberDto.getEmail());
//            user.setSociety(society);
                user.setPassword(passwordEncoder.encode(memberDto.getPassword()));
//            user.getRoles().add(role);
                user.setMemberId(memberId);
                user.setStatus(true);

                // Handle profile image upload
                if (profileImage != null && !profileImage.isEmpty()) {
                    String imageUrl = s3Service.storeFile(profileImage);
                    user.setProfileUrl(imageUrl);
                }

                this.userRepository.save(user);


                boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, role, society);
                if (!roleExists) {
                    UserRoleMapping mapping = UserRoleMapping.builder()
                            .user(user)
                            .role(role)
                            .society(society)
                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                            .build();
                    this._userRoleMappingRepository.save(mapping);
                }

            } else {
                User exitsUser = existingUser.get();
//            exitsUser.getRoles().add(role);
                this.userRepository.save(exitsUser);
                // ✅ Create UserRoleMapping instead of adding to user.getRoles()
                boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(exitsUser, role, society);
                if (!roleExists) {
                    UserRoleMapping mapping = UserRoleMapping.builder()
                            .user(exitsUser)
                            .role(role)
                            .society(society)
                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                            .build();
                    this._userRoleMappingRepository.save(mapping);
                }
                memberId = exitsUser.getMemberId();
            }


            Area area = this.areaRepository
                    .findById(memberDto.getAreaId())
                    .orElseThrow(() -> new ResourceNotFoundException("Area Not Found"));
            Apartment apartment = this.apartmentRepository
                    .findById(memberDto.getApartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("some apartments not found with  " + area.getId()));
            LocalDateTime possessionDate = null;
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            String possessionDateStr = LocalDateTime.now().format(formatter).toString();
            if (possessionDateStr != null && !possessionDateStr.isEmpty()) {
                try {
                    possessionDate = LocalDateTime.parse(possessionDateStr, formatter);
                } catch (DateTimeParseException e) {
                    throw new AuthException("Can not parse data");
                }
            }
            User u = this.userRepository.findByMemberId(memberId);
            Resident r = Resident.builder()
                    .password(passwordEncoder.encode(memberDto.getPassword()))
                    .society(society)
                    .apartment(apartment)
                    .area(area)
                    .ownerName(memberDto.getName())
                    .ownerEmail(memberDto.getEmail())
                    .ownerPhone(memberDto.getContactNumber())
                    .residentType("VACANT")
                    .user(u)
                    .status(true)
                    .roles(role.getTitle())
                    .roleId(role.getId())
                    .build();
            this.residentRepository.save(r);
            return null;
        } catch (Exception ex) {
            return ex.getMessage();
        }
    }

    @Override
    public String updateMemberWithProfile(UpdateMemberDto memberDto, long id, MultipartFile profileImage) throws SQLIntegrityConstraintViolationException, IOException {
        User existingUser = this.userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Id not found", "User", String.valueOf(id)));
        existingUser.setName(memberDto.getName());
        existingUser.setAge(memberDto.getAge());
        existingUser.setLocation(memberDto.getLocation());
        existingUser.setOccupation(memberDto.getOccupation());
        existingUser.setInterests(memberDto.getInterests());
        existingUser.setBio(memberDto.getBio());
        // Handle profile image upload
        if (profileImage != null && !profileImage.isEmpty()) {
            if (existingUser.getProfileUrl() != null) {
                s3Service.deleteFile(existingUser.getProfileUrl());
            }
            String imageUrl = s3Service.storeFile(profileImage);
            existingUser.setProfileUrl(imageUrl);
        }
        else{
            existingUser.setProfileUrl(null);
        }
        this.userRepository.save(existingUser);
        return null;
    }

    @Override
    @Transactional
    public void deleteMember(long id) {
        User existingUser = this.userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Id not found", "User", String.valueOf(id)));
        try {
            List<Resident> existingResident = this.residentRepository.findByUserMemberId(existingUser.getMemberId());
            if ((long) existingResident.size() > 0) {
                this.residentRepository.deleteAll(existingResident);
            }
            this.userRepository.delete(existingUser);
        } catch (Exception ex) {
            throw ex;
        }
    }


    @Transactional
    public void softDeleteMember_old(long id, long societyId) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            User user = this.userRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found", "id", Long.toString(id)));
//            user.setDelete(true);
//            user.setDeletedAt(LocalDateTime.now());
//            user.setDeleteBy(loggedInId);
//            this.userRepository.save(user);
//            List<Resident> residents = this.residentRepository.findByUserMemberId(user.getMemberId());//
//            if (residents.stream().count() > 0) {
//                List<Resident> r = residents.stream().map(x -> {
//                    x.setDelete(true);
//                    x.setDeletedAt(LocalDateTime.now());
//                    x.setDeleteBy(loggedInId);
//                    return x;
//                }).toList();
//                this.residentRepository.saveAll(r);
//            }
            Optional<Resident> resi = Optional.ofNullable(this.residentRepository.findByOwnerEmailAndSocietyIdAndIsDelete(user.getEmail(), societyId, false)
                    .orElseThrow(() -> new ResourceNotFoundException("Resident not found for delete")));
            Resident resi1 = resi.get();
            resi1.setDelete(true);
            resi1.setDeletedAt(LocalDateTime.now());
            resi1.setDeleteBy(loggedInId);
            this.residentRepository.save(resi1);
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while soft deleting user: " + e.getMessage());
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    @Transactional
    public void softDeleteMember(long id, long societyId) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();

            User user = this.userRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found", "id", Long.toString(id)));

            Society society = this.societyRepository.findById(societyId)
                    .orElseThrow(() -> new ResourceNotFoundException("Society not found", "id", Long.toString(societyId)));

            // ✅ Soft delete the UserRoleMapping for this user and society
            List<UserRoleMapping> mappings = this._userRoleMappingRepository.findByUserAndSociety(user, society);
            for (UserRoleMapping mapping : mappings) {
                mapping.setDelete(true);
                mapping.setDeletedAt(LocalDateTime.now());
                mapping.setDeleteBy(loggedInId);
            }
            this._userRoleMappingRepository.saveAll(mappings);
            // ✅ Soft delete Resident entry for this user and society
            Resident resident = this.residentRepository
                    .findByOwnerEmailAndSocietyIdAndIsDelete(user.getEmail(), societyId, false)
                    .orElseThrow(() -> new ResourceNotFoundException("Resident not found for delete"));
            resident.setDelete(true);
            resident.setDeletedAt(LocalDateTime.now());
            resident.setDeleteBy(loggedInId);
            this.residentRepository.save(resident);
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while soft deleting user: " + e.getMessage());
        } catch (Exception ex) {
            throw ex;
        }
    }


    public ViewMemberDto getMember_old(long id) {
        User existingUser = this.userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Id not found", "User", String.valueOf(id)));
        return this.modelMapper.map(existingUser, ViewMemberDto.class);
    }


    @Override
    public ViewMemberDto getMember(long id) {
        User user = this.userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Id not found", "User", String.valueOf(id)));
        ViewMemberDto dto = this.modelMapper.map(user, ViewMemberDto.class);
        List<UserRoleMapping> mappings = this._userRoleMappingRepository.findByUser(user);
        List<SocietyRoleDto> societyRoles = mappings.stream().map(mapping -> {
            SocietyRoleDto srd = new SocietyRoleDto();
            srd.setSociety(modelMapper.map(mapping.getSociety(), ViewSocietyDto.class));
            srd.setRole(modelMapper.map(mapping.getRole(), RoleDTO.class));
            return srd;
        }).collect(Collectors.toList());
        dto.setSocietyRoles(societyRoles);
        return dto;
    }


    @Override
    public PaginationDto<ViewMemberDto> getMembers(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, long societyId) {
        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }
        Sort.Direction direction = Sort.Direction.fromString(sortDir);
        PageRequest pageable = PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));
        Page<User> pageMemberList;
        User loggedInUser = customUserDetailService.LoggedInUser();
        long loggedInId = loggedInUser.getId();
//        long loggedInRoleId = loggedInUser.getRoles().stream().map(x -> x.getId()).findFirst().get().longValue();
        long loggedInRoleId = loggedInUser
                .getUserRoleMappings()
                .stream()
                .filter(x -> x.getSociety().getId() == societyId)
                .findFirst()
                .get()
                .getRole()
                .getId();
        List<Long> excludedRoles = new ArrayList<>(List.of(AppConstants.RoleConstant.RESIDENTIAL_USER, AppConstants.RoleConstant.MASTER_ACCESS_USER));
        switch ((int) loggedInRoleId) {
            case (int) AppConstants.RoleConstant.ADMIN_USER:
                excludedRoles.add(AppConstants.RoleConstant.SUPERADMIN_USER);
                break;
            case (int) AppConstants.RoleConstant.STAFF_USER:
                excludedRoles.addAll(List.of(AppConstants.RoleConstant.ADMIN_USER, AppConstants.RoleConstant.SUPERADMIN_USER));
                break;
            case (int) AppConstants.RoleConstant.RESIDENTIAL_USER:
                excludedRoles.addAll(List.of(AppConstants.RoleConstant.ADMIN_USER, AppConstants.RoleConstant.SUPERADMIN_USER, AppConstants.RoleConstant.STAFF_USER, AppConstants.RoleConstant.GROUNDSTAFF_USER));
                break;
            case (int) AppConstants.RoleConstant.GROUNDSTAFF_USER:
                excludedRoles.addAll(List.of(AppConstants.RoleConstant.ADMIN_USER, AppConstants.RoleConstant.SUPERADMIN_USER, AppConstants.RoleConstant.STAFF_USER));
                break;
        }
        Specification<User> spec = Specification
                .where(MemberSpecification.hasSocietyId(societyId))
                .and(MemberSpecification.isNotDeleted(false))
                .and(MemberSpecification.hasNotUserId(loggedInId))
                .and(MemberSpecification.hasRoleNotIn(excludedRoles));
        if (searchText != null && !searchText.trim().isEmpty()) {
            spec = spec.and(MemberSpecification.searchByText(searchText));
        }
        pageMemberList = userRepository.findAll(spec, pageable);
        List<ViewMemberDto> viewMemberDtoList = pageMemberList.getContent()
                .stream()
                .map(member -> modelMapper.map(member, ViewMemberDto.class))
                .collect(Collectors.toList());
        PaginationDto<ViewMemberDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(viewMemberDtoList);
        paginationDto.setPageNumber(pageMemberList.getNumber());
        paginationDto.setPageSize(pageMemberList.getSize());
        paginationDto.setTotalPages(pageMemberList.getTotalPages());
        paginationDto.setTotalElements(pageMemberList.getTotalElements());
        paginationDto.setLastPage(pageMemberList.isLast());
        return paginationDto;
    }

    public List<ViewMemberDto> getAllUser_old(Long roleId, long societyId) {
        List<User> users;
        if (roleId != null) {
            users = this.userRepository.findUsersByRoleIdAndSocietyIdAndIsDeleteAndStatus(roleId, societyId, false, true);
        } else {
            users = this.userRepository.findBySocietyIdAndIsDelete(societyId, false);
        }

        List<ViewMemberDto> viewMemberDtoList = users
                .stream()
                .map(member -> this.modelMapper.map(member, ViewMemberDto.class))
                .collect(Collectors.toList());
        return viewMemberDtoList;
    }

    @Override
    public List<ViewMemberDto> getAllUser(Long roleId, long societyId) {
        List<User> users;
        if (roleId != null) {
            users = this.userRepository.findUsersByRoleIdAndSocietyIdAndIsDeleteAndStatus(roleId, societyId, false, true);
        } else {
            users = this.userRepository.findBySocietyIdAndIsDelete(societyId, false);
        }
        List<ViewMemberDto> viewMemberDtoList = users.stream().map(user -> {
            ViewMemberDto dto = modelMapper.map(user, ViewMemberDto.class);
            // Fetch all society-role mappings for this user
            List<UserRoleMapping> mappings = this._userRoleMappingRepository.findByUser(user);
            List<SocietyRoleDto> societyRoles = mappings.stream().map(mapping -> {
                SocietyRoleDto srd = new SocietyRoleDto();
                srd.setSociety(modelMapper.map(mapping.getSociety(), ViewSocietyDto.class));
                srd.setRole(modelMapper.map(mapping.getRole(), RoleDTO.class));
                return srd;
            }).collect(Collectors.toList());
            dto.setSocietyRoles(societyRoles);
            return dto;
        }).collect(Collectors.toList());
        return viewMemberDtoList;
    }

    @Override
    public List<RoleDTO> getAllUserRole() {
        User loggedInUser = customUserDetailService.LoggedInUser();
//        Optional<Role> role = loggedInUser.getRoles().stream().findFirst();
        Role role = loggedInUser
                .getUserRoleMappings()
                .stream()
                .findFirst()
                .get()
                .getRole();

        List<Role> roles = new ArrayList<>();
        if (role != null) {
            long rolId = role.getId();
            switch ((int) rolId) {
                case (int) AppConstants.RoleConstant.MASTER_ACCESS_USER:
                    roles = this.roleRepository.findAll();
                    break;
                case (int) AppConstants.RoleConstant.SUPERADMIN_USER:
                    roles = this.roleRepository.findByIdNot(AppConstants.RoleConstant.MASTER_ACCESS_USER);
                    break;
                case (int) AppConstants.RoleConstant.ADMIN_USER:
                    roles = this.roleRepository.findByIdNotIn(List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER, AppConstants.RoleConstant.SUPERADMIN_USER));
                    break;
                default:
                    roles = Collections.emptyList();
            }
        }
        List<RoleDTO> roleDtoList = roles
                .stream()
                .map(member -> this.modelMapper.map(member, RoleDTO.class))
                .collect(Collectors.toList());
        return roleDtoList;
    }

    @Override
    public List<RoleDTO> getAllUserRole(long societyId) {
        User loggedInUser = customUserDetailService.LoggedInUser();
        long loggedInRoleId = AppConstants.RoleConstant.MASTER_ACCESS_USER;
        boolean hasMaster = loggedInUser.getUserRoleMappings().stream().anyMatch(x -> x.getRole().getId() == AppConstants.RoleConstant.MASTER_ACCESS_USER);
        if (!hasMaster) {
            loggedInRoleId = loggedInUser
                    .getUserRoleMappings()
                    .stream()
                    .filter(x -> x.getSociety().getId() == societyId)
                    .findFirst()
                    .get()
                    .getRole()
                    .getId();
        }
//        Role role = loggedInUser
//                .getUserRoleMappings()
//                .stream()
//                .filter(x->x.getSociety().getId()==societyId)
//                .findFirst()
//                .get()
//                .getRole();
        List<Role> roles = new ArrayList<>();
//        if (role!=null) {
//            long rolId = role.getId();
        switch ((int) loggedInRoleId) {
            case (int) AppConstants.RoleConstant.MASTER_ACCESS_USER:
                roles = this.roleRepository.findAll();
                break;
            case (int) AppConstants.RoleConstant.SUPERADMIN_USER:
                roles = this.roleRepository.findByIdNot(AppConstants.RoleConstant.MASTER_ACCESS_USER);
                break;
            case (int) AppConstants.RoleConstant.ADMIN_USER:
                roles = this.roleRepository.findByIdNotIn(List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER, AppConstants.RoleConstant.SUPERADMIN_USER));
                break;
            default:
                roles = Collections.emptyList();
        }
//        }
        List<RoleDTO> roleDtoList = roles
                .stream()
                .map(member -> this.modelMapper.map(member, RoleDTO.class))
                .collect(Collectors.toList());
        return roleDtoList;
    }

    @Override
    public List<LocationDTO> getAllLocation() {
        List<Location> locations = this.locationRepository.findAll();
        List<LocationDTO> locationDTOList = locations
                .stream()
                .map(member -> this.modelMapper.map(member, LocationDTO.class))
                .collect(Collectors.toList());
        return locationDTOList;
    }

    @Transactional
    @Override
    public String revokeMember(Long memberId, MemberRevokeDto statusUpdateDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String currentUserEmail = authentication.getName();
            User user = this.userRepository.findById(memberId)
                    .orElseThrow(() -> new ResourceNotFoundException("Member Not Found"));
            user.setStatus(statusUpdateDTO.isRevoked());
            User com = this.userRepository.save(user);
            List<Resident> residents = this.residentRepository.findByUserMemberId(user.getMemberId());
            if (residents.stream().count() > 0) {
                List<Resident> r = residents.stream().filter(x -> x.getSociety().getId() == statusUpdateDTO.getSocietyId()).map(x -> {
                    x.setStatus(statusUpdateDTO.isRevoked());
                    return x;
                }).toList();
                this.residentRepository.saveAll(r);
            }
            return "Member Revoked";
        } catch (Exception ex) {
            return "";
        }
    }

    @Override
    public PaginationDto<ViewMemberDto> getMembersFromResident(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, long societyId) {
        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }
        Sort.Direction direction = Sort.Direction.fromString(sortDir);
        PageRequest pageable = PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));
        Page<Resident> pageMemberList;
        User loggedInUser = customUserDetailService.LoggedInUser();
        long loggedInId = loggedInUser.getId();
        String loggedInMemberId = loggedInUser.getMemberId();
        long loggedInRoleId = AppConstants.RoleConstant.MASTER_ACCESS_USER;
        boolean hasMaster = loggedInUser.getUserRoleMappings().stream().anyMatch(x -> x.getRole().getId() == AppConstants.RoleConstant.MASTER_ACCESS_USER);
        if (!hasMaster) {
            loggedInRoleId = loggedInUser
                    .getUserRoleMappings()
                    .stream()
                    .filter(x -> x.getSociety().getId() == societyId)
                    .findFirst()
                    .get()
                    .getRole()
                    .getId();
        }
        List<Long> excludedRoles = new ArrayList<>(List.of(AppConstants.RoleConstant.RESIDENTIAL_USER));
        switch ((int) loggedInRoleId) {
            case (int) AppConstants.RoleConstant.SUPERADMIN_USER ->
                    excludedRoles.addAll(List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER));
            case (int) AppConstants.RoleConstant.ADMIN_USER ->
                    excludedRoles.addAll(List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER, AppConstants.RoleConstant.SUPERADMIN_USER));
            case (int) AppConstants.RoleConstant.STAFF_USER ->
                    excludedRoles.addAll(List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER, AppConstants.RoleConstant.ADMIN_USER, AppConstants.RoleConstant.SUPERADMIN_USER));
            case (int) AppConstants.RoleConstant.RESIDENTIAL_USER -> excludedRoles.addAll(
                    List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER, AppConstants.RoleConstant.ADMIN_USER, AppConstants.RoleConstant.SUPERADMIN_USER, AppConstants.RoleConstant.STAFF_USER, AppConstants.RoleConstant.GROUNDSTAFF_USER)
            );
            case (int) AppConstants.RoleConstant.GROUNDSTAFF_USER -> excludedRoles.addAll(
                    List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER, AppConstants.RoleConstant.ADMIN_USER, AppConstants.RoleConstant.SUPERADMIN_USER, AppConstants.RoleConstant.STAFF_USER)
            );
        }
        Specification<Resident> spec = Specification
                .where(ResidentSpecification.hasSocietyId(societyId))
                .and(ResidentSpecification.isNotDeleted(false))
                .and(ResidentSpecification.hasNotMemberId(loggedInMemberId))
                .and(ResidentSpecification.hasRolesNotIn(excludedRoles));//change in future
        if (searchText != null && !searchText.trim().isEmpty()) {
            spec = spec.and(ResidentSpecification.searchByText(searchText));
        }
        pageMemberList = residentRepository.findAll(spec, pageable);
        List<ViewMemberDto> viewMemberDtoList = pageMemberList.getContent()
                .stream()
                .map(member -> modelMapper.map(member, ViewMemberDto.class))
                .collect(Collectors.toList());
        PaginationDto<ViewMemberDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(viewMemberDtoList);
        paginationDto.setPageNumber(pageMemberList.getNumber());
        paginationDto.setPageSize(pageMemberList.getSize());
        paginationDto.setTotalPages(pageMemberList.getTotalPages());
        paginationDto.setTotalElements(pageMemberList.getTotalElements());
        paginationDto.setLastPage(pageMemberList.isLast());
        return paginationDto;
    }

}