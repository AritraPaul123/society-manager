package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Incident;
import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IncidentRepository extends JpaRepository<Incident, Long> {
    List<Incident> findBySociety(Society society);
    List<Incident> findByGuard(User guard);
    List<Incident> findByAssignedTo(User user);
    List<Incident> findByStatus(String status);
}
