package com.propertymanageruae.api.services.Society;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.master.AddSocietyDto;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;

import java.util.List;

public interface ISocietyService {
    String addSociety(AddSocietyDto dto);
    ViewSocietyDto updateSociety(Long id, AddSocietyDto dto);
    List<ViewSocietyDto> getAllSocietyForWeb();
    ViewSocietyDto getSocietyById(Long id);
    void deleteSociety(Long id, long deletedBy);
    ViewSocietyDto togglePublish(Long id, boolean publish, long modifyBy);
    PaginationDto<ViewSocietyDto> getAllSocietyInWebWithPaginate(int pageNumber,
                                                                        int pageSize,
                                                                        String sortBy,
                                                                        String sortDir,
                                                                        String searchText);
}