package com.propertymanageruae.api.services.master;

import com.google.protobuf.ServiceException;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.enums.SocietyType;
import com.propertymanageruae.api.exceptions.AuthException;
import com.propertymanageruae.api.exceptions.CsvParsingException;
import com.propertymanageruae.api.exceptions.EmailAlreadyExitException;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.AppHelper;
import com.propertymanageruae.api.helper.S3FileHandler;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.master.*;
import com.propertymanageruae.api.payloads.user.ViewComplainerDto;
import com.propertymanageruae.api.repositories.*;
import com.propertymanageruae.api.services.logger.LoggerService;
import com.propertymanageruae.api.services.notification.INotificationService;
import com.propertymanageruae.api.services.user.CustomUserDetailService;
import com.propertymanageruae.api.specificaions.ApartmentSpecification;
import com.propertymanageruae.api.specificaions.AreaSpecification;
import com.propertymanageruae.api.specificaions.ResidentSpecification;
import com.propertymanageruae.api.specificaions.SocietySpecification;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.*;
import java.net.URL;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.propertymanageruae.api.specificaions.ApartmentQueryWithMultiClause.hasSocietyId;
import static com.propertymanageruae.api.specificaions.ApartmentQueryWithMultiClause.withActiveResidentsOnly;

@AllArgsConstructor
@Service
@Slf4j
public class MasterService implements IMasterService {
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private IRoleRepository roleRepository;
    @Autowired
    private ISocietyRepository societyRepository;
    @Autowired
    private IAreaRepository areaRepository;
    @Autowired
    private IApartmentRepository apartmentRepository;
    @Autowired
    private IResidentRepository residentRepository;
    @Autowired
    private CustomUserDetailService customUserDetailService;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private ICommentMasterRepository commentMasterRepository;
    @Autowired
    private IComplaintRepository complaintRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private S3FileHandler s3FileHandler;
    @Autowired
    private LoggerService loggerService;
    @Autowired
    private IUserRoleMappingRepository _userRoleMappingRepository;

    @Autowired
    private INotificationService _notificationService;

    private static LocalDateTime getLocalDateTime(ResidentCSV csvLine, DateTimeFormatter formatter) {
        LocalDateTime possessionDate = null;
        String possessionDateStr = csvLine.getPossessionDate();
        if (possessionDateStr != null && !possessionDateStr.isEmpty()) {
            try {
                possessionDate = LocalDateTime.parse(possessionDateStr, formatter);
            } catch (DateTimeParseException e) {
                throw new AuthException("Can not parse data");
            }
        }
        return possessionDate;
    }

    private String generateUploadSummary(UploadDto uploadResult, long typeId) {
        String entityType = switch ((int) typeId) {
            case 1 -> "Area";
            case 2 -> "Apartment";
            case 3 -> "Resident";
            default -> "Unknown";
        };
        int successCount = uploadResult.getRecords().size();
        int errorCount = uploadResult.getErrors().size();
        StringBuilder summary = new StringBuilder();
        summary.append(entityType).append(" Upload Completed.\n");
        summary.append("Total ").append(successCount).append(" ").append(entityType.toLowerCase()).append("s uploaded successfully.\n");
        if (errorCount > 0) {
            summary.append("Errors Encountered (").append(errorCount).append("):\n");
            uploadResult.getErrors().forEach(error -> summary.append(" - ").append(error).append("\n"));
        }
        return summary.toString();
    }

    private UploadDto processAreaUpload(MultipartFile file, Society society) throws IOException {
        if (Objects.requireNonNull(file.getOriginalFilename()).endsWith(".csv")) {
            return parseAreaCsv(file, society);
        } else if (file.getOriginalFilename().endsWith(".xlsx")) {
            return parseAreaExcel(file, society);
        }
        throw new IllegalArgumentException("Unsupported file type for Area: " + file.getOriginalFilename());
    }

    private UploadDto processApartmentUpload(MultipartFile file, Society society) throws IOException {
        if (Objects.requireNonNull(file.getOriginalFilename()).endsWith(".csv")) {
            return parseApartmentCsv(file, society);
        } else if (file.getOriginalFilename().endsWith(".xlsx")) {
            return parseApartmentExcel(file, society);
        }
        throw new IllegalArgumentException("Unsupported file type for Apartment: " + file.getOriginalFilename());
    }

    private UploadDto processResidentUpload(MultipartFile file, Society society) throws IOException {
        if (Objects.requireNonNull(file.getOriginalFilename()).endsWith(".csv")) {
            return parseResidentCsv(file, society);
        } else if (file.getOriginalFilename().endsWith(".xlsx")) {
            return parseResidentExcel(file, society);
        }
        throw new IllegalArgumentException("Unsupported file type for Resident: " + file.getOriginalFilename());
    }

    private void saveRecords(Set<Object> records, long typeId) {
        if (records.isEmpty()) return;
        switch ((int) typeId) {
            case 1:
                this.areaRepository.saveAll(records.stream().map(obj -> (Area) obj).toList());
                break;
            case 2:
                this.apartmentRepository.saveAll(records.stream().map(obj -> (Apartment) obj).toList());
                break;
            case 3:
                this.residentRepository.saveAll(records.stream().map(obj -> (Resident) obj).toList());
                break;
            default:
                throw new IllegalArgumentException("Invalid typeId for saving: " + typeId);
        }
    }

    private boolean isRowEmpty(Row row) {
        for (Cell cell : row) {
            if (cell != null && cell.getCellType() != CellType.BLANK) {
                return false;
            }
        }
        return true;
    }

    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue();
            case NUMERIC -> String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            default -> "";
        };
    }

    private UploadDto parseAreaExcel(MultipartFile file, Society society) throws IOException {
        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
        Set<Object> areas = new HashSet<>();
        List<String> errorLogs = new ArrayList<>();
        try (InputStream inputStream = file.getInputStream(); Workbook workbook = new XSSFWorkbook(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            for (Row row : sheet) {
                if (row.getRowNum() == 0 || isRowEmpty(row)) continue;
                try {
                    String fArea = getCellValue(row.getCell(0));
                    String fType = getCellValue(row.getCell(1));
                    String fCluster = getCellValue(row.getCell(2));
                    if (fArea == null || fType == null) {
                        errorLogs.add("Row " + (row.getRowNum() + 1) + ": Area or Type is missing.");
                        continue;
                    }
                    if (this.areaRepository.existsByAreaAndTypeAndSociety(fArea, fType, society)) {
                        errorLogs.add("Row " + (row.getRowNum() + 1) + ": Duplicate area detected - " + fArea);
                        continue;
                    }
                    Area area = Area.builder()
                            .area(fArea)
                            .type(fType)
                            .cluster(fCluster)
                            .society(society)
                            .createdBy(loggedInId)
                            .build();
                    areas.add(area);
                } catch (Exception e) {
                    errorLogs.add("Row " + (row.getRowNum() + 1) + ": Error - " + e.getMessage());
                }
            }
        }
        if (!errorLogs.isEmpty()) {
            loggerService.logInfo("Total Errors: " + errorLogs.size());
            errorLogs.forEach(loggerService::logInfo);
        }
        Set<ViewAreaDto> safeResponseDto = areas.stream()
                .map(r -> modelMapper.map(r, ViewAreaDto.class))
                .collect(Collectors.toSet());
        return UploadDto.builder()
                .records(areas)
                .errors(errorLogs)
                .build();
    }

    private UploadDto parseAreaCsv(MultipartFile file, Society society) throws IOException {
        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
        List<String> errorLogs = new ArrayList<>();
        Set<Object> areas;
        try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            HeaderColumnNameMappingStrategy<AreaCSV> strategy =
                    new HeaderColumnNameMappingStrategy<>();
            strategy.setType(AreaCSV.class);
            CsvToBean<AreaCSV> csvToBean =
                    new CsvToBeanBuilder<AreaCSV>(reader)
                            .withMappingStrategy(strategy)
                            .withIgnoreEmptyLine(true)
                            .withIgnoreLeadingWhiteSpace(true)
                            .build();
            areas = csvToBean.parse()
                    .stream()
                    .map(csvLine -> Area.builder()
                            .area(csvLine.getArea())
                            .type(csvLine.getType())
                            .cluster(csvLine.getCluster())
                            .society(society)
                            .createdBy(loggedInId)
                            .build()
                    )
                    .collect(Collectors.toSet());
        }
        Set<ViewAreaDto> safeResponseDto = areas.stream()
                .map(r -> modelMapper.map(r, ViewAreaDto.class))
                .collect(Collectors.toSet());
        return UploadDto.builder()
                .records(areas)
                .errors(errorLogs)
                .build();
    }

    private UploadDto parseApartmentCsv(MultipartFile file, Society society) throws IOException {
        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
        List<String> errorLogs = new ArrayList<>();
        Set<Object> apartments;
        try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            HeaderColumnNameMappingStrategy<ApartmentCSV> strategy = new HeaderColumnNameMappingStrategy<>();
            strategy.setType(ApartmentCSV.class);
            CsvToBean<ApartmentCSV> csvToBean = new CsvToBeanBuilder<ApartmentCSV>(reader)
                    .withMappingStrategy(strategy)
                    .withIgnoreEmptyLine(true)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();
            List<ApartmentCSV> csvRows = csvToBean.parse();
            AtomicInteger skippedRows = new AtomicInteger();
            apartments = csvRows.stream()
                    .flatMap(csvLine -> {
                        Area area = this.areaRepository.findBySocietyAndArea(society, csvLine.getBlock())
                                .orElseThrow(() -> new ResourceNotFoundException("Area Not Found"));
                        if (csvLine.getBlock() == null || csvLine.getFloor() == null || csvLine.getFlat() == null) {
                            throw new CsvParsingException("Missing required fields in CSV line");
                        }
                        String[] flats = csvLine.getFlat().contains(",") ? csvLine.getFlat().split(",") : new String[]{csvLine.getFlat()};
                        return Arrays.stream(flats)
                                .map(flat -> {
                                    boolean exists = this.apartmentRepository.existsByBlockAndFloorAndFlatAndAreaAndSociety(
                                            csvLine.getBlock(), csvLine.getFloor(), flat.trim(), area, society);
                                    if (exists) {
                                        skippedRows.getAndIncrement();
                                        return null;
                                    }
                                    return Apartment.builder()
                                            .block(csvLine.getBlock())
                                            .floor(csvLine.getFloor())
                                            .flat(flat.trim())
                                            .intercom(csvLine.getIntercom())
                                            .area(area)
                                            .createdBy(loggedInId)
                                            .society(society)
                                            .build();
                                });
                    })
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());
            if (skippedRows.get() == csvRows.size()) {
                throw new CsvParsingException("All rows already exist in the database");
            }
            Set<ViewApartmentDto> safeResponseDto = apartments.stream()
                    .map(r -> modelMapper.map(r, ViewApartmentDto.class))
                    .collect(Collectors.toSet());
            return UploadDto.builder()
                    .records(apartments)
                    .errors(errorLogs)
                    .build();
        }
    }

    private UploadDto parseApartmentExcel(MultipartFile file, Society society) throws IOException {
        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
        Set<Object> apartments = new HashSet<>();
        List<String> errors = new ArrayList<>();
        try (InputStream inputStream = file.getInputStream(); Workbook workbook = new XSSFWorkbook(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            boolean isHeaderSkipped = false;
            int rowNum = 0;
            for (Row row : sheet) {
                rowNum++;
                if (!isHeaderSkipped) {
                    isHeaderSkipped = true;
                    continue;
                }
                if (isRowEmpty(row)) continue;
                String block = getCellValue(row.getCell(0));
                String floor = getCellValue(row.getCell(1));
                String flat = getCellValue(row.getCell(2));
                String intercom = getCellValue(row.getCell(3));
                if (block.isEmpty() || floor.isEmpty() || flat.isEmpty()) {
                    errors.add("Row " + rowNum + ": Missing required fields (block, floor, flat)");
                    continue;
                }
                Area area = this.areaRepository.findBySocietyAndArea(society, block).orElse(null);
                if (area == null) {
                    errors.add("Row " + rowNum + ": Area '" + block + "' not found in society");
                    continue;
                }
                String[] flats = flat.contains(",") ? flat.split(",") : new String[]{flat};
                int finalRowNum = rowNum;
                Arrays.stream(flats)
                        .map(String::trim)
                        .filter(f -> !f.isEmpty())
                        .forEach(f -> {
                            boolean exists = this.apartmentRepository.existsByBlockAndFloorAndFlatAndAreaAndSociety(
                                    block, floor, f, area, society);
                            if (exists) {
                                errors.add("Row " + finalRowNum + ": Apartment already exists (block: " + block +
                                        ", floor: " + floor + ", flat: " + f + ")");
                            } else {
                                apartments.add(Apartment.builder()
                                        .block(block)
                                        .floor(floor)
                                        .flat(f)
                                        .intercom(intercom)
                                        .area(area)
                                        .createdBy(loggedInId)
                                        .society(society)
                                        .build());
                            }
                        });
            }
        }
        if (!errors.isEmpty()) {
            loggerService.logInfo("Total Errors: " + errors.size());
            errors.forEach(loggerService::logInfo);
        }
//        if (apartments.isEmpty()) {ow
//            throw new CsvParsingException("No valid apartments to save. Errors: " + errors);
//        }
        Set<ViewApartmentDto> safeResponseDto = apartments.stream()
                .map(r -> modelMapper.map(r, ViewApartmentDto.class))
                .collect(Collectors.toSet());
        return UploadDto.builder()
                .records(apartments)
                .errors(errors)
                .build();
    }

    private UploadDto parseResidentCsv(MultipartFile file, Society society) throws IOException {
        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        List<String> errorLogs = new ArrayList<>();
        Set<Object> residents;
        try (Reader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            HeaderColumnNameMappingStrategy<ResidentCSV> strategy = new HeaderColumnNameMappingStrategy<>();
            strategy.setType(ResidentCSV.class);
            Optional<Role> fetchRole = this.roleRepository.findById(AppConstants.RoleConstant.RESIDENTIAL_USER);
            Role role;
            if (fetchRole.isPresent()) {
                role = fetchRole.get();
            } else {
                throw new ResourceNotFoundException("Not Found", "role", AppConstants.RoleConstant.RESIDENTIAL_USER + "");
            }
            CsvToBean<ResidentCSV> csvToBean = new CsvToBeanBuilder<ResidentCSV>(reader)
                    .withMappingStrategy(strategy)
                    .withIgnoreEmptyLine(true)
                    .withIgnoreLeadingWhiteSpace(true)
                    .build();
            residents = csvToBean.parse()
                    .stream()
                    .map(csvLine -> {
                        Area area = this.areaRepository.findBySocietyAndArea(society, csvLine.getBlock())
                                .orElseThrow(() -> new ResourceNotFoundException("Area Not Found"));
                        Apartment apartment = this.apartmentRepository
                                .findByAreaAndFlat(area, csvLine.getFlat())
                                .orElseThrow(() -> new ResourceNotFoundException("some apartments not found with  " + area.getId()));
                        LocalDateTime possessionDate = getLocalDateTime(csvLine, formatter);
                        String memberId = AppHelper.generateUniqueId();
                        String memberTenantId = AppHelper.generateUniqueId();
                        Optional<User> existingUser = this.userRepository.findByEmail(csvLine.getOwnerEmail());
                        Optional<User> existingTenantUser = this.userRepository.findByEmail(csvLine.getTenantEmail());//
                        if (existingTenantUser.isEmpty()) {
                            User u = User.builder()
                                    .email(csvLine.getOwnerEmail())
                                    .contactNumber(csvLine.getOwnerPhone())
//                                    .society(society)
                                    .password(passwordEncoder.encode("1234"))
                                    .name(csvLine.getOwnerName())
                                    .status(true)
//                                    .roles(Set.of(fetchRole.get()))
                                    .memberId(memberTenantId)
                                    .residentType(AppConstants.ResidentType.TENANT)
                                    .build();
                            this.userRepository.save(u);

                            // ✅ Create UserRoleMapping instead of adding to user.getRoles()
                            boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, role, society);
                            if (!roleExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(u)
                                        .role(role)
                                        .society(society)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }
                        }
                        if (existingUser.isEmpty()) {
                            User u = User.builder()
                                    .email(csvLine.getOwnerEmail())
                                    .contactNumber(csvLine.getOwnerPhone())
//                                    .society(society)
                                    .password(passwordEncoder.encode("1234"))
                                    .name(csvLine.getOwnerName())
                                    .status(true)
//                                    .roles(Set.of(fetchRole.get()))
                                    .memberId(memberId)
                                    .residentType(AppConstants.ResidentType.OWNER)
                                    .build();
                            this.userRepository.save(u);

                            // ✅ Create UserRoleMapping instead of adding to user.getRoles()
                            boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, role, society);
                            if (!roleExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(u)
                                        .role(role)
                                        .society(society)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }

                        } else {
                            memberId = existingUser.get().getMemberId();
                        }
                        User u = this.userRepository.findByMemberId(memberId);
                        return Resident.builder()
                                .bhk(csvLine.getBhk())
                                .sqFeetArea(csvLine.getSqFeetArea())
                                .ownerName(csvLine.getOwnerName())
                                .ownerPhone(csvLine.getOwnerPhone())
                                .ownerSecondaryPhone(csvLine.getOwnerSecondaryPhone())
                                .ownerEmail(csvLine.getOwnerEmail())
                                .tenantName(csvLine.getTenantName())
                                .tenantPhone(csvLine.getTenantPhone())
                                .tenantSecondaryPhone(csvLine.getTenantSecondaryPhone())
                                .tenantEmail(csvLine.getTenantEmail())
                                .residentType(csvLine.getResidentType())
                                .parking(csvLine.getParking())
                                .accommodationType(csvLine.getAccommodationType())
                                .primaryOwnerPhone(csvLine.getPrimaryOwnerPhone())
                                .primaryTenantPhone(csvLine.getPrimaryTenantPhone())
                                .meterId(csvLine.getMeterId())
                                .consumerId(csvLine.getConsumerId())
                                .sanctionedLoadKW(csvLine.getSanctionedLoadKW())
                                .sanctionedDGLoadKV(csvLine.getSanctionedDGLoadKV())
                                .numberPipedGasUsers(csvLine.getNumberPipedGasUsers())
                                .possessionDate(possessionDate)
                                .ownerMemberId(memberId)
                                .tenantMemberId(memberTenantId)
                                .createdBy(loggedInId)
                                .roles(AppConstants.RoleTitle.resident)
                                .user(u)
                                .apartment(apartment)
                                .area(area)
                                .society(society)
                                .password(passwordEncoder.encode("1234"))//
                                .build();
                    })
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());
        }
        Set<ViewResidentDto> safeResponseDtos = residents.stream()
                .map(r -> modelMapper.map(r, ViewResidentDto.class))
                .collect(Collectors.toSet());

        return UploadDto.builder()
                .records(residents)
                .errors(errorLogs)
                .uploadSummary("Uploaded " + safeResponseDtos.size() + " residents successfully.")
                .build();
    }

    private UploadDto parseResidentExcel_old(MultipartFile file, Society society) throws IOException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
        Set<Object> residents = new HashSet<>();
        List<String> errorLogs = new ArrayList<>();
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            if (rowIterator.hasNext()) rowIterator.next();
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            int rowNumber = 1;
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                rowNumber++;
                if (isRowEmpty(row)) {
                    continue;
                }
                try {
                    String block = getStringCellValue(row, 0, evaluator);
                    String flat = getStringCellValue(row, 1, evaluator);
                    String accommodationType = getStringCellValue(row, 2, evaluator);
                    String tenantName = getStringCellValue(row, 3, evaluator);
                    String tenantPhone = getStringCellValue(row, 4, evaluator);
                    String tenantEmail = getStringCellValue(row, 5, evaluator);
                    String primaryOwnerPhone = getStringCellValue(row, 6, evaluator);
                    String primaryTenantPhone = getStringCellValue(row, 7, evaluator);
                    String meterId = getStringCellValue(row, 9, evaluator);
                    String consumerId = getStringCellValue(row, 10, evaluator);
                    String sanctionedLoadKW = getStringCellValue(row, 11, evaluator);
                    String sanctionedDGLoadKV = getStringCellValue(row, 12, evaluator);
                    String numberPipedGasUser = getStringCellValue(row, 13, evaluator);
                    String possessionDateStr = getStringCellValue(row, 14, evaluator);
                    String ownerName = getStringCellValue(row, 15, evaluator);
                    String ownerPhone = getStringCellValue(row, 16, evaluator);
                    String ownerEmail = getStringCellValue(row, 17, evaluator);
                    Area area;
                    try {
                        area = this.areaRepository.findBySocietyAndArea(society, block)
                                .orElseThrow(() -> new ResourceNotFoundException("Area Not Found: block " + block));
                    } catch (ResourceNotFoundException e) {
                        errorLogs.add("Row " + rowNumber + ": " + e.getMessage());
                        continue;
                    }
                    Apartment apartment;
                    try {
                        apartment = this.apartmentRepository.findByAreaAndFlat(area, flat)
                                .orElseThrow(() -> new ResourceNotFoundException("Apartment Not Found: block " + block + ", flat " + flat));
                    } catch (ResourceNotFoundException e) {
                        errorLogs.add("Row " + rowNumber + ": " + e.getMessage());
                        continue;
                    }
                    if (this.residentRepository.existsByTenantEmailAndAreaAndApartmentAndSociety(tenantEmail, area, apartment, society)) {
                        errorLogs.add("Row " + rowNumber + ": Duplicate record for tenant email " + tenantEmail);
                        continue;
                    }
                    LocalDateTime possessionDate = null;
                    if (possessionDateStr != null && !possessionDateStr.isBlank()) {
                        try {
                            possessionDate = LocalDateTime.parse(possessionDateStr, formatter);
                        } catch (DateTimeParseException e) {
                            errorLogs.add("Row " + rowNumber + ": Invalid date format " + possessionDateStr);
                            continue;
                        }
                    }
                    String tenantMemberId;
                    String ownerMemberId;
                    Optional<User> existingTenantUser = this.userRepository.findByEmail(tenantEmail);
                    Optional<User> existingOwnerUser = this.userRepository.findByEmail(ownerEmail);
                    Role residentRole = this.roleRepository
                            .findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
                            .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"));
                    if (existingTenantUser.isEmpty()) {
                        tenantMemberId = AppHelper.generateUniqueId();
                        User newUser = User.builder()
                                .email(tenantEmail)
                                .contactNumber(tenantPhone)
                                .password(passwordEncoder.encode("1234"))
                                .name(tenantName)
                                .status(true)
                                .memberId(tenantMemberId)
                                .residentType(AppConstants.ResidentType.TENANT)
                                .build();
                        this.userRepository.save(newUser);

                        boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(newUser, residentRole, society);
                        if (!roleExists) {
                            UserRoleMapping mapping = UserRoleMapping.builder()
                                    .user(newUser)
                                    .role(residentRole)
                                    .society(society)
                                    .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                    .build();
                            this._userRoleMappingRepository.save(mapping);
                        }

                    } else {
                        User existUser = existingTenantUser.get();
                        this.userRepository.save(existUser);
//                        this._userRoleMappingRepository.deleteByUserAndSociety(existUser, society);
//
//                        UserRoleMapping mapping = UserRoleMapping.builder()
//                                .user(existUser)
//                                .role(residentRole)
//                                .society(society)
//                                .createdAt(Timestamp.valueOf(LocalDateTime.now()))
//                                .build();
//                        this._userRoleMappingRepository.save(mapping);

                        // ✅ Update UserRoleMapping instead of modifying roles directly
                        List<UserRoleMapping> mappings = this._userRoleMappingRepository.findByUserAndSociety(existUser, society);

                        if (mappings.isEmpty()) {
                            // If no mapping exists, create a new one
                            UserRoleMapping newMapping = UserRoleMapping.builder()
                                    .user(existUser)
                                    .role(residentRole)
                                    .society(society)
                                    .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                    .build();
                            this._userRoleMappingRepository.save(newMapping);
                        } else {
                            // Update existing mapping(s)
                            for (UserRoleMapping mapping : mappings) {
                                mapping.setRole(residentRole);
                                mapping.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
                                this._userRoleMappingRepository.save(mapping);
                            }
                        }
                        tenantMemberId = existingTenantUser.get().getMemberId();
                    }

                    if (existingOwnerUser.isEmpty()) {
                        ownerMemberId = AppHelper.generateUniqueId();
                        User newUser = User.builder()
                                .email(ownerEmail)
                                .contactNumber(ownerPhone)
                                .password(passwordEncoder.encode("1234"))
                                .name(ownerName)
                                .status(true)
                                .memberId(ownerMemberId)
                                .residentType(AppConstants.ResidentType.OWNER)
                                .build();
                        this.userRepository.save(newUser);

                        boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(newUser, residentRole, society);
                        if (!roleExists) {
                            UserRoleMapping mapping = UserRoleMapping.builder()
                                    .user(newUser)
                                    .role(residentRole)
                                    .society(society)
                                    .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                    .build();
                            this._userRoleMappingRepository.save(mapping);
                        }

                    } else {
                        User existUser = existingOwnerUser.get();
                        this.userRepository.save(existUser);

                        List<UserRoleMapping> mappings = this._userRoleMappingRepository.findByUserAndSociety(existUser, society);

                        if (mappings.isEmpty()) {
                            // If no mapping exists, create a new one
                            UserRoleMapping newMapping = UserRoleMapping.builder()
                                    .user(existUser)
                                    .role(residentRole)
                                    .society(society)
                                    .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                    .build();
                            this._userRoleMappingRepository.save(newMapping);
                        } else {
                            // Update existing mapping(s)
                            for (UserRoleMapping mapping : mappings) {
                                mapping.setRole(residentRole);
                                mapping.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
                                this._userRoleMappingRepository.save(mapping);
                            }
                        }
                        ownerMemberId = existingOwnerUser.get().getMemberId();
                    }

                    Resident resident = Resident.builder()
                            .possessionDate(possessionDate)
                            .createdBy(loggedInId)
                            .roles(AppConstants.RoleTitle.resident)
                            .user(this.userRepository.findByMemberId(tenantMemberId))
                            .apartment(apartment)
                            .area(area)
                            .society(society)
                            .password(passwordEncoder.encode("1234"))
                            .tenantName(tenantName)
                            .tenantPhone(tenantPhone)
                            .tenantEmail(tenantEmail)
                            .ownerEmail(ownerEmail)
                            .ownerName(ownerName)
                            .ownerPhone(ownerPhone)
                            .ownerMemberId(ownerMemberId)
                            .accommodationType(accommodationType)
                            .primaryOwnerPhone(primaryOwnerPhone)
                            .primaryTenantPhone(primaryTenantPhone)
                            .meterId(meterId)
                            .consumerId(consumerId)
                            .sanctionedLoadKW(sanctionedLoadKW)
                            .sanctionedDGLoadKV(sanctionedDGLoadKV)
                            .numberPipedGasUsers(numberPipedGasUser.isBlank() ? null : Integer.parseInt(numberPipedGasUser))
                            .tenantMemberId(tenantMemberId)
                            .residentType(AppConstants.ResidentType.TENANT)
                            .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
                            .build();
                    residents.add(resident);
                } catch (Exception e) {
                    errorLogs.add("Row " + rowNumber + ": Unexpected error - " + e.getMessage());
                }
            }
        }
        if (!errorLogs.isEmpty()) {
            loggerService.logInfo("Total Errors: " + errorLogs.size());
            errorLogs.forEach(loggerService::logInfo);
        }
        return UploadDto.builder()
                .records(residents)
                .errors(errorLogs)
                .uploadSummary("")
                .build();
    }

    private String handleUserRoleMapping(String email, String phone, String name,
                                         String residentType, Role role, Society society) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        var memberId = AppHelper.generateUniqueId();
        User user = userOpt.orElseGet(() -> {
            User newUser = User.builder()
                    .email(email)
                    .password(passwordEncoder.encode("1234"))
                    .contactNumber(phone)
                    .name(name)
                    .status(true)
                    .memberId(memberId)
                    .residentType(residentType)
                    .build();
            return userRepository.save(newUser);
        });
        // Assign mapping only if missing
        _userRoleMappingRepository.findByUserAndSociety(user, society)
                .stream()
                .findAny()
                .ifPresentOrElse(
                        m -> m.setUpdatedAt(Timestamp.valueOf(LocalDateTime.now())),
                        () -> _userRoleMappingRepository.save(
                                UserRoleMapping.builder()
                                        .user(user)
                                        .role(role)
                                        .society(society)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build()
                        )
                );

        return user.getMemberId();
    }

    private Optional<LocalDateTime> parseLocalDateTimeSafe(String value, DateTimeFormatter formatter) {
        if (value == null || value.isBlank()) return Optional.empty();
        try {
            return Optional.of(LocalDateTime.parse(value, formatter));
        } catch (DateTimeParseException e) {
            return Optional.empty();
        }
    }


    private UploadDto parseResidentExcel(MultipartFile file, Society society) throws IOException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        long loggedInId = customUserDetailService.LoggedInUser().getId();

        Set<Object> residents = new HashSet<>();
        List<String> errorLogs = new ArrayList<>();

        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            var sheet = workbook.getSheetAt(0);
            var iterator = sheet.iterator();

            if (iterator.hasNext()) iterator.next(); // skip header

            var evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            int rowNum = 1;

            while (iterator.hasNext()) {
                rowNum++;
                Row row = iterator.next();

                if (isRowEmpty(row)) continue;

                try {
                    String block = getStringCellValue(row, 0, evaluator);
                    String flat = getStringCellValue(row, 1, evaluator);

                    // Fetch Area
                    var area = areaRepository.findBySocietyAndArea(society, block)
                            .orElse(null);

                    if (area == null) {
                        errorLogs.add("Row %d: Area Not Found: block %s".formatted(rowNum, block));
                        continue;
                    }

                    // Fetch Apartment
                    var apartment = apartmentRepository.findByAreaAndFlat(area, flat)
                            .orElse(null);

                    if (apartment == null) {
                        errorLogs.add("Row %d: Apartment Not Found: block %s, flat %s".formatted(rowNum, block, flat));
                        continue;
                    }

                    String tenantName = getStringCellValue(row, 3, evaluator);
                    String tenantPhone = getStringCellValue(row, 4, evaluator);
                    String tenantEmail = getStringCellValue(row, 5, evaluator);
                    String ownerName = getStringCellValue(row, 15, evaluator);
                    String ownerPhone = getStringCellValue(row, 16, evaluator);
                    String ownerEmail = getStringCellValue(row, 17, evaluator);

                    // Prevent duplicate Resident
                    if (residentRepository.existsByTenantEmailAndAreaAndApartmentAndSociety(tenantEmail, area, apartment, society)) {
                        errorLogs.add("Row %d: Duplicate record for tenant email %s".formatted(rowNum, tenantEmail));
                        continue;
                    }

                    if (residentRepository.existsByTenantEmailAndAreaAndApartmentAndSociety(ownerEmail, area, apartment, society)) {
                        errorLogs.add("Row %d: Duplicate record for owner email %s".formatted(rowNum, ownerEmail));
                        continue;
                    }
                    // Possession date
                    final int currentRow = rowNum;
                    //LocalDateTime possessionDate = parseLocalDateTimeSafe(getStringCellValue(row, 14, evaluator), formatter)
                    //.orElseGet(() -> {
                    // errorLogs.add("Row %d: Invalid date format".formatted(currentRow));
                    //return null;
                    //});


                    //if (possessionDate == null) continue;
                    String possessionDateStr = getStringCellValue(row, 14, evaluator);
                    LocalDateTime possessionDate = null;
                    if (possessionDateStr != null && !possessionDateStr.isBlank()) {
                        try {
                            possessionDate = LocalDateTime.parse(possessionDateStr, formatter);
                        } catch (DateTimeParseException e) {
                            errorLogs.add("Row %d: Invalid date format".formatted(currentRow));
                            continue;
                        }
                    }

                    Role residentRole = roleRepository
                            .findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
                            .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"));

                    String tenantMemberId = handleUserRoleMapping(tenantEmail, tenantPhone, tenantName,
                            AppConstants.ResidentType.TENANT, residentRole, society);

                    String ownerMemberId = handleUserRoleMapping(ownerEmail, ownerPhone, ownerName,
                            AppConstants.ResidentType.OWNER, residentRole, society);

                    User finalUser = Stream.of(ownerMemberId, tenantMemberId)
                            .filter(id -> id != null && !id.isBlank())
                            .map(id -> this.userRepository.findByMemberId(id))
                            .filter(Objects::nonNull)
                            .findFirst()
                            .orElseThrow(() -> new IllegalStateException("No valid user found to bind with resident"));


                    // Build Resident
                    Resident resident = Resident.builder()
                            .apartment(apartment)
                            .area(area)
                            .user(finalUser)
                            .society(society)
                            .createdBy(loggedInId)
                            .tenantName(tenantName)
                            .tenantPhone(tenantPhone)
                            .tenantEmail(tenantEmail)
                            .ownerName(ownerName)
                            .ownerPhone(ownerPhone)
                            .ownerEmail(ownerEmail)
                            .tenantMemberId(tenantMemberId)
                            .ownerMemberId(ownerMemberId)
                            .residentType(AppConstants.ResidentType.TENANT)
                            .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
                            .roles(AppConstants.RoleTitle.resident)
                            .password(passwordEncoder.encode("1234"))
                            .possessionDate(possessionDate)
                            .build();

                    residents.add(resident);

                } catch (Exception e) {
                    errorLogs.add("Row %d: Unexpected error - %s".formatted(rowNum, e.getMessage()));
                }
            }
        }

        errorLogs.forEach(loggerService::logInfo);
        Set<ViewResidentDto> safeResponseDtos = residents.stream()
                .map(r -> modelMapper.map(r, ViewResidentDto.class))
                .collect(Collectors.toSet());

        return UploadDto.builder()
                .records(residents)
                .errors(errorLogs)
                .uploadSummary("Uploaded " + safeResponseDtos.size() + " residents successfully.")
                .build();
    }


    private String getStringCellValue(Row row, int columnIndex, FormulaEvaluator evaluator) {
        Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
        if (cell == null) {
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return String.valueOf((int) cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return getFormulaCellValue(cell, evaluator);
            case BLANK:
            default:
                return "";
        }
    }

    private String getFormulaCellValue(Cell cell, FormulaEvaluator evaluator) {
        CellValue cellValue = evaluator.evaluate(cell);
        return switch (cellValue.getCellType()) {
            case STRING -> cellValue.getStringValue().trim();
            case NUMERIC -> String.valueOf((int) cellValue.getNumberValue()); // Handle numeric formulas
            case BOOLEAN -> String.valueOf(cellValue.getBooleanValue());
            default -> "";
        };
    }

    private String generateSocietyCode(String societyName) {
        StringBuilder code = new StringBuilder();
        for (String word : societyName.trim().split("\\s+")) {
            code.append(Character.toUpperCase(word.charAt(0)));
        }
        return code.toString();
    }

    private String generateUniqueSocietyCode(String societyName) {
        String baseCode = generateSocietyCode(societyName);
        String finalCode = baseCode;
        int count = 1;

        while (societyRepository.existsBySocietyCode(finalCode)) {
            finalCode = baseCode + count;
            count++;
        }

        return finalCode;
    }


    @Override
    @Transactional
    public String addSociety(AddSocietyDto addSocietyDto) {
        try {
            Optional<Society> existingSociety = this.societyRepository.findBySocietyEmail(addSocietyDto.getSocietyEmail());
            if (existingSociety.isPresent()) {
                throw new EmailAlreadyExitException("EmailId already registered with another society");
            }
            Society society = this.modelMapper.map(addSocietyDto, Society.class);
            society.setSocietyId(UUID.randomUUID().toString());
            // Generate unique society code
            String uniqueCode = generateUniqueSocietyCode(addSocietyDto.getSocietyName());
            society.setSocietyCode(uniqueCode);
            this.societyRepository.save(society);
            return null;
        } catch (Exception ex) {
            return ex.getMessage();
        }
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public UploadDto uploadFile(long societyId, long typeId, MultipartFile file) throws IOException {
        Society society = this.societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found with ID: " + societyId));
        UploadDto uploadResult = switch ((int) typeId) {
            case 1 -> processAreaUpload(file, society);
            case 2 -> processApartmentUpload(file, society);
            case 3 -> processResidentUpload(file, society);
            default -> throw new IllegalArgumentException("Invalid typeId: " + typeId);
        };
        if (!uploadResult.getRecords().isEmpty()) {
            saveRecords(uploadResult.getRecords(), typeId);
        }
        String uploadSummary = generateUploadSummary(uploadResult, typeId);
        uploadResult.setUploadSummary(uploadSummary);
        return uploadResult;
    }

    //    private Set<Resident> parseResidentExcel(MultipartFile file, Society society) throws IOException {
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
//        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
//        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
//            Sheet sheet = workbook.getSheetAt(0); // Assume first sheet contains data
//            Iterator<Row> rowIterator = sheet.iterator();
//            // Skip header row
//            if (rowIterator.hasNext()) rowIterator.next();
//            Set<Resident> residents = new HashSet<>();
//            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
//            while (rowIterator.hasNext()) {
//                Row row = rowIterator.next();
//                // Read & Trim values
//                String block = getStringCellValue(row, 0,evaluator);
//                String flat = getStringCellValue(row, 1,evaluator);
//                String accommodationType = getStringCellValue(row, 2,evaluator);
//                String tenantName = getStringCellValue(row, 3,evaluator);
//                String tenantPhone = getStringCellValue(row, 4,evaluator);
//                String tenantEmail = getStringCellValue(row, 5,evaluator);
//                String primaryOwnerPhone = getStringCellValue(row, 6,evaluator);
//                String primaryTenantPhone = getStringCellValue(row, 7,evaluator);
//                String blank = getStringCellValue(row, 8,evaluator);
//                String meterId = getStringCellValue(row, 9,evaluator);
//                String consumerId = getStringCellValue(row, 10,evaluator);
//                String sanctionedLoadKW = getStringCellValue(row, 11,evaluator);
//                String sanctionedDGLoadKV = getStringCellValue(row, 12,evaluator);
//                String numberPipedGasUser = getStringCellValue(row, 13,evaluator);
//                String possessionDateStr = getStringCellValue(row, 14,evaluator);
////                String ownerName = getStringCellValue(row, 15);
////                String ownerPhone = getStringCellValue(row, 16);
////                String ownerEmail = getStringCellValue(row, 17);
//
//
//
//                // Fetch area & apartment
//                Area area = this.areaRepository.findBySocietyAndArea(society, block)
//                        .orElseThrow(() -> new ResourceNotFoundException("Area Not Found block: "+block));
//
//                Apartment apartment = this.apartmentRepository.findByAreaAndFlat(area, flat)
//                        .orElseThrow(() -> new ResourceNotFoundException("Apartment Not Found for block: " + block + "flat: " + flat));
//
//                if (this.residentRepository.existsByTenantEmailAndAreaAndApartmentAndSociety(tenantEmail, area, apartment, society)) {
//                    continue; // Skip duplicate record
//                }
//
//                LocalDateTime possessionDate = null;
//                if (possessionDateStr != null && !possessionDateStr.isBlank()) {
//                    try {
//                        possessionDate = LocalDateTime.parse(possessionDateStr, formatter);
//                    } catch (DateTimeParseException e) {
//                        throw new CsvParsingException("Invalid date format: " + possessionDateStr);
//                    }
//                }
//
//
//                // Check if user already exists
//                String ownerMemberId = null;
//                String tenantMemberId = null;
//
////                Optional<User> existingOwnerUser = this.userRepository.findByEmail(ownerEmail);
//                Optional<User> existingTenantUser = this.userRepository.findByEmail(tenantEmail);
////                if (existingOwnerUser.isEmpty()) {
////                    ownerMemberId=AppHelper.generateUniqueId();
////                    User newUser = User.builder()
////                            .email(ownerEmail)
////                            .contactNumber(ownerPhone)
////                            .society(society)
////                            .password(passwordEncoder.encode("1234"))
////                            .name(ownerName)
////                            .status(true)
////                            .roles(Set.of(this.roleRepository.findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
////                                    .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"))))
////                            .memberId(ownerMemberId)
////                            .residentType(AppConstants.ResidentType.OWNER)
////                            .build();
////                    this.userRepository.save(newUser);
////                }
//                if (existingTenantUser.isEmpty()) {
//                    tenantMemberId = AppHelper.generateUniqueId();
//                    User u = User.builder()
//                            .email(tenantEmail)
//                            .contactNumber(tenantPhone)
//                            .society(society)
//                            .password(passwordEncoder.encode("1234"))
//                            .name(tenantName)
//                            .status(true)
//                            .roles(Set.of(this.roleRepository.findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
//                                    .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"))))
//                            .memberId(tenantMemberId)
//                            .residentType(AppConstants.ResidentType.TENANT)
//                            .build();
//                    this.userRepository.save(u);
//                } else {
//                    tenantMemberId = existingTenantUser.get().getMemberId();
//                }
//
//                // Create resident object
//                Resident resident = Resident.builder()
////                        .ownerName(ownerName)
////                        .ownerPhone(ownerPhone)
////                        .ownerEmail(ownerEmail)
//                        .possessionDate(possessionDate)
//                        .createdBy(loggedInId)
//                        .roles(AppConstants.RoleTitle.resident)
//                        .user(this.userRepository.findByMemberId(tenantMemberId))//
//                        .apartment(apartment)
//                        .area(area)
//                        .society(society)
//                        .password(passwordEncoder.encode("1234"))
//                        .bhk(null)
//                        .sqFeetArea(null)
//                        .ownerSecondaryPhone(null)
//                        .tenantName(tenantName)
//                        .tenantPhone(tenantPhone)
//                        .tenantSecondaryPhone(null)
//                        .tenantEmail(tenantEmail)
//                        .residentType(null)
//                        .parking(false)
//                        .accommodationType(accommodationType)
//                        .primaryOwnerPhone(primaryOwnerPhone)
//                        .primaryTenantPhone(primaryTenantPhone)
//                        .meterId(meterId)
//                        .consumerId(consumerId)
//                        .sanctionedLoadKW(sanctionedLoadKW)
//                        .sanctionedDGLoadKV(sanctionedDGLoadKV)
//                        .numberPipedGasUsers(numberPipedGasUser.isBlank() ? null : Integer.parseInt(numberPipedGasUser))
//                        .ownerMemberId(null)
//                        .tenantMemberId(tenantMemberId)
//                        .build();
//                residents.add(resident);
//            }
//            return residents;
//        }
//    }
    @Override
    public PaginationDto<ViewResidentDto> getResidents(int pageNumber, int pageSize, String sortBy, String
            sortDir, String searchText, long societyId) {
        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }
        this.societyRepository.findById(societyId).orElseThrow(() -> new ResourceNotFoundException("Society Not Found"));
        Sort.Direction direction = Sort.Direction.fromString(sortDir);
        PageRequest pageable = PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));
        Page<Resident> pageResidentList;
        if (searchText != null && !searchText.trim().isEmpty()) {
            pageResidentList = this.residentRepository.findBySearchText(searchText, pageable);
        } else {
            pageResidentList = this.residentRepository.findResidentBySocietyId(societyId, pageable);
        }
        List<ViewResidentDto> viewResidentDtoList = pageResidentList.getContent()
                .stream()
                .map(res -> modelMapper.map(res, ViewResidentDto.class))
                .toList();
        PaginationDto<ViewResidentDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(viewResidentDtoList);
        paginationDto.setPageNumber(pageResidentList.getNumber());
        paginationDto.setPageSize(pageResidentList.getSize());
        paginationDto.setTotalPages(pageResidentList.getTotalPages());
        paginationDto.setTotalElements(pageResidentList.getTotalElements());
        paginationDto.setLastPage(pageResidentList.isLast());
        return paginationDto;
    }

    @Override
    public PaginationDto<GetApartmentDto> getApartments(int pageNumber, int pageSize, String sortBy, String
            sortDir, String searchText, long societyId) {
        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }
        this.societyRepository.findById(societyId).orElseThrow(() -> new ResourceNotFoundException("Society Not Found"));
        Sort.Direction direction = Sort.Direction.fromString(sortDir);
        PageRequest pageable = PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));
        Page<Apartment> pageResidentList;
        if (searchText != null && !searchText.trim().isEmpty()) {
            pageResidentList = this.apartmentRepository.findBySearchText(searchText, pageable);
        } else {
            Specification<Apartment> spec = Specification
                    .where(hasSocietyId(societyId))
                    .and(withActiveResidentsOnly());
            pageResidentList = apartmentRepository.findAll(spec, pageable);
//            pageResidentList = this.apartmentRepository.findApartmentBySocietyId(societyId, pageable);
        }
        List<GetApartmentDto> getApartmentDtoList = pageResidentList.getContent()
                .stream()
                .map(res -> modelMapper.map(res, GetApartmentDto.class))
                .toList();
        PaginationDto<GetApartmentDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(getApartmentDtoList);
        paginationDto.setPageNumber(pageResidentList.getNumber());
        paginationDto.setPageSize(pageResidentList.getSize());
        paginationDto.setTotalPages(pageResidentList.getTotalPages());
        paginationDto.setTotalElements(pageResidentList.getTotalElements());
        paginationDto.setLastPage(pageResidentList.isLast());
        return paginationDto;
    }

    @Override
    public List<ViewSocietyDto> getSocaityList() {
        User loggedInUser = customUserDetailService.LoggedInUser();
        long roleId = AppConstants.RoleConstant.MASTER_ACCESS_USER;
        String memberId = loggedInUser.getMemberId();
        Optional<UserRoleMapping> masterRoles = loggedInUser
                .getUserRoleMappings().stream()
                .filter(x -> x.getRole().getId() == AppConstants.RoleConstant.MASTER_ACCESS_USER)
                .findAny();
        Optional<UserRoleMapping> superAdminRoles = loggedInUser
                .getUserRoleMappings().stream()
                .filter(x -> x.getRole().getId() == AppConstants.RoleConstant.SUPERADMIN_USER)
                .findAny();
        Optional<UserRoleMapping> adminRoles = loggedInUser
                .getUserRoleMappings().stream()
                .filter(x -> x.getRole().getId() == AppConstants.RoleConstant.ADMIN_USER)
                .findAny();
        Optional<UserRoleMapping> staffRoles = loggedInUser
                .getUserRoleMappings().stream()
                .filter(x -> x.getRole().getId() == AppConstants.RoleConstant.STAFF_USER)
                .findAny();
        if (masterRoles.isPresent()) {
            roleId = masterRoles.get().getRole().getId();
        } else if (superAdminRoles.isPresent()) {
            roleId = superAdminRoles.get().getRole().getId();
        } else if (adminRoles.isPresent()) {
            roleId = adminRoles.get().getRole().getId();
        } else if (staffRoles.isPresent()) {
            roleId = staffRoles.get().getRole().getId();
        }

        List<Society> societies;
        if (roleId == AppConstants.RoleConstant.MASTER_ACCESS_USER) {
            societies = this.societyRepository.findBySocietyType(SocietyType.PUBLISH);
        } else {
            societies = societyRepository.findAll(SocietySpecification.leftJoinResidentsWithUMemberIdAndSocietyType(memberId, SocietyType.PUBLISH));
        }
        return societies
                .stream()
                .map(society -> this.modelMapper.map(society, ViewSocietyDto.class))
                .toList();
    }

    @Override
    public List<ViewAreaDto> getAreaList(long societyId, String searchText) {
        User loggedInUser = customUserDetailService.LoggedInUser();
        Society society = this.societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found!"));
        List<Area> areaList;
        if (searchText == null || searchText.trim().isEmpty()) {
            areaList = this.areaRepository.findBySociety(society);
        } else {
            areaList = this.areaRepository.findAll(AreaSpecification.searchByText(searchText, societyId));
        }
        return areaList.stream()
                .map(ar -> this.modelMapper.map(ar, ViewAreaDto.class))
                .toList();
    }

    @Override
    public List<ViewApartmentDto> getApartmentList(long societyId, long areaId, String searchText) {
        User loggedInUser = customUserDetailService.LoggedInUser();
        Society society = this.societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found!"));
        Area area = this.areaRepository.findById(areaId)
                .orElseThrow(() -> new ResourceNotFoundException("Area not found!"));
        List<Apartment> apartments;
        if (searchText == null || searchText.trim().isEmpty()) {
            apartments = this.apartmentRepository.findByAreaAndSociety(area, society);
        } else {
            apartments = this.apartmentRepository.findAll(ApartmentSpecification.searchByText(searchText, societyId, areaId));
        }
        return apartments.stream()
                .map(ar -> this.modelMapper.map(ar, ViewApartmentDto.class))
                .toList();
    }

    @Override
    public List<ViewComplainerDto> getResidentList(long societyId, long areaId, long apartmentId, String searchText) {
        User loggedInUser = customUserDetailService.LoggedInUser();
        Society society = this.societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found!"));
        Area area = this.areaRepository.findById(areaId)
                .orElseThrow(() -> new ResourceNotFoundException("Area not found!"));
        Apartment apartment = this.apartmentRepository.findById(apartmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Apartment not found!"));
        List<Resident> residents;
        if (searchText == null || searchText.trim().isEmpty()) {
            residents = this.residentRepository.findByAreaAndSocietyAndApartment(area, society, apartment);
        } else {
            residents = this.residentRepository.findAll(ResidentSpecification.searchByText(searchText, societyId, areaId, apartmentId));
        }
        return residents.stream()
                .map(ar -> this.modelMapper.map(ar, ViewComplainerDto.class))
                .toList();
    }

    @Override
    public List<ViewApartmentDto> getApartmentList(long societyId, String searchText) {
        Society society = this.societyRepository.findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found!"));
        List<Apartment> apartments;
        if (searchText == null || searchText.trim().isEmpty()) {
            apartments = this.apartmentRepository.findBySociety(society);
        } else {
            apartments = this.apartmentRepository.findAll(ApartmentSpecification.searchByTextAndSocietyId(searchText, societyId));
        }
        return apartments.stream()
                .map(ar -> this.modelMapper.map(ar, ViewApartmentDto.class))
                .toList();
    }

    @Override
    @Transactional
    public String sendComments(SendCommentsDto sendCommentsDto) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            Society society = this.societyRepository.findById(sendCommentsDto.getSocietyId())
                    .orElseThrow(() -> new ResourceNotFoundException("Society No found"));

            User user = this.userRepository.findById(loggedInId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found", "", loggedInId + ""));

            Complaint complaint = this.complaintRepository.findById(sendCommentsDto.getComplaintId())
                    .orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));

            CommentMaster commentMaster = modelMapper.map(sendCommentsDto, CommentMaster.class);
            commentMaster.setSociety(society);
            commentMaster.setCommentBy(loggedInId);
            commentMaster.setUserType(sendCommentsDto.getUserType());
            commentMaster.setComplaint(complaint);
            commentMaster.setComments(sendCommentsDto.getComments());

            CommentMaster savedComment = this.commentMasterRepository.save(commentMaster);

            if (savedComment.getId() != 0) {
                // Asynchronous notification sending (will not affect transaction even if it fails)
                complaint.getComplainer().getUserRoleMappings().stream()
                        .filter(mapping -> mapping.getRole().getId() == AppConstants.RoleConstant.RESIDENTIAL_USER)
                        .findFirst()
                        .ifPresent(mapping -> {
                            User assignedUser = mapping.getUser();
                            String notificationTitle = "Someone replied to your comment";
                            String notificationBody = String.format(
                                    "You have received a new reply on your complaint #%d from %s. View the discussion now.",
                                    complaint.getId(), user.getName());

                            try {
                                _notificationService.sendNotificationToUser(assignedUser, notificationTitle, notificationBody);
                            } catch (Exception e) {
                                // Log but do not rethrow
                                log.warn("Failed to trigger async notification: {}", e.getMessage());
                            }
                        });

                return null;
            } else {
                return "Comment not added";
            }

        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while adding comment");
        } catch (Exception ex) {
            return ex.getMessage();
        }
    }


    @Override
    @Transactional
    public String sendCommentsWithImage(SendCommentsDto sendCommentsDto, List<MultipartFile> imageFiles) throws IOException, SQLIntegrityConstraintViolationException {
        try {
            User loggedInUser = customUserDetailService.LoggedInUser();
            Society society = this.societyRepository.findById(sendCommentsDto.getSocietyId()).orElseThrow(() -> new ResourceNotFoundException("Society No found"));
            User user = this.userRepository
                    .findById(loggedInUser.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("User not found", "", loggedInUser.getId() + ""));
            Complaint complaint = this.complaintRepository.findById(sendCommentsDto.getComplaintId()).orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));
            CommentMaster commentMaster = modelMapper.map(sendCommentsDto, CommentMaster.class);
            commentMaster.setSociety(society);
            commentMaster.setCommentBy(loggedInUser.getId());
            commentMaster.setUserType(sendCommentsDto.getUserType());
            commentMaster.setComplaint(complaint);
            commentMaster.setComments(sendCommentsDto.getComments());
            List<CommentImage> uploadedImages = imageUpload(imageFiles, commentMaster);
            commentMaster.setImages(uploadedImages);
            commentMaster.setImageUrl(null);
            CommentMaster commentMaster1 = this.commentMasterRepository.save(commentMaster);
            if (commentMaster1.getId() != 0) {
                // Asynchronous notification sending (will not affect transaction even if it fails)
//                complaint.getComplainer().getUserRoleMappings().stream()
//                        .filter(mapping -> mapping.getRole().getId() == AppConstants.RoleConstant.RESIDENTIAL_USER)
//                        .findFirst()
//                        .ifPresent(mapping -> {
//                            User assignedUser = mapping.getUser();
//                            String notificationTitle = "Complaint Update";
//                            String notificationBody = String.format(
//                                    "You have received a new reply on your complaint #%d from %s. View the discussion now.",
//                                    complaint.getId(), user.getName());
//
//                            try {
//                                _notificationService.sendNotificationToUser(assignedUser, notificationTitle, notificationBody);
//                            } catch (Exception e) {
//                                log.warn("Failed to trigger async notification with image: {}", e.getMessage());
//                            }
//                        });
                Area area = this.areaRepository.findById(complaint.getAreaId()).orElseThrow(() -> new ResourceNotFoundException("Area Not Found"));
                Apartment apartment = this.apartmentRepository.findById(complaint.getApartmentId()).orElseThrow(() -> new ResourceNotFoundException("Apartment Not Found"));
                List<User> receivers = this.residentRepository.findByAreaAndSocietyAndApartment(area, society, apartment)
                        .stream()
                        .filter(resident -> resident.getUser() != null && resident.getUser().getId() != loggedInUser.getId())
                        .map(Resident::getUser)
                        .distinct()
                        .toList();
                try {
                    _notificationService.sendNotificationToUsers(receivers, "New Comment Added", String.format(
                            "A new comment has been added to complaint #%d by %s. Check it out!",
                            complaint.getId(), user.getName()));
                } catch (Exception e) {
                    log.warn("Failed to trigger async notification with data: {}", e.getMessage());
                }

                return null;
            } else {
                return "Comments not added";
            }
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while adding category");
        } catch (Exception ex) {
            return ex.getMessage();
        }
    }

    @Async
    private List<CommentImage> imageUpload(List<MultipartFile> files, CommentMaster commentMaster) throws IOException {
        String fileDownloadUri = "";
        List<CommentImage> imageEntityList = new ArrayList<>();
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (!file.isEmpty()) {
                    s3FileHandler.validateFile(file);
                    String uniqueFileName = s3FileHandler.storeFile(file);
                    URL filePath = s3FileHandler.getFilePath(uniqueFileName);
                    if (!uniqueFileName.isEmpty()) {
                        fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                                .path("/api/v1/master/image/")
                                .path(uniqueFileName)
                                .toUriString();
                    }
                    CommentImage commentImage = CommentImage.builder()
                            .imageName(uniqueFileName)
                            .awsUrl(filePath.toString())
                            .imageUrl(fileDownloadUri)
                            .imageSize(file.getSize())
                            .imageType(file.getContentType())
                            .imageCategory("COMPLAINT")
                            .comment(commentMaster)
                            .build();
                    imageEntityList.add(commentImage);
                }
            }
        }
        return imageEntityList;
    }


    @Override
    public List<ViewCommentsDto> getCommentList(long complaintId) {
        List<CommentMaster> commentMasterList = this.commentMasterRepository.findByComplaintIdAndIsDelete(complaintId, false);
        List<ViewCommentsDto> viewCommentsDtos = commentMasterList.stream()
                .map(commentMaster -> {
                    ViewCommentsDto dto = modelMapper.map(commentMaster, ViewCommentsDto.class);
                    Society society = commentMaster.getSociety();
                    if (society != null) {
                        dto.setSocietyId(society.getId());
                    }
                    return dto;
                })
                .toList();

        return viewCommentsDtos.stream().peek(commentMaster -> {
            if (commentMaster.getUserType().equalsIgnoreCase("User")) {
                User u = this.userRepository
                        .findById(commentMaster.getCommentBy())
                        .orElseThrow(() -> new ResourceNotFoundException("User Not Found"));
                String role = u.getUserRoleMappings()
                        .stream()
                        .filter(f -> f.getSociety() != null && f.getSociety().getId() == commentMaster.getSocietyId())
                        .findFirst().filter(f -> f.getRole() != null).map(f -> f.getRole().getTitle()).orElse("Unknown");

                Person p = Person
                        .builder()
                        .name(u.getName())
                        .id(u.getId())
                        .email(u.getEmail())
                        .authorRole(role)
                        .profileUrl(u.getProfileUrl()).build();
                commentMaster.setPerson(p);
            } else if (commentMaster.getUserType().equalsIgnoreCase("Resident")) {
                Resident r = this.residentRepository
                        .findById(commentMaster.getCommentBy())
                        .orElseThrow(() -> new ResourceNotFoundException("Resident Not Found"));
                User ur = this.userRepository.findByEmail(r.getOwnerEmail()).orElseThrow(() -> new ResourceNotFoundException("user not found"));
                Person p = Person
                        .builder()
                        .name(r.getOwnerName())
                        .id(r.getId())
                        .email(r.getOwnerEmail())
                        .profileUrl(ur.getProfileUrl())
                        .authorRole("Resident")
                        .build();
                commentMaster.setPerson(p);
            }
        }).toList();
    }

    public List<ResidentSocietyDetailDto> getResidentDetailsByOwnerEmail_old(String ownerEmail) {
//        Optional<Role> role = customUserDetailService.LoggedInUser().getUserRoleMappings().stream().findFirst().get().getRole();
        Optional<UserRoleMapping> roleMap = customUserDetailService.LoggedInUser().getUserRoleMappings().stream().findFirst();
        Role role = null;
        if (roleMap.isPresent()) {
            role = roleMap.get().getRole();
        }
        assert role != null;
        long roleId = role.getId();//role.map(Role::getId).orElse(0L);
        List<ResidentSocietyDetailDto> residentDetails;
        if (roleId == AppConstants.RoleConstant.MASTER_ACCESS_USER) {
            residentDetails = this.residentRepository.getSocietyListForMaster(AppConstants.SocietyApartmentArea.FIRST_SOCIETY, AppConstants.SocietyApartmentArea.FIRST_FLAT_BLOCK, AppConstants.SocietyApartmentArea.FIRST_FLAT_BLOCK);
        } else if (roleId != AppConstants.RoleConstant.RESIDENTIAL_USER) {
            residentDetails = this.residentRepository.getSocietyListForResident_old(ownerEmail, AppConstants.SocietyApartmentArea.FIRST_SOCIETY, AppConstants.SocietyApartmentArea.FIRST_FLAT_BLOCK, AppConstants.SocietyApartmentArea.FIRST_FLAT_BLOCK);
//            residentDetails = resident.stream().map(r -> this.modelMapper.map(r, ViewApartmentOfResidentsDto.class)
//           ).toList();

        } else {
            residentDetails = this.residentRepository.getSocietyListForAll(ownerEmail);
        }
        return residentDetails;
    }

    public List<ViewApartmentOfResidentsDto> getApartmentListOfResident(String email) {
        Optional<UserRoleMapping> adminRole = customUserDetailService.LoggedInUser()
                .getUserRoleMappings().stream()
                .filter(x -> x.getRole().getId() == AppConstants.RoleConstant.ADMIN_USER)
                .findAny();
        Optional<UserRoleMapping> superAdminRole = customUserDetailService.LoggedInUser()
                .getUserRoleMappings().stream()
                .filter(x -> x.getRole().getId() == AppConstants.RoleConstant.SUPERADMIN_USER)
                .findAny();
        Optional<UserRoleMapping> residentRole = customUserDetailService.LoggedInUser()
                .getUserRoleMappings().stream()
                .filter(x -> x.getRole().getId() == AppConstants.RoleConstant.RESIDENTIAL_USER)
                .findAny();
        if (residentRole.isEmpty())
            throw new AuthException("User does not have the required Residential User role");
        else {
            List<Resident> residents = this.residentRepository.getSocietyListForResident(
                    email,
                    AppConstants.SocietyApartmentArea.FIRST_SOCIETY,
                    AppConstants.SocietyApartmentArea.FIRST_FLAT_BLOCK,
                    AppConstants.SocietyApartmentArea.FIRST_FLAT_BLOCK
            );

            return residents.stream()
                    .map(r -> {
                        var viewResident = modelMapper.map(r, ViewApartmentOfResidentsDto.class);

                        String ownerEmail = r.getOwnerEmail();
                        String tenantEmail = r.getTenantEmail();

                        if (ownerEmail != null && ownerEmail.contains(email)) {
                            viewResident.setResidentType("Owner");
                        } else if (tenantEmail != null && tenantEmail.contains(email)) {
                            viewResident.setResidentType("Tenant");
                        }

                        return viewResident;
                    })
                    .toList();

        }
    }

    private void validateOwnerTenantConflict(String email, Apartment apartment, Area area, Society society) throws ServiceException {
        // check owner existing
        boolean existsAsOwner = residentRepository.existsByOwnerEmailAndApartmentAndAreaAndSociety(
                email, apartment, area, society);

        if (existsAsOwner) {
            throw new ServiceException("This email is already an Owner in this flat");
        }
        // check tenant existing
        boolean existsAsTenant = residentRepository.existsByTenantEmailAndApartmentAndAreaAndSociety(
                email, apartment, area, society);

        if (existsAsTenant) {
            throw new ServiceException("This email is already a Tenant in this flat");
        }
    }


    @Override
    @Transactional
    public String manageResidentSocietyAndBlockWise(ManageResidentDto manageResidentDto) throws ServiceException {

        Role residentRole = this.roleRepository
                .findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
                .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"));

        long loggedInId = this.customUserDetailService.LoggedInUser().getId();
        boolean hasNonZeroId = manageResidentDto.getResidents().stream()
                .anyMatch(resident -> resident.getId() != 0);

        // Helper lambda to ensure user + mapping exists and return the user
        BiFunction<String, String, User> ensureUserAndMapping = (email, mobile) -> {
            Optional<User> existingUserOpt = this.userRepository.findByEmail(email);
            User u;
            if (existingUserOpt.isEmpty()) {
                u = User.builder()
                        .email(email)
                        .contactNumber(mobile)
                        .password(passwordEncoder.encode("1234"))
                        .name("") // caller should update name on user save if needed
                        .status(true)
                        .memberId(AppHelper.generateUniqueId())
                        .build();
                this.userRepository.save(u);
            } else {
                u = existingUserOpt.get();
            }
            // Ensure UserRoleMapping exists for this society/role
            return u;
        };

        if (hasNonZeroId) {
            // We have at least one existing resident id => this request is likely editing/deleting/
            // adding relative to an existing resident. Find one existing resident to reuse base data.
            Optional<Long> nonZeroIdOpt = manageResidentDto.getResidents().stream()
                    .map(CommonResidentDto::getId)
                    .filter(id -> id != 0)
                    .findFirst();


            Resident baseResident = this.residentRepository
                    .findById(nonZeroIdOpt.orElseThrow(() -> new ResourceNotFoundException("non zero id not present")))
                    .orElseThrow(() -> new ResourceNotFoundException("Resident not found!"));


            // For each incoming item process mode
            for (CommonResidentDto residentDto : manageResidentDto.getResidents()) {

                Apartment ap = baseResident.getApartment();
                Area ar = baseResident.getArea();
                Society so = baseResident.getSociety();

                validateOwnerTenantConflict(residentDto.getEmail(), ap, ar, so);

                String mode = residentDto.getMode();
                if ("DELETE".equalsIgnoreCase(mode)) {
                    Resident existingResidentToDelete = this.residentRepository
                            .findById(residentDto.getId())
                            .orElseThrow(() -> new ResourceNotFoundException("Resident not found!"));
                    existingResidentToDelete.setDelete(true);
                    existingResidentToDelete.setDeletedAt(LocalDateTime.now());
                    existingResidentToDelete.setDeleteBy(loggedInId);
                    this.residentRepository.save(existingResidentToDelete);
                    // (commented out user soft-delete left as in your original)
                } else if ("ADD".equalsIgnoreCase(mode)) {
                    // Try to find an existing Resident row for same apartment where complementary fields are empty
                    Apartment apartment = baseResident.getApartment();
                    Area area = baseResident.getArea();
                    Society society = baseResident.getSociety();

                    // NOTE: ensure your ResidentRepository exposes a method to fetch by apartment (and optionally area/society)
                    // e.g. List<Resident> findByApartment(Apartment apartment);
                    List<Resident> residentsForFlat = this.residentRepository.findByApartment(apartment);

                    boolean addedOrUpdated = false;

                    if (AppConstants.ResidentType.TENANT.equalsIgnoreCase(residentDto.getResidentType())) {
                        // look for an existing row where tenantEmail is null/empty but owner exists
                        for (Resident r : residentsForFlat) {
                            boolean tenantEmpty = (r.getTenantEmail() == null || r.getTenantEmail().trim().isEmpty());
                            if (tenantEmpty) {
                                // fill tenant fields in this row
                                r.setTenantEmail(residentDto.getEmail());
                                r.setTenantName(residentDto.getName());
                                r.setTenantPhone(residentDto.getMobileNo());
                                r.setTenantMemberId(r.getTenantMemberId() == null ? AppHelper.generateUniqueId() : r.getTenantMemberId());
                                r.setResidentType(AppConstants.ResidentType.TENANT); // note: residentType on row could be a general tag
                                r.setModifyBy(loggedInId);
//                                    r.setUpdatedAt();
                                // set associated user if exists or create user
                                Optional<User> existingTenantUser = this.userRepository.findByEmail(residentDto.getEmail());
                                User userToAttach = existingTenantUser.orElseGet(() -> {
                                    User u = User.builder()
                                            .email(residentDto.getEmail())
                                            .contactNumber(residentDto.getMobileNo())
                                            .password(passwordEncoder.encode("1234"))
                                            .name(residentDto.getName())
                                            .status(true)
                                            .memberId(r.getTenantMemberId())
                                            .residentType(AppConstants.ResidentType.TENANT)
                                            .build();
                                    this.userRepository.save(u);
                                    return u;
                                });
                                r.setUser(userToAttach);

                                // ensure mapping exists
                                boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(userToAttach, residentRole, society);
                                if (!mappingExists) {
                                    UserRoleMapping m = UserRoleMapping.builder()
                                            .user(userToAttach)
                                            .role(residentRole)
                                            .society(society)
                                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                            .build();
                                    this._userRoleMappingRepository.save(m);
                                }

                                this.residentRepository.save(r);
                                addedOrUpdated = true;
                                break;
                            }
                        }

                        if (!addedOrUpdated) {
                            // no suitable existing row — create a new row copying from baseResident where useful
                            Resident newRes = Resident.builder()
                                    .tenantEmail(residentDto.getEmail())
                                    .tenantName(residentDto.getName())
                                    .tenantPhone(residentDto.getMobileNo())
                                    .possessionDate(baseResident.getPossessionDate())
                                    .createdBy(loggedInId)
                                    .roles(baseResident.getRoles())
                                    .user(baseResident.getUser())
                                    .apartment(baseResident.getApartment())
                                    .area(baseResident.getArea())
                                    .society(baseResident.getSociety())
                                    .password(baseResident.getPassword())
                                    .bhk(baseResident.getBhk())
                                    .sqFeetArea(baseResident.getSqFeetArea())
                                    .ownerSecondaryPhone(baseResident.getOwnerSecondaryPhone())
                                    .tenantSecondaryPhone(baseResident.getTenantSecondaryPhone())
                                    .residentType(AppConstants.ResidentType.TENANT)
                                    .parking(baseResident.getParking())
                                    .accommodationType(baseResident.getAccommodationType())
                                    .primaryOwnerPhone(baseResident.getPrimaryOwnerPhone())
                                    .primaryTenantPhone(baseResident.getPrimaryTenantPhone())
                                    .meterId(baseResident.getMeterId())
                                    .consumerId(baseResident.getConsumerId())
                                    .sanctionedLoadKW(baseResident.getSanctionedLoadKW())
                                    .sanctionedDGLoadKV(baseResident.getSanctionedDGLoadKV())
                                    .numberPipedGasUsers(baseResident.getNumberPipedGasUsers())
                                    .tenantMemberId(AppHelper.generateUniqueId())
                                    .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
                                    .build();
                            this.residentRepository.save(newRes);

                            // create or reuse user and mapping (same logic as above)
                            Optional<User> existingTenantUser = this.userRepository.findByEmail(residentDto.getEmail());
                            User u = existingTenantUser.orElseGet(() -> {
                                User nu = User.builder()
                                        .email(residentDto.getEmail())
                                        .contactNumber(residentDto.getMobileNo())
                                        .password(passwordEncoder.encode("1234"))
                                        .name(residentDto.getName())
                                        .status(true)
                                        .memberId(newRes.getTenantMemberId())
                                        .residentType(AppConstants.ResidentType.TENANT)
                                        .build();
                                this.userRepository.save(nu);
                                return nu;
                            });

                            boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, residentRole, society);
                            if (!mappingExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(u)
                                        .role(residentRole)
                                        .society(society)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }
                        }

                    } else if (AppConstants.ResidentType.OWNER.equalsIgnoreCase(residentDto.getResidentType())) {
                        // very similar to tenant logic but for owner fields
                        for (Resident r : residentsForFlat) {
                            boolean ownerEmpty = (r.getOwnerEmail() == null || r.getOwnerEmail().trim().isEmpty());
                            if (ownerEmpty) {
                                r.setOwnerEmail(residentDto.getEmail());
                                r.setOwnerName(residentDto.getName());
                                r.setOwnerPhone(residentDto.getMobileNo());
                                r.setOwnerMemberId(r.getOwnerMemberId() == null ? AppHelper.generateUniqueId() : r.getOwnerMemberId());
                                r.setResidentType(AppConstants.ResidentType.OWNER);
                                r.setModifyBy(loggedInId);
//                                    r.setModifyAt(LocalDateTime.now());

                                Optional<User> existingOwnerUser = this.userRepository.findByEmail(residentDto.getEmail());
                                User userToAttach = existingOwnerUser.orElseGet(() -> {
                                    User u = User.builder()
                                            .email(residentDto.getEmail())
                                            .contactNumber(residentDto.getMobileNo())
                                            .password(passwordEncoder.encode("1234"))
                                            .name(residentDto.getName())
                                            .status(true)
                                            .memberId(r.getOwnerMemberId())
                                            .residentType(AppConstants.ResidentType.OWNER)
                                            .build();
                                    this.userRepository.save(u);
                                    return u;
                                });
                                r.setUser(userToAttach);

                                boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(userToAttach, residentRole, society);
                                if (!mappingExists) {
                                    UserRoleMapping m = UserRoleMapping.builder()
                                            .user(userToAttach)
                                            .role(residentRole)
                                            .society(society)
                                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                            .build();
                                    this._userRoleMappingRepository.save(m);
                                }

                                this.residentRepository.save(r);
                                addedOrUpdated = true;
                                break;
                            }
                        }

                        if (!addedOrUpdated) {
                            Resident newRes = Resident.builder()
                                    .possessionDate(baseResident.getPossessionDate())
                                    .createdBy(loggedInId)
                                    .roles(baseResident.getRoles())
                                    .user(baseResident.getUser())
                                    .apartment(baseResident.getApartment())
                                    .area(baseResident.getArea())
                                    .society(baseResident.getSociety())
                                    .password(baseResident.getPassword())
                                    .bhk(baseResident.getBhk())
                                    .sqFeetArea(baseResident.getSqFeetArea())
                                    .ownerSecondaryPhone(baseResident.getOwnerSecondaryPhone())
                                    .tenantSecondaryPhone(baseResident.getTenantSecondaryPhone())
                                    .residentType(AppConstants.ResidentType.OWNER)
                                    .parking(baseResident.getParking())
                                    .accommodationType(baseResident.getAccommodationType())
                                    .primaryOwnerPhone(baseResident.getPrimaryOwnerPhone())
                                    .primaryTenantPhone(baseResident.getPrimaryTenantPhone())
                                    .meterId(baseResident.getMeterId())
                                    .consumerId(baseResident.getConsumerId())
                                    .sanctionedLoadKW(baseResident.getSanctionedLoadKW())
                                    .sanctionedDGLoadKV(baseResident.getSanctionedDGLoadKV())
                                    .numberPipedGasUsers(baseResident.getNumberPipedGasUsers())
                                    .ownerMemberId(AppHelper.generateUniqueId())
                                    .tenantMemberId(baseResident.getTenantMemberId())
                                    .ownerName(residentDto.getName())
                                    .ownerEmail(residentDto.getEmail())
                                    .ownerPhone(residentDto.getMobileNo())
                                    .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
                                    .build();
                            this.residentRepository.save(newRes);

                            Optional<User> existingOwnerUser = this.userRepository.findByEmail(residentDto.getEmail());
                            User u = existingOwnerUser.orElseGet(() -> {
                                User nu = User.builder()
                                        .email(residentDto.getEmail())
                                        .contactNumber(residentDto.getMobileNo())
                                        .password(passwordEncoder.encode("1234"))
                                        .name(residentDto.getName())
                                        .status(true)
                                        .memberId(newRes.getOwnerMemberId())
                                        .residentType(AppConstants.ResidentType.OWNER)
                                        .build();
                                this.userRepository.save(nu);
                                return nu;
                            });

                            boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, residentRole, society);
                            if (!mappingExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(u)
                                        .role(residentRole)
                                        .society(society)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }
                        }
                    }
                } else if ("EDIT".equalsIgnoreCase(mode)) {
                    Resident existingResident1 = this.residentRepository
                            .findById(residentDto.getId())
                            .orElseThrow(() -> new ResourceNotFoundException("Resident not found!"));
                    if (residentDto.getResidentType().equalsIgnoreCase(AppConstants.ResidentType.OWNER)) {
                        existingResident1.setOwnerPhone(residentDto.getMobileNo());
                        existingResident1.setOwnerName(residentDto.getName());
                        existingResident1.setOwnerEmail(residentDto.getEmail());
                    } else if (residentDto.getResidentType().equalsIgnoreCase(AppConstants.ResidentType.TENANT)) {
                        existingResident1.setTenantPhone(residentDto.getMobileNo());
                        existingResident1.setTenantName(residentDto.getName());
                        existingResident1.setTenantEmail(residentDto.getEmail());
                    }
                    this.residentRepository.save(existingResident1);

                    Optional<User> userOpt = this.userRepository.findByEmail(residentDto.getEmail());
                    if (userOpt.isPresent()) {
                        User user = userOpt.get();
                        user.setEmail(residentDto.getEmail());
                        user.setName(residentDto.getName());
                        user.setModifyBy(loggedInId);
                        user.setContactNumber(residentDto.getMobileNo());
                        this.userRepository.save(user);
                    } else {
                        User u = User.builder()
                                .email(residentDto.getEmail())
                                .contactNumber(residentDto.getMobileNo())
                                .password(passwordEncoder.encode("1234"))
                                .status(true)
                                .name(residentDto.getName())
                                .residentType(residentDto.getResidentType())
                                .memberId(residentDto.getResidentType().equalsIgnoreCase(AppConstants.ResidentType.TENANT) ? existingResident1.getTenantMemberId() : existingResident1.getOwnerMemberId())
                                .build();
                        this.userRepository.save(u);
                        // ensure mapping
                        Society society = existingResident1.getSociety();
                        boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, residentRole, society);
                        if (!roleExists) {
                            UserRoleMapping mapping = UserRoleMapping.builder()
                                    .user(u)
                                    .role(residentRole)
                                    .society(society)
                                    .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                    .build();
                            this._userRoleMappingRepository.save(mapping);
                        }
                    }
                }
            }
        } else {
            // All incoming residents are new (no non-zero id in request). Use their society/apartment/area ids
            for (CommonResidentDto residentDto : manageResidentDto.getResidents()) {
                String tenantMemberId = AppHelper.generateUniqueId();
                String ownerMemberId = AppHelper.generateUniqueId();

                Society existingSociety = this.societyRepository
                        .findById(residentDto.getSocietyId())
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found!"));
                Apartment existingApartment = this.apartmentRepository.findById(residentDto.getApartmentId())
                        .orElseThrow(() -> new ResourceNotFoundException("Apartment not found"));
                Area existingArea = this.areaRepository.findById(residentDto.getAreaId())
                        .orElseThrow(() -> new ResourceNotFoundException("Area not found"));

                // Fetch all resident rows for this apartment
                List<Resident> residentsForFlat = this.residentRepository.findByApartment(existingApartment);

                // check if any row has complementary slot empty (owner or tenant) and fill it
                boolean filledExistingRow = false;
                if (AppConstants.ResidentType.TENANT.equalsIgnoreCase(residentDto.getResidentType())) {
                    for (Resident r : residentsForFlat) {
                        boolean tenantEmpty = (r.getTenantEmail() == null || r.getTenantEmail().trim().isEmpty());
                        if (tenantEmpty) {
                            r.setTenantEmail(residentDto.getEmail());
                            r.setTenantName(residentDto.getName());
                            r.setTenantPhone(residentDto.getMobileNo());
                            r.setTenantMemberId(r.getTenantMemberId() == null ? tenantMemberId : r.getTenantMemberId());
                            this.residentRepository.save(r);

                            // ensure user + mapping
                            Optional<User> existingUser = this.userRepository.findByEmail(residentDto.getEmail());
                            User user = existingUser.orElseGet(() -> {
                                User nu = User.builder()
                                        .email(residentDto.getEmail())
                                        .contactNumber(residentDto.getMobileNo())
                                        .password(passwordEncoder.encode("1234"))
                                        .name(residentDto.getName())
                                        .status(true)
                                        .memberId(r.getTenantMemberId())
                                        .residentType(AppConstants.ResidentType.TENANT)
                                        .build();
                                this.userRepository.save(nu);
                                return nu;
                            });
                            boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, residentRole, existingSociety);
                            if (!mappingExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(user)
                                        .role(residentRole)
                                        .society(existingSociety)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }

                            filledExistingRow = true;
                            break;
                        }
                    }

                    if (!filledExistingRow) {
                        // create new resident row
                        Optional<User> existingUser = this.userRepository.findByEmail(residentDto.getEmail());
                        User user = null;
                        if (existingUser.isEmpty()) {
                            user = User.builder()
                                    .email(residentDto.getEmail())
                                    .contactNumber(residentDto.getMobileNo())
                                    .password(passwordEncoder.encode("1234"))
                                    .name(residentDto.getName())
                                    .status(true)
                                    .memberId(tenantMemberId)
                                    .residentType(AppConstants.ResidentType.TENANT)
                                    .build();
                            this.userRepository.save(user);

                            boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, residentRole, existingSociety);
                            if (!roleExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(user)
                                        .role(residentRole)
                                        .society(existingSociety)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }
                        } else {
                            User existUser = existingUser.get();
                            boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(existUser, residentRole, existingSociety);
                            if (!mappingExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(existUser)
                                        .role(residentRole)
                                        .society(existingSociety)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }
                            user = existUser;
                        }

                        Resident resident1 = Resident.builder()
                                .tenantEmail(residentDto.getEmail())
                                .tenantName(residentDto.getName())
                                .tenantPhone(residentDto.getMobileNo())
                                .createdBy(loggedInId)
                                .roles("Resident")
                                .user(user)
                                .apartment(existingApartment)
                                .area(existingArea)
                                .society(existingSociety)
                                .password(passwordEncoder.encode("1234"))
                                .bhk(existingApartment.getFlat())
                                .residentType(AppConstants.ResidentType.TENANT)
                                .tenantMemberId(tenantMemberId)
                                .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
                                .build();
                        this.residentRepository.save(resident1);
                    }
                } else if (AppConstants.ResidentType.OWNER.equalsIgnoreCase(residentDto.getResidentType())) {
                    for (Resident r : residentsForFlat) {
                        boolean ownerEmpty = (r.getOwnerEmail() == null || r.getOwnerEmail().trim().isEmpty());
                        if (ownerEmpty) {
                            r.setOwnerEmail(residentDto.getEmail());
                            r.setOwnerName(residentDto.getName());
                            r.setOwnerPhone(residentDto.getMobileNo());
                            r.setOwnerMemberId(r.getOwnerMemberId() == null ? ownerMemberId : r.getOwnerMemberId());
                            this.residentRepository.save(r);

                            Optional<User> existingUser = this.userRepository.findByEmail(residentDto.getEmail());
                            User user = existingUser.orElseGet(() -> {
                                User nu = User.builder()
                                        .email(residentDto.getEmail())
                                        .contactNumber(residentDto.getMobileNo())
                                        .password(passwordEncoder.encode("1234"))
                                        .name(residentDto.getName())
                                        .status(true)
                                        .memberId(r.getOwnerMemberId())
                                        .residentType(AppConstants.ResidentType.OWNER)
                                        .build();
                                this.userRepository.save(nu);
                                return nu;
                            });
                            boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, residentRole, existingSociety);
                            if (!mappingExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(user)
                                        .role(residentRole)
                                        .society(existingSociety)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }

                            filledExistingRow = true;
                            break;
                        }
                    }

                    if (!filledExistingRow) {
                        Optional<User> existingUser = this.userRepository.findByEmail(residentDto.getEmail());
                        User user = null;
                        if (existingUser.isEmpty()) {
                            user = User.builder()
                                    .email(residentDto.getEmail())
                                    .contactNumber(residentDto.getMobileNo())
                                    .password(passwordEncoder.encode("1234"))
                                    .name(residentDto.getName())
                                    .status(true)
                                    .memberId(ownerMemberId)
                                    .residentType(AppConstants.ResidentType.OWNER)
                                    .build();
                            this.userRepository.save(user);

                            boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, residentRole, existingSociety);
                            if (!roleExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(user)
                                        .role(residentRole)
                                        .society(existingSociety)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }
                        } else {
                            User existUser = existingUser.get();
                            boolean mappingExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(existUser, residentRole, existingSociety);
                            if (!mappingExists) {
                                UserRoleMapping mapping = UserRoleMapping.builder()
                                        .user(existUser)
                                        .role(residentRole)
                                        .society(existingSociety)
                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                                        .build();
                                this._userRoleMappingRepository.save(mapping);
                            }
                            user = existUser;
                        }

                        Resident resident1 = Resident.builder()
                                .ownerEmail(residentDto.getEmail())
                                .ownerName(residentDto.getName())
                                .ownerPhone(residentDto.getMobileNo())
                                .createdBy(loggedInId)
                                .roles("Resident")
                                .user(user)
                                .apartment(existingApartment)
                                .area(existingArea)
                                .society(existingSociety)
                                .password(passwordEncoder.encode("1234"))
                                .bhk(existingApartment.getFlat())
                                .residentType(AppConstants.ResidentType.OWNER)
                                .ownerMemberId(ownerMemberId)
                                .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
                                .build();
                        this.residentRepository.save(resident1);
                    }
                }
            }
        }

        return null;
    }


//    @Override
//    @Transactional
//    public String manageResidentSocietyAndBlockWise(ManageResidentDto manageResidentDto) {
//        try {
//            Role residentRole = this.roleRepository
//                    .findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
//                    .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"));
//
//            long loggedInId = this.customUserDetailService.LoggedInUser().getId();
//            boolean hasNonZeroId = manageResidentDto.getResidents().stream()
//                    .anyMatch(resident -> resident.getId() != 0);
//
//            if (hasNonZeroId) {
//                Optional<Long> nonZeroId = manageResidentDto.getResidents().stream()
//                        .map(CommonResidentDto::getId)
//                        .filter(id -> id != 0)
//                        .findFirst();
//
//                Resident existingResident = this.residentRepository
//                        .findById(nonZeroId.orElseThrow(() -> new ResourceNotFoundException("non zero id not present")))
//                        .orElseThrow(() -> new ResourceNotFoundException("Resident not found!"));
//                manageResidentDto.getResidents().forEach(resident -> {
//                    if (Objects.equals(resident.getMode(), "DELETE")) {
//                        Resident existingResident2 = this.residentRepository
//                                .findById(resident.getId())
//                                .orElseThrow(() -> new ResourceNotFoundException("Resident not found!"));
//                        existingResident2.setDelete(true);
//                        existingResident2.setDeletedAt(LocalDateTime.now());
//                        existingResident2.setDeleteBy(loggedInId);
//                        this.residentRepository.save(existingResident2);
////                        Optional<User> user = this.userRepository.findByEmail(resident.getEmail());
////                        if (user.isPresent()) {
////                            user.get().setDelete(true);
////                            user.get().setDeleteBy(loggedInId);
////                            user.get().setDeletedAt(LocalDateTime.now());
////                            this.userRepository.save(user.get());
////                        }
//                    } else if (Objects.equals(resident.getMode(), "ADD")) {
//                        String tenantMemberId = AppHelper.generateUniqueId();
//                        String ownerMemberId = AppHelper.generateUniqueId();
//                        if (Objects.equals(resident.getResidentType(), AppConstants.ResidentType.TENANT)) {
//                            Resident resident1 = Resident.builder()
//                                    .tenantEmail(resident.getEmail())
//                                    .tenantName(resident.getName())
//                                    .tenantPhone(resident.getMobileNo())
//                                    .possessionDate(existingResident.getPossessionDate())
//                                    .createdBy(loggedInId)
//                                    .roles(existingResident.getRoles())
//                                    .user(existingResident.getUser())
//                                    .apartment(existingResident.getApartment())
//                                    .area(existingResident.getArea())
//                                    .society(existingResident.getSociety())
//                                    .password(existingResident.getPassword())
//                                    .bhk(existingResident.getBhk())
//                                    .sqFeetArea(existingResident.getSqFeetArea())
//                                    .ownerSecondaryPhone(existingResident.getOwnerSecondaryPhone())
//                                    .tenantSecondaryPhone(existingResident.getTenantSecondaryPhone())
//                                    .residentType(AppConstants.ResidentType.TENANT)
//                                    .parking(existingResident.getParking())
//                                    .accommodationType(existingResident.getAccommodationType())
//                                    .primaryOwnerPhone(existingResident.getPrimaryOwnerPhone())
//                                    .primaryTenantPhone(existingResident.getPrimaryTenantPhone())
//                                    .meterId(existingResident.getMeterId())
//                                    .consumerId(existingResident.getConsumerId())
//                                    .sanctionedLoadKW(existingResident.getSanctionedLoadKW())
//                                    .sanctionedDGLoadKV(existingResident.getSanctionedDGLoadKV())
//                                    .numberPipedGasUsers(existingResident.getNumberPipedGasUsers())
//                                    .tenantMemberId(tenantMemberId)
//                                    .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)//
//                                    .build();
//                            this.residentRepository.save(resident1);
//                            Optional<User> existingTenantUser = this.userRepository.findByEmail(resident.getEmail());
//                            if (existingTenantUser.isEmpty()) {
//                                User u = User.builder()
//                                        .email(resident.getEmail())
//                                        .contactNumber(resident.getMobileNo())
////                                        .society(existingResident.getSociety())
//                                        .password(passwordEncoder.encode("1234"))
//                                        .name(resident.getName())
//                                        .status(true)
////                                        .roles(Set.of(this.roleRepository.findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
////                                                .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"))))
//                                        .memberId(tenantMemberId)
//                                        .residentType(AppConstants.ResidentType.TENANT)
//                                        .build();
//                                this.userRepository.save(u);
//
//                                // ✅ Create UserRoleMapping instead of adding to user.getRoles()
//                                Society society = existingResident.getSociety();
//                                boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, residentRole, society);
//                                if (!roleExists) {
//                                    UserRoleMapping mapping = UserRoleMapping.builder()
//                                            .user(u)
//                                            .role(residentRole)
//                                            .society(society)
//                                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
//                                            .build();
//                                    this._userRoleMappingRepository.save(mapping);
//                                }
//
//                            } else {
//                                User existUser = existingTenantUser.get();//
//                                Society society = existingResident.getSociety();
//                                existUser.getUserRoleMappings()
//                                        .add(UserRoleMapping
//                                                .builder()
//                                                .user(existUser)
//                                                .role(residentRole)
//                                                .society(society)
//                                                .createdAt(Timestamp.valueOf(LocalDateTime.now())).build());
////                                existUser.getRoles().add(residentRole);//
//                                this.userRepository.save(existUser);
//                            }
//                        }
//                        if (Objects.equals(resident.getResidentType(), AppConstants.ResidentType.OWNER)) {
//                            Resident resident2 = Resident.builder()
//                                    .possessionDate(existingResident.getPossessionDate())
//                                    .createdBy(loggedInId)
//                                    .roles(existingResident.getRoles())
//                                    .user(existingResident.getUser())//
//                                    .apartment(existingResident.getApartment())
//                                    .area(existingResident.getArea())
//                                    .society(existingResident.getSociety())
//                                    .password(existingResident.getPassword())
//                                    .bhk(existingResident.getBhk())
//                                    .sqFeetArea(existingResident.getSqFeetArea())
//                                    .ownerSecondaryPhone(existingResident.getOwnerSecondaryPhone())
//                                    .tenantSecondaryPhone(existingResident.getTenantSecondaryPhone())
//                                    .residentType(AppConstants.ResidentType.OWNER)
//                                    .parking(existingResident.getParking())
//                                    .accommodationType(existingResident.getAccommodationType())
//                                    .primaryOwnerPhone(existingResident.getPrimaryOwnerPhone())
//                                    .primaryTenantPhone(existingResident.getPrimaryTenantPhone())
//                                    .meterId(existingResident.getMeterId())
//                                    .consumerId(existingResident.getConsumerId())
//                                    .sanctionedLoadKW(existingResident.getSanctionedLoadKW())
//                                    .sanctionedDGLoadKV(existingResident.getSanctionedDGLoadKV())
//                                    .numberPipedGasUsers(existingResident.getNumberPipedGasUsers())
//                                    .ownerMemberId(ownerMemberId)
//                                    .tenantMemberId(existingResident.getTenantMemberId())
//                                    .ownerName(resident.getName())
//                                    .ownerEmail(resident.getEmail())
//                                    .ownerPhone(resident.getMobileNo())
//                                    .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
//                                    .build();
//                            this.residentRepository.save(resident2);
//                            Optional<User> existingOwnerUser = this.userRepository.findByEmail(resident.getEmail());
//                            if (existingOwnerUser.isEmpty()) {
//                                User u = User.builder()
//                                        .email(resident.getEmail())
//                                        .contactNumber(resident.getMobileNo())
////                                        .society(existingResident.getSociety())
//                                        .password(passwordEncoder.encode("1234"))
//                                        .name(resident.getName())
//                                        .status(true)
////                                        .roles(Set.of(this.roleRepository.findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
////                                                .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"))))
//                                        .memberId(ownerMemberId)
//                                        .residentType(AppConstants.ResidentType.OWNER)
//                                        .build();
//                                this.userRepository.save(u);
//                                // ✅ Create UserRoleMapping instead of adding to user.getRoles()
//                                Society society = existingResident.getSociety();
//                                boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, residentRole, society);
//                                if (!roleExists) {
//                                    UserRoleMapping mapping = UserRoleMapping.builder()
//                                            .user(u)
//                                            .role(residentRole)
//                                            .society(society)
//                                            .createdAt(Timestamp.valueOf(LocalDateTime.now()))
//                                            .build();
//                                    this._userRoleMappingRepository.save(mapping);
//                                }
//                            } else {
//                                User existUser = existingOwnerUser.get();//
//                                Society society = existingResident.getSociety();
//                                existUser.getUserRoleMappings()
//                                        .add(UserRoleMapping
//                                                .builder()
//                                                .user(existUser)
//                                                .role(residentRole)
//                                                .society(society)
//                                                .createdAt(Timestamp.valueOf(LocalDateTime.now()))
//                                                .build());
////                                existUser.getRoles().add(residentRole);//
//                                this.userRepository.save(existUser);
//                            }
//                        }
//                    } else if (Objects.equals(resident.getMode(), "EDIT")) {
//                        Resident existingResident1 = this.residentRepository
//                                .findById(resident.getId())
//                                .orElseThrow(() -> new ResourceNotFoundException("Resident not found!"));
//                        if (resident.getResidentType().equalsIgnoreCase(AppConstants.ResidentType.OWNER)) {
//                            existingResident1.setOwnerPhone(resident.getMobileNo());
//                            existingResident1.setOwnerName(resident.getName());
//                            existingResident1.setOwnerEmail(resident.getEmail());
//                        } else if (resident.getResidentType().equalsIgnoreCase(AppConstants.ResidentType.TENANT)) {
//                            existingResident1.setTenantPhone(resident.getMobileNo());
//                            existingResident1.setTenantName(resident.getName());
//                            existingResident1.setTenantEmail(resident.getEmail());
//                        }
//                        this.residentRepository.save(existingResident1);
//                        Optional<User> user = this.userRepository.findByEmail(resident.getEmail());
//                        if (user.isPresent()) {
//                            user.get().setEmail(resident.getEmail());
//                            user.get().setName(resident.getName());
//                            user.get().setModifyBy(loggedInId);
//                            user.get().setContactNumber(resident.getMobileNo());
//                            this.userRepository.save(user.get());
//                        } else {
//                            User u = User.builder()
//                                    .email(resident.getEmail())
//                                    .contactNumber(resident.getMobileNo())
//                                    .password(passwordEncoder.encode("1234"))
//                                    .status(true)
//                                    .name(resident.getName())
//                                    .residentType(resident.getResidentType())
//                                    .memberId(resident.getResidentType().equalsIgnoreCase(AppConstants.ResidentType.TENANT) ? existingResident1.getTenantMemberId() : existingResident1.getOwnerMemberId())
//                                    .build();
//                            this.userRepository.save(u);
//                            // ✅ Create UserRoleMapping instead of adding to user.getRoles()
//                            Society society = existingResident1.getSociety();
//                            boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(u, residentRole, society);
//                            if (!roleExists) {
//                                UserRoleMapping mapping = UserRoleMapping.builder()
//                                        .user(u)
//                                        .role(residentRole)
//                                        .society(society)
//                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
//                                        .build();
//                                this._userRoleMappingRepository.save(mapping);
//                            }
//                        }
//                    }
//                });
//            } else {
//                manageResidentDto.getResidents().forEach(resident -> {
//                    String tenantMemberId = AppHelper.generateUniqueId();
//                    String ownerMemberId = AppHelper.generateUniqueId();
//                    Society existingSociety = this.societyRepository
//                            .findById(resident.getSocietyId())
//                            .orElseThrow(() -> new ResourceNotFoundException("Society not found!"));
//                    Apartment existingApartment = this.apartmentRepository.findById(resident.getApartmentId())
//                            .orElseThrow(() -> new ResourceNotFoundException("Apartment not found"));
//                    Area existingArea = this.areaRepository.findById(resident.getAreaId())
//                            .orElseThrow(() -> new ResourceNotFoundException("Area not found"));
//                    Optional<User> existingUser = this.userRepository.findByEmail(resident.getEmail());
//                    User user = null;
//                    if (existingUser.isEmpty()) {
//                        user = User.builder()
//                                .email(resident.getEmail())
//                                .contactNumber(resident.getMobileNo())
////                                .society(existingSociety)
//                                .password(passwordEncoder.encode("1234"))
//                                .name(resident.getName())
//                                .status(true)
////                                .roles(Set.of(this.roleRepository.findById(AppConstants.RoleConstant.RESIDENTIAL_USER)
////                                        .orElseThrow(() -> new ResourceNotFoundException("Role Not Found"))))
//                                .memberId(tenantMemberId)
//                                .residentType(AppConstants.ResidentType.TENANT)
//                                .build();
//                        this.userRepository.save(user);
//
//                        // ✅ Create UserRoleMapping instead of adding to user.getRoles()
//                        boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, residentRole, existingSociety);
//                        if (!roleExists) {
//                            UserRoleMapping mapping = UserRoleMapping.builder()
//                                    .user(user)
//                                    .role(residentRole)
//                                    .society(existingSociety)
//                                    .createdAt(Timestamp.valueOf(LocalDateTime.now()))
//                                    .build();
//                            this._userRoleMappingRepository.save(mapping);
//                        }
//                    } else {
//                        User existUser = existingUser.get();//
//
//                        existUser.getUserRoleMappings()
//                                .add(UserRoleMapping
//                                        .builder()
//                                        .user(existUser)
//                                        .role(residentRole)
//                                        .society(existingSociety)
//                                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
//                                        .build());
////                        existUser.getRoles().add(residentRole);//
//                        this.userRepository.save(existUser);
//                    }
//                    if (Objects.equals(resident.getResidentType(), AppConstants.ResidentType.TENANT)) {
//                        Resident resident1 = Resident.builder()
//                                .tenantEmail(resident.getEmail())
//                                .tenantName(resident.getName())
//                                .tenantPhone(resident.getMobileNo())
//                                .createdBy(loggedInId)
//                                .roles("Resident")
//                                .user(existingUser.orElse(user))
//                                .apartment(existingApartment)
//                                .area(existingArea)
//                                .society(existingSociety)
//                                .password(passwordEncoder.encode("1234"))
//                                .bhk(existingApartment.getFlat())
//                                .residentType(AppConstants.ResidentType.TENANT)
//                                .tenantMemberId(tenantMemberId)
//                                .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
//                                .build();
//                        this.residentRepository.save(resident1);
//                    } else if (Objects.equals(resident.getResidentType(), AppConstants.ResidentType.OWNER)) {
//                        Resident resident1 = Resident.builder()
//                                .ownerEmail(resident.getEmail())
//                                .ownerName(resident.getName())
//                                .ownerPhone(resident.getMobileNo())
//                                .createdBy(loggedInId)
//                                .roles("Resident")
//                                .user(existingUser.orElse(user))
//                                .apartment(existingApartment)
//                                .area(existingArea)
//                                .society(existingSociety)
//                                .password(passwordEncoder.encode("1234"))
//                                .bhk(existingApartment.getFlat())
//                                .residentType(AppConstants.ResidentType.OWNER)
//                                .ownerMemberId(ownerMemberId)
//                                .roleId(AppConstants.RoleConstant.RESIDENTIAL_USER)
//                                .build();
//                        this.residentRepository.save(resident1);
//                    }
//                });
//            }
//            return null;
//        } catch (Exception ex) {
//            return ex.getMessage();
//        }
//    }


    @Override
    public List<ViewApartmentOfResidentsDto> getLocationBySociety(Long societyId, String searchText, int limit, int offset) {
        Specification<Apartment> spec = ApartmentSpecification.getLocationBySocietyId(societyId, searchText);

        List<Apartment> apartments;

        if (searchText != null && !searchText.isEmpty()) {
            // fetch all results for search
            apartments = apartmentRepository.findAll(spec);
        } else {
            int pageNumber = offset / limit;
            PageRequest pageRequest = PageRequest.of(pageNumber, limit);
            apartments = apartmentRepository.findAll(spec, pageRequest).getContent();
        }

        return apartments.stream()
                .map(apartment -> new ViewApartmentOfResidentsDto(
                        apartment.getId(),
                        apartment.getBlock(),
                        apartment.getFlat(),
                        apartment.getFloor(),
                        apartment.getArea().getSociety().getSocietyName(),
                        apartment.getArea().getSociety().getId(),
                        apartment.getId(),
                        apartment.getArea().getId(),
                        "Admin"
                ))
                .toList();
    }

}