package com.propertymanageruae.api.helper;

import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.entities.Complaint;
import com.propertymanageruae.api.entities.SubCategory;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.repositories.ICategoryRepository;
import com.propertymanageruae.api.repositories.IComplaintRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import com.propertymanageruae.api.services.logger.ILoggerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class TableHandler {
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private IComplaintRepository complaintRepository;
    @Autowired
    private ICategoryRepository categoryRepository;
    @Autowired
    private ILoggerService loggerService;

    public List<String> getHeadersForTable(String tableName) {
        if (tableName.equalsIgnoreCase("member")) {
            return List.of("Name", "Email", "Contact", "Role", "Status");
        }
        if (tableName.equalsIgnoreCase("complaint")) {
            return List.of(
                    "Complaint ID",
                    "Priority",
                    "Location",
                    "Category",
                    "SubCategory",
                    "Assigned User",
                    "Complainer",
                    "Ticket Status",
                    "Created At",
                    "Last Updated"
            );
        }
        if (tableName.equalsIgnoreCase("category")) {
            return List.of("Category ID", "Category Name", "Created By", "Created At", "Updated At", "Subcategories");
        }
        if (tableName.equalsIgnoreCase("fileUploadError")) {
            return List.of("Error");
        }
        return null;
    }

    public List<Map<String, Object>> getDataForTable(String tableName, List<String> columns) {
        return switch (tableName.toLowerCase()) {
            case "member" -> {
                List<User> users = this.userRepository.findAll();
                yield users.stream().map(user -> {
                    Map<String, Object> row = new HashMap<>();
                    row.put("Name", user.getName());
                    row.put("Email", user.getEmail());
                    row.put("Contact", user.getContactNumber());
                    row.put("Role", user.getUserRoleMappings().stream()
                            .map(x -> x.getRole().getTitle())
                            .collect(Collectors.joining(", ")));
                    row.put("Status", user.isStatus() ? "Active" : "Inactive");
                    return row;
                }).collect(Collectors.toList());
            }
            case "complaint" -> {
                List<Complaint> complaints = this.complaintRepository.findAll();
                yield complaints.stream().map(complaint -> {
                    Map<String, Object> row = new HashMap<>();
                    row.put("Complaint ID", complaint.getId());
                    row.put("Priority", complaint.getPriority());
                    row.put("Location", complaint.getLocation().getLocationData());
                    row.put("Category", complaint.getCategory().getCategory());
                    row.put("SubCategory", complaint.getSubCategory() != null ? complaint.getSubCategory().getSubCategory() : "N/A");
                    row.put("Assigned User", complaint.getAssignedUser().getName());
                    row.put("Complainer", complaint.getComplainer().getName());
                    row.put("Ticket Status", complaint.getTicketStatus());
                    row.put("Created At", complaint.getCreatedAt().toString());
                    row.put("Last Updated", complaint.getLastUpdated() != null ? complaint.getLastUpdated().toString() : "N/A");
                    return row;
                }).collect(Collectors.toList());
            }
            case "category" -> {
                List<Category> categories = this.categoryRepository.findAll();
                yield categories.stream().map(category -> {
                    Map<String, Object> row = new HashMap<>();
                    row.put("Category ID", category.getId());
                    row.put("Category Name", category.getCategory());
                    row.put("Created By", category.getCreatedBy().getName());
                    row.put("Created At", category.getCreatedAt() != null ? category.getCreatedAt().toString() : "N/A");
                    row.put("Updated At", category.getUpdatedAt() != null ? category.getUpdatedAt().toString() : "N/A");
                    String subCategoryNames = category.getSubCategoryList().stream()
                            .map(SubCategory::getSubCategory)
                            .collect(Collectors.joining(", "));
                    row.put("Subcategories", subCategoryNames);
                    return row;
                }).collect(Collectors.toList());
            }
            case "fileuploaderror" -> columns.stream()
                    .map(error -> {
                        Map<String, Object> row = new HashMap<>();
                        row.put("Error", error);
                        return row;
                    })
                    .collect(Collectors.toList());
            default -> Collections.emptyList();
        };
    }


}