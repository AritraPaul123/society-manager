package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.GuardPerformance;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.analytics.GuardPerformanceDto;
import com.propertymanageruae.api.repositories.GuardPerformanceRepository;
import com.propertymanageruae.api.repositories.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GuardPerformanceService {

    @Autowired
    private GuardPerformanceRepository performanceRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    public GuardPerformanceDto getPerformance(Long guardId, LocalDate date) {
        User guard = userRepository.findById(guardId)
                .orElseThrow(() -> new RuntimeException("Guard not found"));
        
        GuardPerformance performance = performanceRepository.findByGuardAndDate(guard, date)
                .orElseGet(() -> {
                    GuardPerformance newPerf = new GuardPerformance();
                    newPerf.setGuard(guard);
                    newPerf.setDate(date);
                    return performanceRepository.save(newPerf);
                });
        
        return convertToDto(performance);
    }

    public List<GuardPerformanceDto> getGuardHistory(Long guardId) {
        User guard = userRepository.findById(guardId)
                .orElseThrow(() -> new RuntimeException("Guard not found"));
        return performanceRepository.findByGuard(guard).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public void incrementPatrolStats(Long guardId, boolean completed) {
        GuardPerformance performance = getOrCreateTodayPerformance(guardId);
        performance.setPatrolsAssigned(performance.getPatrolsAssigned() + 1);
        if (completed) {
            performance.setPatrolsCompleted(performance.getPatrolsCompleted() + 1);
        } else {
            performance.setPatrolsMissed(performance.getPatrolsMissed() + 1);
        }
        performance.calculatePerformanceScore();
        performanceRepository.save(performance);
    }

    @Transactional
    public void incrementVisitorStats(Long guardId) {
        GuardPerformance performance = getOrCreateTodayPerformance(guardId);
        performance.setVisitorsProcessed(performance.getVisitorsProcessed() + 1);
        performance.calculatePerformanceScore();
        performanceRepository.save(performance);
    }

    @Transactional
    public void incrementIncidentStats(Long guardId) {
        GuardPerformance performance = getOrCreateTodayPerformance(guardId);
        performance.setIncidentsReported(performance.getIncidentsReported() + 1);
        performance.calculatePerformanceScore();
        performanceRepository.save(performance);
    }

    private GuardPerformance getOrCreateTodayPerformance(Long guardId) {
        User guard = userRepository.findById(guardId)
                .orElseThrow(() -> new RuntimeException("Guard not found"));
        return performanceRepository.findByGuardAndDate(guard, LocalDate.now())
                .orElseGet(() -> {
                    GuardPerformance newPerf = new GuardPerformance();
                    newPerf.setGuard(guard);
                    newPerf.setDate(LocalDate.now());
                    return performanceRepository.save(newPerf);
                });
    }

    private GuardPerformanceDto convertToDto(GuardPerformance performance) {
        GuardPerformanceDto dto = modelMapper.map(performance, GuardPerformanceDto.class);
        dto.setGuardName(performance.getGuard().getName());
        return dto;
    }
}
