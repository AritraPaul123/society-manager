package com.propertymanageruae.api.payloads.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.propertymanageruae.api.config.TimeZoneContext;
import com.propertymanageruae.api.helper.AppHelper;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.Instant;
import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {
    private boolean success;
    private String message;
    private T data;
    private T error;
    private LocalDateTime timestamp;
    private int statusCode;
    private String timeZone;

    public ApiResponse(boolean success, String message, T data,T error, int statusCode) {
        this.success = success;
        this.message = message;
        this.data = data;
        this.error=error;
        this.statusCode = statusCode;
        String userZone = TimeZoneContext.getTimeZone();
        this.timeZone = userZone != null ? userZone : "UTC";
        this.timestamp = AppHelper.convertToUserZone(Instant.now(), userZone);
    }



    public static <T> ApiResponse<T> success(T data, String message,T error, int statusCode) {
        return new ApiResponse<>(true, message, data,error, statusCode);
    }


    public static <T> ApiResponse<T> error(String message, int statusCode) {
        return new ApiResponse<>(false, message, null,null, statusCode);
    }

    public static <T> ApiResponse<T> error(String message,T data, T error, int statusCode) {
        return new ApiResponse<>(false, message, data,error, statusCode);
    }
}