package com.propertymanageruae.api.utility;

public class Status {
    public final static int ALL = 0;
    public final static int ACTIVE = 100;
    public final static int INACTIVE = 101;
    public final static int PENDING = 102;
    public final static int REJECT = 103;
    public final static int SUSPENDED = 104;
    public final static int EDITED = 105;
    public final static int DRAFTED = 106;
    public final static int APPROVED = 108;
    public final static int DELETED = 109;
    public final static int BLOCKED = 110;

    private Status() {} // prevent instantiation
}

