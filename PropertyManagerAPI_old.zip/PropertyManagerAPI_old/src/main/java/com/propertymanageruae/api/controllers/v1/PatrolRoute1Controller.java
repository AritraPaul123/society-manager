package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.patrol.PatrolRouteDto;
import com.propertymanageruae.api.services.PatrolRouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/patrol-routes")
public class PatrolRoute1Controller {

    @Autowired
    private PatrolRouteService patrolRouteService;

    @PostMapping("/")
    public ResponseEntity<PatrolRouteDto> createRoute(@RequestBody PatrolRouteDto routeDto) {
        return new ResponseEntity<>(patrolRouteService.createRoute(routeDto), HttpStatus.CREATED);
    }

    @GetMapping("/society/{societyId}")
    public ResponseEntity<List<PatrolRouteDto>> getRoutesBySociety(@PathVariable Long societyId) {
        return ResponseEntity.ok(patrolRouteService.getRoutesBySociety(societyId));
    }
}
