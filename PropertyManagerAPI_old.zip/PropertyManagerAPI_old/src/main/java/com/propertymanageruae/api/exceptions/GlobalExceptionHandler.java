package com.propertymanageruae.api.exceptions;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.utils.ErrorLogService;
import com.propertymanageruae.api.services.utils.IErrorLogService;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.http.HttpServletRequest;
import org.hibernate.service.spi.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MultipartException;
import software.amazon.awssdk.services.s3.model.S3Exception;

import java.nio.file.AccessDeniedException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private final IErrorLogService errorLogService;

    public GlobalExceptionHandler(ErrorLogService errorLogService) {
        this.errorLogService = errorLogService;
    }

    private void logError(Exception ex, HttpServletRequest request) {
        logger.error("Exception at [{}]: {}", request.getRequestURI(), ex.getMessage(), ex);
    }

    private ResponseEntity<ApiResponse<Object>> buildErrorResponse(HttpStatus status, String message, Object errors) {
        ApiResponse<Object> response = ApiResponse.error(message,null, errors, status.value());
        return new ResponseEntity<>(response, status);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ApiResponse<Object>> handleResourceNotFoundException(ResourceNotFoundException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.NOT_FOUND, "Resource Not Found!", ex.getMessage());
    }
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ApiResponse<Object>> handleIllegalArgumentException(IllegalArgumentException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.BAD_REQUEST, "Illegal Argument!", ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<ApiResponse<Object>> handleValidationException(MethodArgumentNotValidException ex, HttpServletRequest request) {
        logError(ex, request);
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMsg = error.getDefaultMessage();
            errors.put(fieldName, errorMsg);
        });
        return buildErrorResponse(HttpStatus.OK, null, errors);
    }

    @ExceptionHandler(MultipartException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ApiResponse<Object>> handleMultipartException(MultipartException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.BAD_REQUEST, "File upload error", ex.getMessage());
    }

    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public ResponseEntity<ApiResponse<Object>> handleSQLIntegrityViolationException(SQLIntegrityConstraintViolationException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.CONFLICT, "Database conflict", ex.getMessage());
    }

    @ExceptionHandler(InvalidOperationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ApiResponse<Object>> handleInvalidOperationException(InvalidOperationException ex,HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.BAD_REQUEST, ex.getMessage(),ex.getMessage());
    }

    @ExceptionHandler(AuthException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ApiResponse<Object>> handleAuthException(AuthException ex,HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.BAD_REQUEST, ex.getMessage(),ex.getMessage());
    }

//    @ExceptionHandler(ServiceException.class)
//    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
//    public ResponseEntity<ApiResponse<Object>> handleServiceException(ServiceException ex, HttpServletRequest request) {
//        logError(ex, request);
//        return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR,"Service Exception occurred" , ex.getMessage());
//    }
    @ExceptionHandler(ServiceException.class)
    public ResponseEntity<ApiResponse<Object>> handleServiceException(
            ServiceException ex, HttpServletRequest request) {

        logError(ex, request);

        return buildErrorResponse(
                HttpStatus.BAD_REQUEST,
                ex.getMessage(),
                null
        );
    }


    @ExceptionHandler(ExpiredJwtException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<ApiResponse<Object>> handleExpiredJwtException(ExpiredJwtException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.UNAUTHORIZED, "JWT token expired", ex.getMessage());
    }

    @ExceptionHandler(BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<ApiResponse<Object>> handleBadCredentialsException(BadCredentialsException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.UNAUTHORIZED, "Invalid credentials", ex.getMessage());
    }

    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResponseEntity<ApiResponse<Object>> handleAccessDeniedException(AccessDeniedException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.FORBIDDEN, "Access denied", ex.getMessage());
    }
    @ExceptionHandler(MailSendException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ApiResponse<Object>> handleMailSendException(Exception ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), request);
    }
    @ExceptionHandler(S3Exception.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResponseEntity<ApiResponse<Object>> handleS3Exception(S3Exception ex) {
        String detailedMessage = String.format(
                "S3 Exception occurred: Status Code: %d, Error Code: %s, Error Message: %s, AWS Request ID: %s",
                ex.statusCode(),
                ex.awsErrorDetails().errorCode(),
                ex.awsErrorDetails().errorMessage(),
                ex.requestId()
        );
        logError(new Exception(detailedMessage),null);
        return buildErrorResponse(HttpStatus.FORBIDDEN,"Access to S3 is forbidden: " + ex.awsErrorDetails().errorMessage(), null);
    }

    @ExceptionHandler(EmailAlreadyExitException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResponseEntity<ApiResponse<Object>> dataIntegrityViolationExceptionException(DataIntegrityViolationException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.FORBIDDEN, "Duplicate Entry!", ex.getMessage());
    }

    @ExceptionHandler(FirebaseMessagingException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ApiResponse<Object>> handleFirebaseMessagingException(FirebaseMessagingException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Failed to send notification",
                ex.getMessage()
        );
    }


    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ApiResponse<Object>> handleRuntimeException(RuntimeException ex, HttpServletRequest request) {
        logError(ex, request);
        return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "A runtime error occurred", ex.getMessage());
    }




    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ApiResponse<Object>> handleGeneralException(Exception ex, HttpServletRequest request) {
        // 1) log to logger
        logError(ex, request);

        // 2) save to DB and get unique code
        String errorCode = errorLogService.saveException(ex, request.getRequestURI());

        // 3) return sanitized error message for client
        String clientMessage = "Internal server error - error code " + errorCode;
        return buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, clientMessage, null);
    }
}