package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Tenant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TenantRepository extends JpaRepository<Tenant, Long> {
}

