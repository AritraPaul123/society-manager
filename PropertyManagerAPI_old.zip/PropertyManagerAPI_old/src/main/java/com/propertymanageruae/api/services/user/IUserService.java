package com.propertymanageruae.api.services.user;


import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.user.UserDTO;
import com.propertymanageruae.api.payloads.user.UserProfileDto;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

public interface IUserService {
    UserDTO register(UserDTO userDto) throws SQLIntegrityConstraintViolationException;
    List<User> getUsers();
    User getUserByMail(String mail);
    UserDTO getUserById(Long id);
    UserProfileDto getUserProfile(Long id);
}