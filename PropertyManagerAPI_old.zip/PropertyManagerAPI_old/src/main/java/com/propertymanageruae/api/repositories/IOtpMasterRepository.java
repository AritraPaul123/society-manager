package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.OtpMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.Optional;

public interface IOtpMasterRepository extends JpaRepository<OtpMaster, Long>, JpaSpecificationExecutor<OtpMaster> {

    @Modifying
    @Query("UPDATE OtpMaster o SET o.status = false WHERE o.createdAt <= :expirationTime AND o.status = true")
    void updateOtpStatusToFalse(@Param("expirationTime") LocalDateTime expirationTime);
    Optional<OtpMaster> findByOtpIdentifier(String otpIdentifier);
    @Query("SELECT o FROM OtpMaster o WHERE o.otp = :otp AND o.otpIdentifier = :otpIdentifier AND o.status = true")
    Optional<OtpMaster> findValidOtp(@Param("otp") String otp, @Param("otpIdentifier") String otpIdentifier);
}