package com.propertymanageruae.api.payloads.category;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CategoryDTO {
    private long id;
    @NotEmpty(message = "Category is required")
    private String category;
    private long societyId;
    private List<SubCategoryDTO> subCategoryList;
}