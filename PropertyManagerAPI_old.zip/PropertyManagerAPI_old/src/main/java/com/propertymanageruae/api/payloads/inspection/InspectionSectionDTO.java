package com.propertymanageruae.api.payloads.inspection;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InspectionSectionDTO {

    private Long inspectionId;
    private String title;
}
