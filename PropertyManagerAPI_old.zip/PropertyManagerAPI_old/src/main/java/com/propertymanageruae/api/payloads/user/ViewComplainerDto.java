package com.propertymanageruae.api.payloads.user;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ViewComplainerDto {
    private long id;
    private String ownerName;
    private String ownerPhone;
    private String ownerSecondaryPhone;
    private String ownerEmail;
    private String tenantName;
    private String tenantEmail;
    private String memberId;
    private String residentType;
}