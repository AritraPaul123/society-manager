package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Table(name = "visitors")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Visitor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "mobile_number", nullable = false)
    private String mobileNumber;

    @Column(name = "visit_purpose")
    private String visitPurpose; // Delivery, Guest, Service

    // Linking to Apartment entity effectively
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "apartment_id")
    private Apartment apartment;

    @Column(name = "check_in_time", nullable = false)
    private LocalDateTime checkInTime;

    @Column(name = "check_out_time")
    private LocalDateTime checkOutTime;

    @Column(name = "status")
    private String status; // CHECKED_IN, CHECKED_OUT

    @Column(name = "gate_number")
    private String gateNumber;

    @Column(name = "photo_url")
    private String photoUrl;
    
    // Emirates ID and Repeat Visitor Intelligence fields
    @Column(name = "emirates_id")
    private String emiratesId;
    
    @Column(name = "company_name")
    private String companyName;
    
    @Column(name = "is_repeat_visitor")
    private Boolean isRepeatVisitor = false;
    
    @Column(name = "last_visit_date")
    private LocalDateTime lastVisitDate;
    
    @Column(name = "visit_count")
    private Integer visitCount = 1;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "guard_id") // The guard who allowed entry
    private User guard;

    @PrePersist
    protected void onCreate() {
        if(checkInTime == null) checkInTime = LocalDateTime.now();
    }
}
