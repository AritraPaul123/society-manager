package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.GuardPerformance;
import com.propertymanageruae.api.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface GuardPerformanceRepository extends JpaRepository<GuardPerformance, Long> {
    Optional<GuardPerformance> findByGuardAndDate(User guard, LocalDate date);
    List<GuardPerformance> findByGuard(User guard);
    List<GuardPerformance> findByDate(LocalDate date);
}
