package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.propertymanageruae.api.enums.SocietyType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "society")
public class Society {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "societyName")
    private String societyName;
    @Column(name = "societyPhone")
    private String societyPhone;
    @Column(name = "societyEmail", unique = false, nullable = false)
    private String societyEmail;

    @Enumerated(EnumType.STRING)
    @Column(name = "societyType",nullable = false)
    private SocietyType societyType;



    @Column(name = "city")
    private String city;
    @Column(name="country")
    private String country;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "societyId", unique = true, nullable = false)//
    private String societyId;
    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<Area> area=new ArrayList<>();
    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<Apartment> apartment;
    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<Resident> resident;
    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<Notice> notice;
    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<Complaint> complaint;
    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<Category> category;

//    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
//    @JsonManagedReference
//    private List<User> user;

    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<AssignmentRule> assignmentRule;
    @OneToMany(mappedBy = "society", cascade = CascadeType.REMOVE, orphanRemoval = false)
    @JsonManagedReference
    private List<CommentMaster> comments;


    @OneToMany(mappedBy = "society", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<UserRoleMapping> userRoleMappings = new ArrayList<>();

    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;

    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Column(nullable = true)
    private LocalDateTime deletedAt;
    @Column(name = "society_code", nullable = true, length = 100)
    private String societyCode;



    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}