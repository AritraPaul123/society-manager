package com.propertymanageruae.api.config._Mapper;

import com.propertymanageruae.api.entities.Apartment;
import com.propertymanageruae.api.entities.Area;
import com.propertymanageruae.api.entities.Complaint;
import com.propertymanageruae.api.payloads.complaint.ViewComplaintDto;
import com.propertymanageruae.api.payloads.master.ViewApartmentDto;
import com.propertymanageruae.api.payloads.master.ViewAreaDto;
import com.propertymanageruae.api.repositories.IApartmentRepository;
import com.propertymanageruae.api.repositories.IAreaRepository;
import jakarta.annotation.PostConstruct;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.stereotype.Component;

@Component
public class ComplaintMappingProfile {
    private final ModelMapper modelMapper;
    private final IApartmentRepository apartmentRepository;
    private final IAreaRepository areaRepository;

    public ComplaintMappingProfile(ModelMapper modelMapper,
                                   IApartmentRepository apartmentRepository,
                                   IAreaRepository areaRepository) {
        this.modelMapper = modelMapper;
        this.apartmentRepository = apartmentRepository;
        this.areaRepository=areaRepository;
    }

    @PostConstruct
    public void configureComplaintMapping() {
        TypeMap<Complaint, ViewComplaintDto> typeMap = modelMapper.createTypeMap(Complaint.class, ViewComplaintDto.class);
        typeMap.addMappings(mapper -> {
            mapper.map(src -> src.getSociety().getId(), ViewComplaintDto::setSocietyId);
            mapper.using(ctx -> {
                Long apartmentId = (Long) ctx.getSource();
                if (apartmentId == 0) return null;
                Apartment apartment = apartmentRepository.findById(apartmentId).orElse(null);
                return (apartment != null) ? modelMapper.map(apartment, ViewApartmentDto.class) : null;
            }).map(Complaint::getApartmentId, ViewComplaintDto::setApartment);
            mapper.using(ctx -> {
                Long areaId = (Long) ctx.getSource();
                if (areaId == 0) return null;
                Area area = areaRepository.findById(areaId).orElse(null);
                return (area != null) ? modelMapper.map(area, ViewAreaDto.class) : null;
            }).map(Complaint::getAreaId, ViewComplaintDto::setArea);
        });

    }
}