package com.propertymanageruae.api.controllers.v1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.ServiceException;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.UnitHelper;
import com.propertymanageruae.api.payloads.ExternalDTO.MailDto;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.master.*;
import com.propertymanageruae.api.payloads.user.ViewComplainerDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v${api.version}/master")
@SecurityRequirement(name = "auth")
@Tag(name = "Masters")
public class Master1Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Autowired
    private UnitService _unitService;
    @Autowired
    private UnitHelper _unitHelper;
    @Autowired
    private TemplateEngine templateEngine;

    @Operation(summary = "Add new Society")
    @PostMapping("/add-society")
    public ResponseEntity<ApiResponse<String>> addMember(@Valid @RequestBody AddSocietyDto addSocietyDto) throws SQLIntegrityConstraintViolationException {
        String msg = this._unitService.masterService.addSociety(addSocietyDto);
        boolean success = (msg == null || msg.isEmpty());
        return success
                ? ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(null, "Society Added Successfully.", null, HttpStatus.CREATED.value()))
                : ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ApiResponse.error(msg, null, msg, HttpStatus.CONFLICT.value()));
    }

    @Operation(summary = "Upload CSV or Excel of Area,Apartment,Resident data into Society")
    @PostMapping(value = "/upload/{societyId}/type/{typeId}", consumes = {"multipart/form-data"})
    public ResponseEntity<ApiResponse<UploadDto>> uploadCSVFileToSociety(
            @RequestPart("file") MultipartFile file, @PathVariable("societyId") long societyId, @PathVariable("typeId") long typeId
    ) throws IOException {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Please attached file before upload", null, null, HttpStatus.BAD_REQUEST.value()));
        }
        UploadDto uploadDto = this._unitService.masterService.uploadFile(societyId, typeId, file);
        if (uploadDto.getUploadSummary() != null) {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(uploadDto, uploadDto.getUploadSummary(), null, HttpStatus.CREATED.value()));
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Something Went Wrong", null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @Operation(summary = "Universal Send Email API")
    @PostMapping("/send-email")
    public ResponseEntity<ApiResponse<String>> sendEmail(@RequestBody MailDto mailDto) {
        try {
            Context context = new Context();
            context.setVariable("name", mailDto.getName());
            context.setVariable("message", mailDto.getBody());
            String htmlContent = templateEngine.process("email-template", context);
            mailDto.setBody(htmlContent);
            this._unitService.gmailOAuthService.sendEmail(mailDto);
            return ResponseEntity.status(HttpStatus.OK).body(ApiResponse.success(null, "Mail send successfully", null, HttpStatus.OK.value()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ApiResponse.success(null, null, "Failed to send email", HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @Operation(description = "Get Residents", summary = "This is summary for category get endpoint")
    @GetMapping("/all-residents/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewResidentDto>>> getMembers(
            @PathVariable("societyId") long societyId,
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(value = "searchText", required = false) String searchText
    ) throws JsonProcessingException {
        PaginationDto<ViewResidentDto> residentDtos = this._unitService.masterService.getResidents(pageNumber, pageSize, sortBy, sortDir, searchText, societyId);
        List<ViewResidentDto> residentDto = residentDtos.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", residentDtos.getPageSize());
        metadata.put("PageNumber", residentDtos.getPageNumber());
        metadata.put("TotalPages", residentDtos.getTotalPages());
        metadata.put("TotalElements", residentDtos.getTotalElements());
        metadata.put("IsFirstPage", residentDtos.isFirstPage());
        metadata.put("IsLastPage", residentDtos.isLastPage());
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(residentDto, "Residents retrieved successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(description = "Get Apartment", summary = "This is summary for category get endpoint")
    @GetMapping("all-apartments/{societyId}")
    public ResponseEntity<ApiResponse<List<GetApartmentDto>>> getApartment(
            @PathVariable("societyId") long societyId,
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(value = "searchText", required = false) String searchText
    ) throws JsonProcessingException {
        PaginationDto<GetApartmentDto> residentDtos = this._unitService.masterService.getApartments(pageNumber, pageSize, sortBy, sortDir, searchText, societyId);
        List<GetApartmentDto> residentDto = residentDtos.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", residentDtos.getPageSize());
        metadata.put("PageNumber", residentDtos.getPageNumber());
        metadata.put("TotalPages", residentDtos.getTotalPages());
        metadata.put("TotalElements", residentDtos.getTotalElements());
        metadata.put("IsFirstPage", residentDtos.isFirstPage());
        metadata.put("IsLastPage", residentDtos.isLastPage());
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(residentDto, "Apartments retrieved successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Society For Web")
    @GetMapping("/all-society")
    public ResponseEntity<ApiResponse<List<ViewSocietyDto>>> getAllSociety() {
        List<ViewSocietyDto> societyDTOS = this._unitService.masterService.getSocaityList();
        return ResponseEntity.ok(
                ApiResponse.success(societyDTOS, "All society fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Area")
    @GetMapping("/area-list/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewAreaDto>>> getAllArea(@PathVariable("societyId") long societyId, @RequestParam(defaultValue = "", required = false) String searchText) {
        List<ViewAreaDto> areaDTOS = this._unitService.masterService.getAreaList(societyId, searchText);
        return ResponseEntity.ok(
                ApiResponse.success(areaDTOS, "All area fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Apartment by societyId")
    @GetMapping("/apartment-list/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewApartmentDto>>> getAllApartmentBySocietyId(@PathVariable("societyId") long societyId, @RequestParam(defaultValue = "", required = false) String searchText) {
        List<ViewApartmentDto> apartmentDTOS = this._unitService.masterService.getApartmentList(societyId, searchText);
        return ResponseEntity.ok(
                ApiResponse.success(apartmentDTOS, "All apartment fetched successfully by society id", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Apartment")
    @GetMapping("/apartment-list/{societyId}/{areaId}")
    public ResponseEntity<ApiResponse<List<ViewApartmentDto>>> getAllApartment(@PathVariable("societyId") long societyId, @PathVariable("areaId") long areaId, @RequestParam(defaultValue = "", required = false) String searchText) {
        List<ViewApartmentDto> apartmentDTOS = this._unitService.masterService.getApartmentList(societyId, areaId, searchText);
        return ResponseEntity.ok(
                ApiResponse.success(apartmentDTOS, "All apartment fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Residents")
    @GetMapping("/resident-list/society/{societyId}/area/{areaId}/apartment/{apartmentId}")
    public ResponseEntity<ApiResponse<List<ViewComplainerDto>>> getAllResidents(@PathVariable("societyId") long societyId,
                                                                                @PathVariable("areaId") long areaId, @PathVariable("apartmentId") long apartmentId, @RequestParam(defaultValue = "", required = false) String searchText) {
        List<ViewComplainerDto> residentDTOS = this._unitService.masterService.getResidentList(societyId, areaId,apartmentId, searchText);
        return ResponseEntity.ok(
                ApiResponse.success(residentDTOS, "All resident fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Export To Excel")
    @PostMapping("/export-excel")
    public ResponseEntity<byte[]> exportAllDataToExcel(@RequestBody ExportRequestDto request) throws IOException {
        String tableName = request.getTableName();
        List<String> columns = request.getColumns();
        List<String> headers = this._unitHelper.tableHandler.getHeadersForTable(tableName);
        List<Map<String, Object>> data = this._unitHelper.tableHandler.getDataForTable(tableName, columns);
        if (headers == null) {
            throw new ResourceNotFoundException("Table Not Found");
        }
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet(tableName + "_Export");
        // Create a CellStyle for the header row
        CellStyle headerStyle = workbook.createCellStyle();
        XSSFColor lightPurple = new XSSFColor(new java.awt.Color(221, 160, 221), null);
        ((XSSFCellStyle) headerStyle).setFillForegroundColor(lightPurple);
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerStyle.setFont(headerFont);
        // Create header row
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers.get(i));
            cell.setCellStyle(headerStyle);
        }
        // Populate rows with data
        int rowNum = 1;
        for (Map<String, Object> rowData : data) {
            Row row = sheet.createRow(rowNum++);
            int cellNum = 0;
            for (String header : headers) {
                Cell cell = row.createCell(cellNum++);
                cell.setCellValue(rowData.get(header) != null ? rowData.get(header).toString() : "");
            }
        }
        // Write workbook to byte array
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();
        byte[] excelData = outputStream.toByteArray();
        // Prepare response
        HttpHeaders headersResponse = new HttpHeaders();
        headersResponse.setContentDispositionFormData("attachment", tableName + ".xlsx");
        headersResponse.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        return ResponseEntity.ok()
                .headers(headersResponse)
                .body(excelData);
    }


    @PostMapping("/send-comments")
    public ResponseEntity<ApiResponse<String>> sendComments(@Valid @RequestBody SendCommentsDto sendCommentsDto) throws SQLIntegrityConstraintViolationException {
        String msg = this._unitService.masterService.sendComments(sendCommentsDto);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, "Comment post successfully", null, HttpStatus.CREATED.value()));
        }
    }

    @Operation(summary = "Create a new comment with attachment")
    @PostMapping(value = "/send-comments-with-image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<String>> createComment(
            @Valid @RequestPart("comment") SendCommentsDto sendCommentsDto,
            @RequestPart(value = "imageFile", required = false) List<MultipartFile> imageFile) throws SQLIntegrityConstraintViolationException, IOException {
        String msg = this._unitService.masterService.sendCommentsWithImage(sendCommentsDto, imageFile);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, msg, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, "Comment post successfully", null, HttpStatus.CREATED.value()));
        }
    }


    @GetMapping("/comment-list/{complaintId}")
    public ResponseEntity<ApiResponse<List<ViewCommentsDto>>> getCommentListBySocietyId(@PathVariable("complaintId") long complaintId) {
        return ResponseEntity.ok(
                ApiResponse.success(this._unitService.masterService.getCommentList(complaintId), "Comment List retrieved successfully", null, HttpStatus.OK.value())
        );
    }


    @Operation(summary = "Fetch apartments (block & flat) for App")
    @GetMapping("/resident-society-details")
    public ResponseEntity<ApiResponse<List<ViewApartmentOfResidentsDto>>> getApartmentListOfResident(@RequestParam("ownerEmail") String email) {
        List<ViewApartmentOfResidentsDto> residentDetails = this._unitService.masterService.getApartmentListOfResident(email);
        return ResponseEntity.ok(
                ApiResponse.success(residentDetails, "Resident society List retrieved successfully", null, HttpStatus.OK.value())
        );
    }


    @PostMapping("/manage-resident")
    public ResponseEntity<ApiResponse<String>> manageResident(@Valid @RequestBody ManageResidentDto manageResidentDto) throws SQLIntegrityConstraintViolationException, ServiceException {
        String msg = this._unitService.masterService.manageResidentSocietyAndBlockWise(manageResidentDto);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error("some data missing", null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, "Resident managed successfully", null, HttpStatus.CREATED.value()));
        }
    }


    @GetMapping(value = "/image/{imageName}", produces = MediaType.IMAGE_JPEG_VALUE)
    public void downloadImage(@PathVariable("imageName") String imageName, HttpServletResponse httpServletResponse) throws IOException {
        InputStream resource = this._unitHelper.s3FileHandler.getResource(imageName);
        httpServletResponse.setContentType(MediaType.IMAGE_JPEG_VALUE);
        StreamUtils.copy(resource, httpServletResponse.getOutputStream());
    }

    @Operation(summary = "Fetch apartments (block & flat) by society with search, limit, and offset")
    @GetMapping("/{societyId}/locations")
    public ResponseEntity<ApiResponse<List<ViewApartmentOfResidentsDto>>> getApartmentsBySociety(
            @PathVariable Long societyId,
            @RequestParam(required = false) String searchText,
            @RequestParam(defaultValue = "20") int limit,
            @RequestParam(defaultValue = "0") int offset
    ) {
        List<ViewApartmentOfResidentsDto> apartments =
                this._unitService.masterService.getLocationBySociety(societyId, searchText, limit, offset);

        return ResponseEntity.ok(
                ApiResponse.success(apartments, "Locations fetched successfully", null, HttpStatus.OK.value())
        );
    }

}