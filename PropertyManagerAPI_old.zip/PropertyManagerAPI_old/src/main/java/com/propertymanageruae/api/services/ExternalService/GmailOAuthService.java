package com.propertymanageruae.api.services.ExternalService;

import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.model.Message;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.oauth2.UserCredentials;
import com.propertymanageruae.api.entities.MailLog;
import com.propertymanageruae.api.helper.GenerateEmailTemplate;
import com.propertymanageruae.api.payloads.ExternalDTO.GmailProperties;
import com.propertymanageruae.api.payloads.ExternalDTO.MailDto;
import com.propertymanageruae.api.payloads.ExternalDTO.WelcomeEmailDto;
import com.propertymanageruae.api.payloads.utils.BulkEmailResponse;
import com.propertymanageruae.api.repositories.ExternalRepository.IMailLogRepository;
import com.propertymanageruae.api.services.logger.ILoggerService;
import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.mail.Multipart;
import jakarta.mail.Session;
import jakarta.mail.internet.*;
import jakarta.mail.util.ByteArrayDataSource;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.MailSendException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.multipart.MultipartFile;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@Service
public class GmailOAuthService implements IGmailOAuthService {

    private final Gmail gmail;
    private final GmailProperties gmailProperties;

    @Autowired
    private GenerateEmailTemplate generateEmailTemplate;

    @Autowired
    private ILoggerService loggerService;

    @Autowired
    private IMailLogRepository mailLogRepository;

    @Value("${email.gateway}")
    private String mailGateway;

    private static final int BATCH_SIZE = 20;

    public GmailOAuthService(GmailProperties gmailProperties) throws Exception {
        this.gmailProperties = gmailProperties;

        UserCredentials userCredentials = UserCredentials.newBuilder()
                .setClientId(gmailProperties.getClientId())
                .setClientSecret(gmailProperties.getClientSecret())
                .setRefreshToken(gmailProperties.getRefreshToken())
                .build();

        this.gmail = new Gmail.Builder(
                GoogleNetHttpTransport.newTrustedTransport(),
                GsonFactory.getDefaultInstance(),
                new HttpCredentialsAdapter(userCredentials)
        ).setApplicationName("Property Manager Mailer")
                .build();
    }





    @Retryable(value = MailSendException.class, maxAttempts = 3, backoff = @Backoff(delay = 2000))
    private CompletableFuture<Boolean> sendMail(MailDto mailModel) {
        try {
            Properties props = new Properties();
            Session session = Session.getDefaultInstance(props, null);
            MimeMessage message = new MimeMessage(session);

            // Set From
            message.setFrom(new InternetAddress(gmailProperties.getFromEmail()));

            // Set To recipients
            for (String recipient : mailModel.getTo()) {
                message.addRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(recipient));
            }

            // Set CC recipients if present
            if (mailModel.getCc() != null && !mailModel.getCc().isEmpty()) {
                for (String cc : mailModel.getCc()) {
                    if (isValidEmail(cc.trim())) {
                        message.addRecipient(jakarta.mail.Message.RecipientType.CC, new InternetAddress(cc.trim()));
                    }
                }
            }

            // Set BCC recipients if present
            if (mailModel.getBcc() != null && !mailModel.getBcc().isEmpty()) {
                for (String bcc : mailModel.getBcc()) {
                    if (isValidEmail(bcc.trim())) {
                        message.addRecipient(jakarta.mail.Message.RecipientType.BCC, new InternetAddress(bcc.trim()));
                    }
                }
            }

            // Set Subject
            message.setSubject(mailModel.getSubject());

            // Handle body and attachments
            if (mailModel.getAttachments() != null && !mailModel.getAttachments().isEmpty()) {
                // Create multipart message for attachments
                Multipart multipart = new MimeMultipart();

                // Add body part
                MimeBodyPart textBodyPart = new MimeBodyPart();
                textBodyPart.setContent(mailModel.getBody(), "text/html; charset=utf-8");
                multipart.addBodyPart(textBodyPart);

                // Add attachments
                for (MailDto.Attachment attachment : mailModel.getAttachments()) {
                    MimeBodyPart attachmentPart = new MimeBodyPart();
                    DataSource dataSource = new ByteArrayDataSource(attachment.getData(), attachment.getType());
                    attachmentPart.setDataHandler(new DataHandler(dataSource));
                    attachmentPart.setFileName(attachment.getName());
                    multipart.addBodyPart(attachmentPart);
                }

                message.setContent(multipart);
            } else {
                // Simple HTML message without attachments
                message.setContent(mailModel.getBody(), "text/html; charset=utf-8");
            }

            // Send via Gmail OAuth
            sendMessage(message);

            // Log success
            logMailStatus(mailModel.getTo(), "true", null, mailModel.getPurpose());
            return CompletableFuture.completedFuture(true);

        } catch (Exception e) {
            logMailStatus(mailModel.getTo(), "false", e.getMessage(), mailModel.getPurpose());
            return CompletableFuture.completedFuture(false);
        }
    }

    @Async
    @Override
    public CompletableFuture<Boolean> sendEmail(MailDto request) {
        // This method now uses OAuth instead of checking mail gateway
        return sendMail(request);
    }

    @Override
    public CompletableFuture<Boolean> sendWelcomeEmail(WelcomeEmailDto welcomeEmail) {
        String body = String.format("Welcome %s %s! Your username is %s.",
                welcomeEmail.getMemberFirstName(),
                welcomeEmail.getMemberLastName(),
                welcomeEmail.getUsername());

        MailDto email = new MailDto();
        email.setTo(List.of(welcomeEmail.getToEmail()));
        email.setSubject("Welcome to our service!");
        email.setBody(body);
        email.setPurpose("WELCOME");
        return sendEmail(email);
    }

    @Async
    @Override
    public void sendBulkEmail(List<String> recipients, String name, String description, List<MultipartFile> files) {
        for (int i = 0; i < recipients.size(); i += BATCH_SIZE) {
            List<String> batch = recipients.subList(i, Math.min(i + BATCH_SIZE, recipients.size()));
            sendEmailBatch(batch, name, description, files);
        }
    }

    private void sendEmailBatch(List<String> batch, String name, String description, List<MultipartFile> files) {
        BulkEmailResponse response = new BulkEmailResponse();
        batch.forEach(recipient -> {
            try {
                sendEmailWithAttachment(recipient, name, description, files);
                logMailStatusOne(recipient, "true", null, "NOTICEBOARD");
                response.getSuccessEmails().add(recipient);
            } catch (Exception e) {
                logMailStatusOne(recipient, "false", e.getMessage(), "NOTICEBOARD");
                response.getFailedEmails().add(recipient);
                loggerService.logError("Failed to send email to " + recipient + ": " + e.getMessage());
            }
        });
    }

    @Retryable(value = Exception.class, maxAttempts = 3, backoff = @Backoff(delay = 5000))
    private void sendEmailWithAttachment(String recipient, String name, String description, List<MultipartFile> files)
            throws Exception {
        Properties props = new Properties();
        Session session = Session.getDefaultInstance(props, null);
        MimeMessage message = new MimeMessage(session);

        message.setFrom(new InternetAddress(gmailProperties.getFromEmail()));
        message.addRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(recipient));
        message.setSubject("Notice - " + name);

        // Create multipart message
        Multipart multipart = new MimeMultipart();

        // Add body part
        MimeBodyPart textBodyPart = new MimeBodyPart();
        String template = generateEmailTemplate.noticeTemplate(name,description);
        textBodyPart.setContent(template, "text/html; charset=utf-8");
        multipart.addBodyPart(textBodyPart);

        // Add file attachments if present
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (file != null && !file.isEmpty()) {
                    MimeBodyPart attachmentPart = new MimeBodyPart();
                    DataSource dataSource = new ByteArrayDataSource(file.getBytes(), file.getContentType());
                    attachmentPart.setDataHandler(new DataHandler(dataSource));
                    attachmentPart.setFileName(Objects.requireNonNull(file.getOriginalFilename()));
                    multipart.addBodyPart(attachmentPart);
                }
            }
        }

        message.setContent(multipart);

        // Send via Gmail OAuth
        sendMessage(message);
    }

    @Recover
    private void recoverFromEmailFailure(Exception e, String recipient, String name, List<MultipartFile> files) {
        loggerService.logError("Failed to send email to " + recipient + " after multiple retries: " + e.getMessage());
        logMailStatusOne(recipient, "false", e.getMessage(), "NOTICEBOARD");
    }

    // Simple method for sending plain emails (as in your original example)
    @Override
    public void sendMailOAuth(String to, String subject, String bodyText) throws Exception {
        Properties props = new Properties();
        Session session = Session.getDefaultInstance(props, null);
        MimeMessage email = new MimeMessage(session);
        email.setFrom(new InternetAddress(gmailProperties.getFromEmail()));
        email.addRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(to));
        email.setSubject(subject);
        email.setContent(bodyText, "text/html; charset=utf-8");
        sendMessage(email);
    }



    // Helper method to send message via Gmail API
    private void sendMessage(MimeMessage email) throws Exception {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        email.writeTo(buffer);
        String encodedEmail = Base64.getUrlEncoder().encodeToString(buffer.toByteArray());
        Message message = new Message();
        message.setRaw(encodedEmail);
        gmail.users().messages().send("me", message).execute();
    }

    // Logging methods (same as original)
    private void logMailStatus(List<String> recipients, String status, String errorMsg, String purpose) {
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of("UTC"));
        for (String recipient : recipients) {
            MailLog mailLog = new MailLog();
            mailLog.setMailFrom(gmailProperties.getFromEmail());
            mailLog.setMailDate(currentDateTime);
            mailLog.setMailTo(recipient);
            mailLog.setStatus(status);
            mailLog.setErrorMsg(errorMsg);
            mailLog.setPurpose(purpose);
            mailLog.setSmtp("GmailOAuth");
            mailLogRepository.save(mailLog);
        }
    }

    private void logMailStatusOne(String recipient, String status, String errorMsg, String purpose) {
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of("UTC"));
        MailLog mailLog = new MailLog();
        mailLog.setMailFrom(gmailProperties.getFromEmail());
        mailLog.setMailDate(currentDateTime);
        mailLog.setMailTo(recipient);
        mailLog.setStatus(status);
        mailLog.setErrorMsg(errorMsg);
        mailLog.setPurpose(purpose);
        mailLog.setSmtp("GmailOAuth");
        mailLogRepository.save(mailLog);
    }

    private boolean isValidEmail(String email) {
        try {
            InternetAddress internetAddress = new InternetAddress(email);
            internetAddress.validate();
            return true;
        } catch (AddressException e) {
            return false;
        }
    }
}