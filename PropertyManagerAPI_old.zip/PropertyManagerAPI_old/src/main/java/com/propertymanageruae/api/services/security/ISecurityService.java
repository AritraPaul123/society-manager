package com.propertymanageruae.api.services.security;

public interface ISecurityService {
    String encryptText(String plainText);
    String decryptText(String hexCipher);
}