package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.entities.Apartment;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import org.springframework.data.jpa.domain.Specification;

public class ApartmentQueryWithMultiClause {
    // Filters apartments by societyId
    public static Specification<Apartment> hasSocietyId(Long societyId) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get("society").get("id"), societyId);
    }

    // Filters apartments with active residents (or no resident)
    public static Specification<Apartment> withActiveResidentsOnly() {
        return (root, query, criteriaBuilder) -> {
            // Ensure distinct results
            query.distinct(true);

            // Create a LEFT JOIN to residents
            Join<Object, Object> residentJoin = root.join("resident", JoinType.LEFT);

            // Subquery to find deleted residents
            Subquery<Long> subquery = query.subquery(Long.class);
            Root<?> subRoot = subquery.from(residentJoin.getJavaType());
            subquery.select(subRoot.get("id"));
            subquery.where(
                    criteriaBuilder.equal(subRoot.get("id"), residentJoin.get("id")),
                    criteriaBuilder.isTrue(subRoot.get("isDelete"))
            );

            // Return apartments with either no resident or only non-deleted residents
            return criteriaBuilder.or(
                    criteriaBuilder.isNull(residentJoin),
                    criteriaBuilder.not(criteriaBuilder.exists(subquery))
            );
        };
    }
}