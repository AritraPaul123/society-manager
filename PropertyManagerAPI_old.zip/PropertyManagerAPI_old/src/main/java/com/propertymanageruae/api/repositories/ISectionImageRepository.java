package com.propertymanageruae.api.repositories;
import com.propertymanageruae.api.entities.SectionImage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ISectionImageRepository extends JpaRepository<SectionImage,Long> {
    List<SectionImage> findByHomeInspectionId(Long homeInspectionId);

}
