package com.propertymanageruae.api.payloads.master;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.propertymanageruae.api.entities.Area;
import com.propertymanageruae.api.entities.Resident;
import com.propertymanageruae.api.entities.Society;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetApartmentDto {
    private long id;
    private String block;
    private String floor;
    private String flat;
    private String intercom;
    private ViewAreaDto area;
    private ViewSocietyDto society;
    private List<GetResidentDto> resident;
    private boolean isDelete;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private LocalDateTime deletedAt;

}