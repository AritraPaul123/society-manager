package com.propertymanageruae.api.payloads.assignment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssignmentSlotDTO {
    private Long id;
    private String startTime;
    private String endTime;
    private String day;
    private String duration;
    private AssignmentTypeDTO assignmentType;
}