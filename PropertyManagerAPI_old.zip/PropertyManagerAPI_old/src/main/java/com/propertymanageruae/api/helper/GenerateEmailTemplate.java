package com.propertymanageruae.api.helper;

import lombok.SneakyThrows;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Year;

@Component
public class GenerateEmailTemplate {

    @SneakyThrows
    public String noticeTemplate(String subject,String description) {
        ClassPathResource resource = new ClassPathResource("templates/EmailTemplate/notice-email-template.html");
        var htmlContent= StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
        htmlContent = htmlContent.replace("[#SUBJECT]", subject);
        htmlContent = htmlContent.replace("[#DESCRIPTION]", description);
        htmlContent = htmlContent.replace("[#CURRENT_YEAR]", String.valueOf(Year.now().getValue()));
        return htmlContent;
    }

    @SneakyThrows
    private void sendEmailUsingTemplate() throws IOException {
        ClassPathResource resource = new ClassPathResource("templates/EmailTemplate/notice-email-template.html");
        var htmlContent= StreamUtils.copyToString(resource.getInputStream(), StandardCharsets.UTF_8);
        htmlContent = htmlContent.replace("[#BOOKING_DATE]", "2024-10-10");
        htmlContent = htmlContent.replace("[#BOOKING_TIME]", "10:00 AM");
    }
    //    private String generatePassengerHtml(List<PaxInfo> passengers, boolean isReturn) {
    //        StringBuilder html = new StringBuilder();
    //        for (PaxInfo pax : passengers) {
    //            String baggage = isReturn ? pax.getReturnBaggage() : pax.getOnwardBaggage();
    //            html.append(String.format("""
    //                <div style="margin-bottom: 10px;">
    //                    <div style="font-size: 12px; font-weight: bold;">%s</div>
    //                    <div style="font-size: 11px; color: #666;">Baggage: %s</div>
    //                </div>
    //                """, pax.getFullName(), baggage != null ? baggage : "Not included"));
    //        }
    //        return html.toString();
    //    }
}