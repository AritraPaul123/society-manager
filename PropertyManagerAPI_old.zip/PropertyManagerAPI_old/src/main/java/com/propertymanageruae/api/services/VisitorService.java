package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.Apartment;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.entities.Visitor;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.visitor.VisitorDto;
import com.propertymanageruae.api.repositories.VisitorRepository;
import com.propertymanageruae.api.repositories.IApartmentRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VisitorService {

    @Autowired
    private VisitorRepository visitorRepository;

    @Autowired
    private IApartmentRepository apartmentRepository;
    
    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    public VisitorDto visitorCheckIn(VisitorDto dto) {
        Visitor visitor = new Visitor();
        visitor.setName(dto.getName());
        visitor.setMobileNumber(dto.getMobileNumber());
        visitor.setVisitPurpose(dto.getVisitPurpose());
        visitor.setGateNumber(dto.getGateNumber());
        visitor.setPhotoUrl(dto.getPhotoUrl());
        visitor.setEmiratesId(dto.getEmiratesId());
        visitor.setCompanyName(dto.getCompanyName());
        
        // Repeat Visitor Intelligence
        if (dto.getEmiratesId() != null) {
            visitorRepository.findFirstByEmiratesIdOrderByCheckInTimeDesc(dto.getEmiratesId())
                .ifPresent(lastVisit -> {
                    visitor.setIsRepeatVisitor(true);
                    visitor.setVisitCount(lastVisit.getVisitCount() + 1);
                    visitor.setLastVisitDate(lastVisit.getCheckInTime());
                });
        }

        if (dto.getApartmentId() != null) {
            Apartment apt = apartmentRepository.findById(dto.getApartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Apartment", "id", String.valueOf(dto.getApartmentId())));
            visitor.setApartment(apt);
        }
        
        if (dto.getGuardId() != null) {
            User guard = userRepository.findById(dto.getGuardId())
                    .orElseThrow(() -> new ResourceNotFoundException("User", "id", String.valueOf(dto.getGuardId())));
            visitor.setGuard(guard);
        }

        visitor.setCheckInTime(LocalDateTime.now());
        visitor.setStatus("CHECKED_IN");
        
        Visitor saved = visitorRepository.save(visitor);
        return mapToDto(saved);
    }

    public VisitorDto visitorCheckOut(Long visitorId) {
        Visitor visitor = visitorRepository.findById(visitorId)
                .orElseThrow(() -> new ResourceNotFoundException("Visitor", "id", String.valueOf(visitorId)));
        
        visitor.setCheckOutTime(LocalDateTime.now());
        visitor.setStatus("CHECKED_OUT");
        Visitor saved = visitorRepository.save(visitor);
        return mapToDto(saved);
    }

    public List<VisitorDto> getAllActiveVisitors() {
        return visitorRepository.findByStatus("CHECKED_IN").stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }
    
    public List<VisitorDto> getAllVisitors() {
        return visitorRepository.findAll().stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    public VisitorDto findByEmiratesId(String emiratesId) {
        return visitorRepository.findFirstByEmiratesIdOrderByCheckInTimeDesc(emiratesId)
                .map(this::mapToDto)
                .orElse(null);
    }

    private VisitorDto mapToDto(Visitor visitor) {
        VisitorDto dto = modelMapper.map(visitor, VisitorDto.class);
        if (visitor.getApartment() != null) {
            dto.setApartmentId(visitor.getApartment().getId());
            dto.setApartmentNumber(visitor.getApartment().getFlat());
        }
        if (visitor.getGuard() != null) {
            dto.setGuardId(visitor.getGuard().getId());
            dto.setGuardName(visitor.getGuard().getName());
        }
        return dto;
    }
}
