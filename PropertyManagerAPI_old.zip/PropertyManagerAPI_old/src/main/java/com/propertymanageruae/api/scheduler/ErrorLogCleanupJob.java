package com.propertymanageruae.api.scheduler;

import com.propertymanageruae.api.services.utils.IErrorLogService;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Component
public class ErrorLogCleanupJob {

    private final IErrorLogService errorLogService;

    public ErrorLogCleanupJob(IErrorLogService errorLogService) {
        this.errorLogService = errorLogService;
    }

    // run daily at 1:30 AM
    @Scheduled(cron = "0 30 1 * * *")
    @SchedulerLock(name = "ErrorLogCleanupJob_cleanUp", lockAtLeastFor = "PT5M", lockAtMostFor = "PT1H")
    public void cleanOldLogs() {
        Instant cutoff = Instant.now().minus(5, ChronoUnit.DAYS);
        Timestamp ts = Timestamp.from(cutoff);
        errorLogService.deleteLogsOlderThan(ts);
    }
}