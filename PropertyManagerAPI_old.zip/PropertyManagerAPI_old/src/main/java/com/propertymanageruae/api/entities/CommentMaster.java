package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "commentMaster")
public class CommentMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "comments")
    private String comments;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "complaintId", nullable = false)
    @JsonBackReference
    private Complaint complaint;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "societyId", nullable = false)
    @JsonBackReference
    private Society society;
    @Column(name = "commentBy")
    private long commentBy;
    @Column(name = "userType")
    private String userType;
    @Column(name = "imageUrl")
    private String imageUrl;
    @OneToMany(mappedBy = "comment", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CommentImage> images = new ArrayList<>();
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
}