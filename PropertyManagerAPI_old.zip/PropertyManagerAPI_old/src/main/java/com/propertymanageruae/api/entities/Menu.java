package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Table(name = "menus")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(length = 100, nullable = false)
    private String name;

    @Column(length = 100)
    private String icon; // Menu icon

    @Column(length = 100)
    private String path; // Relative path

    @Column(length = 200)
    private String description;

    @Column(name = "order_no")
    private Integer orderNo;

    @Column(name = "is_active", nullable = false)
    private boolean isActive = true;

    // Self-referencing parent menu
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private Menu parentMenu;

    // Self-referencing child menus
    @OneToMany(mappedBy = "parentMenu", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Menu> childMenus;
}