package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "resident")
@Builder
public class Resident {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "bhk", nullable = true)
    private String bhk;
    @Column(name = "sq_feet_area", nullable = true)
    private String sqFeetArea;
    @Column(name = "owner_name", nullable = true)
    private String ownerName;
    @Column(name = "owner_phone", nullable = true)
    private String ownerPhone;
    @Column(name = "owner_secondary_phone", nullable = true)
    private String ownerSecondaryPhone;
    @Column(name = "owner_email", nullable = true)
    private String ownerEmail;
    @Column(name = "tenant_name", nullable = true)
    private String tenantName;
    @Column(name = "tenant_phone", nullable = true)
    private String tenantPhone;
    @Column(name = "tenant_secondary_phone", nullable = true)
    private String tenantSecondaryPhone;
    @Column(name = "tenant_email", nullable = true)
    private String tenantEmail;
    @Column(name = "resident_type", nullable = false)
    private String residentType;
    @Column(name = "parking", nullable = true)
    private Boolean parking;
    @Column(name = "accommodation_type", nullable = true)
    private String accommodationType;
    @Column(name = "primary_owner_phone", nullable = true)
    private String primaryOwnerPhone;
    @Column(name = "primary_tenant_phone", nullable = true)
    private String primaryTenantPhone;
    @Column(name = "meter_id", nullable = true)
    private String meterId;
    @Column(name = "consumer_id", nullable = true)
    private String consumerId;
    @Column(name = "sanctioned_load_kw", nullable = true)
    private String sanctionedLoadKW;
    @Column(name = "sanctioned_dg_load_kv", nullable = true)
    private String sanctionedDGLoadKV;
    @Column(name = "number_piped_gas_users", nullable = true)
    private Integer numberPipedGasUsers;
    @Column(name = "possession_date", nullable = true)
    private LocalDateTime possessionDate;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "apartment_id", nullable = false)
    @JsonBackReference
    private Apartment apartment;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "area_id", nullable = false)
    @JsonBackReference
    private Area area;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "society_id", nullable = false)
    @JsonBackReference
    private Society society;
    @Column(name = "password")
    private String password;

    @Column(name = "owner_member_id")
    private String ownerMemberId;
    @Column(name = "tenant_member_id")
    private String tenantMemberId;
    @Column(name = "role_id", columnDefinition = "BIGINT DEFAULT 0")
    private long roleId = 0L;
    @Column(name = "roles")
    private String roles;
    @Column(name = "status",columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean status;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "memberId", referencedColumnName = "id", nullable = false)//memberId
    private User user;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Column(nullable = true)
    private LocalDateTime deletedAt;
    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}