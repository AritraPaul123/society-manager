//package com.propertymanageruae.api.scheduler;
//
//public class QuartzConfig {
//}