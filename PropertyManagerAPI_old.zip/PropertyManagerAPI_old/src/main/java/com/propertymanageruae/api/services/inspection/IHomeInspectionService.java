package com.propertymanageruae.api.services.inspection;

import com.propertymanageruae.api.payloads.inspection.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;


public interface IHomeInspectionService {

    String createInspection(HomeInspectionDTO inspectionDTO) throws SQLIntegrityConstraintViolationException;
    ViewHomeInspectionDTO editInspection(HomeInspectionDTO inspectionDTO, long id) throws SQLIntegrityConstraintViolationException;
    ViewHomeInspectionDTO finalSubmit(InspectionFinalRequest request, long inspectionId) throws SQLIntegrityConstraintViolationException;
    List<ViewHomeInspectionDTO> getAllInspections(long societyId, String searchText, String dateRange) throws SQLIntegrityConstraintViolationException;
    String uploadSectionImage(SectionImageDTO dto, MultipartFile file) throws IOException;
    byte[] generateInspectionPDF(Long inspectionId) throws Exception;

}