package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.user.BiometricEnrollmentDto;
import com.propertymanageruae.api.services.BiometricAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/biometrics")
public class BiometricAuth1Controller {

    @Autowired
    private BiometricAuthService biometricAuthService;

    @PostMapping("/{userId}/enroll")
    public ResponseEntity<String> enrollBiometric(
            @PathVariable Long userId,
            @RequestBody BiometricEnrollmentDto enrollmentDto) {
        biometricAuthService.enrollBiometric(userId, enrollmentDto);
        return ResponseEntity.ok("Biometric enrolled successfully");
    }

    @PostMapping("/{userId}/verify-passcode")
    public ResponseEntity<Boolean> verifyPasscode(
            @PathVariable Long userId,
            @RequestParam String passcode) {
        boolean verified = biometricAuthService.verifyPasscode(userId, passcode);
        return ResponseEntity.ok(verified);
    }
}
