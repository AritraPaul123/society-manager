package com.propertymanageruae.api.payloads.ExternalDTO;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.context.annotation.Bean;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class MailDto {
    private String name;
    private List<String> to;
    private List<String> cc;  // Optional for CC
    private List<String> bcc;
    private String from;
    private String subject;
    private String body;
    private List<Attachment> attachments;
    private String purpose;
    @Data
    public static class Attachment {
        private String name;
        private String type;  // e.g., "application/pdf", "image/jpeg"
        private byte[] data;
    }
}