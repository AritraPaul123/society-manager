package com.propertymanageruae.api.entities;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "annual_rent", precision = 12, scale = 2)
    private BigDecimal annualRent;

    @Column(name = "installments")
    private Integer installments = 1;

    @Column(name = "no_of_months_period")
    private Integer noOfMonthsPeriod = 12;

    @Column(name = "security_deposit", precision = 12, scale = 2)
    private BigDecimal securityDeposit = BigDecimal.ZERO;

    @Column(name = "vat_tax", precision = 12, scale = 2)
    private BigDecimal vatTax = BigDecimal.ZERO;

    @Column(name = "broker_fee", precision = 12, scale = 2)
    private BigDecimal brokerFee = BigDecimal.ZERO;

    @Column(name = "ejari_number")
    private String ejariNumber;

    @Column(name = "total_payment_received", precision = 12, scale = 2)
    private BigDecimal totalPaymentReceived = BigDecimal.ZERO;

    @Column(name = "remaining_balance", precision = 12, scale = 2)
    private BigDecimal remainingBalance;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    private Integer paymentPerYear;
    private Integer graceperiod;
    private LocalDate paymentDate;
    private Integer contractValue;
    private Integer rentPerSqm;

    @ManyToOne
    @JoinColumn(name = "lease_id")
    @JsonIgnoreProperties("payments")
    private Lease lease;

    @OneToMany(mappedBy = "payment", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("payment")
    private List<PaymentInstallment> paymentInstallments = new ArrayList<>();

    @OneToMany(mappedBy = "payment", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("payment")
    private List<PaymentTransaction> manualTransactions = new ArrayList<>();
}

