package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.Patrol;
import com.propertymanageruae.api.entities.PatrolLog;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.patrol.PatrolDto;
import com.propertymanageruae.api.repositories.PatrolRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.List;

@Service
public class PatrolService {

    @Autowired
    private PatrolRepository patrolRepository;

    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PatrolRouteRepository routeRepository;

    @Autowired
    private QRPointRepository qrPointRepository;

    @Autowired
    private GuardPerformanceService performanceService;

    public PatrolDto startPatrol(Long guardId, Long routeId, Boolean isOffline) {
        User guard = userRepository.findById(guardId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", String.valueOf(guardId)));

        Patrol patrol = new Patrol();
        patrol.setGuard(guard);
        patrol.setStartTime(LocalDateTime.now());
        patrol.setStatus("IN_PROGRESS");
        patrol.setIsOffline(isOffline);
        
        if (routeId != null) {
            PatrolRoute route = routeRepository.findById(routeId)
                .orElseThrow(() -> new ResourceNotFoundException("PatrolRoute", "id", String.valueOf(routeId)));
            patrol.setRoute(route);
        }
        
        Patrol saved = patrolRepository.save(patrol);
        return mapToDto(saved);
    }

    public PatrolDto pausePatrol(Long patrolId) {
        Patrol patrol = patrolRepository.findById(patrolId)
                .orElseThrow(() -> new ResourceNotFoundException("Patrol", "id", String.valueOf(patrolId)));
        
        patrol.setStatus("PAUSED");
        patrol.setPauseTime(LocalDateTime.now());
        patrol.setPausedCount(patrol.getPausedCount() + 1);
        
        return mapToDto(patrolRepository.save(patrol));
    }

    public PatrolDto resumePatrol(Long patrolId) {
        Patrol patrol = patrolRepository.findById(patrolId)
                .orElseThrow(() -> new ResourceNotFoundException("Patrol", "id", String.valueOf(patrolId)));
        
        patrol.setStatus("IN_PROGRESS");
        patrol.setResumeTime(LocalDateTime.now());
        
        return mapToDto(patrolRepository.save(patrol));
    }

    public PatrolDto logCheckpoint(Long patrolId, Long qrPointId, String comments, String photoUrl, java.math.BigDecimal lat, java.math.BigDecimal lng) {
        Patrol patrol = patrolRepository.findById(patrolId)
                .orElseThrow(() -> new ResourceNotFoundException("Patrol", "id", String.valueOf(patrolId)));
        
        QRPoint qrPoint = qrPointRepository.findById(qrPointId)
                .orElseThrow(() -> new ResourceNotFoundException("QRPoint", "id", String.valueOf(qrPointId)));

        PatrolLog log = new PatrolLog();
        log.setPatrol(patrol);
        log.setQrPoint(qrPoint);
        log.setCheckpointName(qrPoint.getLocationName());
        log.setComments(comments);
        log.setPhotoUrl(photoUrl);
        log.setLatitude(lat);
        log.setLongitude(lng);
        log.setScannedTime(LocalDateTime.now());
        
        patrol.getLogs().add(log);
        Patrol saved = patrolRepository.save(patrol);
        return mapToDto(saved);
    }

    public PatrolDto endPatrol(Long patrolId) {
        Patrol patrol = patrolRepository.findById(patrolId)
                .orElseThrow(() -> new ResourceNotFoundException("Patrol", "id", String.valueOf(patrolId)));
        
        patrol.setEndTime(LocalDateTime.now());
        patrol.setStatus("COMPLETED");
        patrol.setSyncStatus("SYNCED");

        Patrol saved = patrolRepository.save(patrol);
        
        // Track performance
        performanceService.incrementPatrolStats(patrol.getGuard().getId(), true);
        
        return mapToDto(saved);
    }

    @Transactional
    public List<PatrolDto> syncPatrols(List<PatrolDto> offlinePatrols) {
        List<PatrolDto> syncedResults = new ArrayList<>();
        for (PatrolDto dto : offlinePatrols) {
            // Complex sync logic: re-create patrol and logs from offline data
            // For now, simple implementation
            PatrolDto started = startPatrol(dto.getGuardId(), dto.getRouteId(), true);
            for (PatrolDto.PatrolLogDto logDto : dto.getLogs()) {
                logCheckpoint(started.getId(), logDto.getQrPointId(), logDto.getComments(), logDto.getPhotoUrl(), logDto.getLatitude(), logDto.getLongitude());
            }
            syncedResults.add(endPatrol(started.getId()));
        }
        return syncedResults;
    }
    
    public List<PatrolDto> getAllPatrols() {
        return patrolRepository.findAll().stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private PatrolDto mapToDto(Patrol patrol) {
        PatrolDto dto = new PatrolDto();
        dto.setId(patrol.getId());
        dto.setGuardId(patrol.getGuard().getId());
        dto.setGuardName(patrol.getGuard().getName());
        dto.setStartTime(patrol.getStartTime());
        dto.setEndTime(patrol.getEndTime());
        dto.setStatus(patrol.getStatus());
        dto.setIsOffline(patrol.getIsOffline());
        dto.setSyncStatus(patrol.getSyncStatus());
        dto.setPauseTime(patrol.getPauseTime());
        dto.setResumeTime(patrol.getResumeTime());
        dto.setPausedCount(patrol.getPausedCount());
        
        if (patrol.getRoute() != null) {
            dto.setRouteId(patrol.getRoute().getId());
            dto.setRouteName(patrol.getRoute().getRouteName());
        }
        
        if (patrol.getLogs() != null) {
            List<PatrolDto.PatrolLogDto> logDtos = patrol.getLogs().stream().map(log -> {
                PatrolDto.PatrolLogDto logDto = new PatrolDto.PatrolLogDto();
                logDto.setId(log.getId());
                logDto.setCheckpointName(log.getCheckpointName());
                logDto.setScannedTime(log.getScannedTime());
                logDto.setComments(log.getComments());
                logDto.setPhotoUrl(log.getPhotoUrl());
                logDto.setLatitude(log.getLatitude());
                logDto.setLongitude(log.getLongitude());
                logDto.setIsPhotoMandatory(log.getIsPhotoMandatory());
                if (log.getQrPoint() != null) {
                    logDto.setQrPointId(log.getQrPoint().getId());
                }
                return logDto;
            }).collect(Collectors.toList());
            dto.setLogs(logDtos);
        } else {
            dto.setLogs(new ArrayList<>());
        }
        return dto;
    }
}
