package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.entities.Apartment;
import com.propertymanageruae.api.payloads.master.ViewApartmentOfResidentsDto;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public class ApartmentSpecification {
    public static Specification<Apartment> searchByText(String searchText, long societyId,long areaId) {
        return (root, query, criteriaBuilder) -> {
            Predicate societyPredicate = criteriaBuilder.equal(root.get("society").get("id"), societyId);
            Predicate areaPredicate = criteriaBuilder.equal(root.get("area").get("id"), areaId);
            if (searchText == null || searchText.trim().isEmpty()) {
                return societyPredicate; // Only filter by societyId if searchText is empty
            }
            String likePattern = "%" + searchText.toLowerCase() + "%";
            Predicate blockPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("block")), likePattern);
            Predicate flatPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("flat")), likePattern);
            Predicate searchPredicate = criteriaBuilder.or(blockPredicate, flatPredicate);
            return criteriaBuilder.and(areaPredicate, societyPredicate,searchPredicate);
        };
    }
    public static Specification<Apartment> searchByTextAndSocietyId(String searchText, long societyId) {
        return (root, query, criteriaBuilder) -> {
            Predicate societyPredicate = criteriaBuilder.equal(root.get("society").get("id"), societyId);
            if (searchText == null || searchText.trim().isEmpty()) {
                return societyPredicate; // Only filter by societyId if searchText is empty
            }
            String likePattern = "%" + searchText.toLowerCase() + "%";
            Predicate blockPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("block")), likePattern);
            Predicate flatPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("flat")), likePattern);
            Predicate searchPredicate = criteriaBuilder.or(blockPredicate, flatPredicate);
            return criteriaBuilder.and(societyPredicate,searchPredicate);
        };
    }

    public  static Specification<Apartment> getLocationBySocietyId(Long societyId, String searchText) {

        return (root, query, cb) -> {
            // Join Apartment → Area → Society
            Join<Object, Object> areaJoin = root.join("area");
            Join<Object, Object> societyJoin = areaJoin.join("society");

            // Base predicate
            Predicate societyPredicate = cb.equal(societyJoin.get("id"), societyId);

            // If no search text, return only society filter
            if (searchText == null || searchText.trim().isEmpty()) {
                return societyPredicate;
            }

            String likePattern = "%" + searchText.toLowerCase() + "%";
            Predicate blockPredicate = cb.like(cb.lower(root.get("block")), likePattern);
            Predicate flatPredicate = cb.like(cb.lower(root.get("flat")), likePattern);
            Predicate searchPredicate = cb.or(blockPredicate, flatPredicate);

            return cb.and(societyPredicate, searchPredicate);
        };
    }
}