package com.propertymanageruae.api.services.ExternalService;


import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class GmailTokenService implements IGmailTokenService{

    @Value("${google.client-id}")
    private String clientId;

    @Value("${google.client-secret}")
    private String clientSecret;
    @Value("${google.refresh-token}")
    private String refreshToken;
    @Override
    public String getAccessToken() throws IOException {
        GoogleCredential credential = new GoogleCredential.Builder()
                .setClientSecrets(clientId, clientSecret)
                .setTransport(new com.google.api.client.http.javanet.NetHttpTransport())
                .setJsonFactory(com.google.api.client.json.jackson2.JacksonFactory.getDefaultInstance())
                .build()
                .setRefreshToken(refreshToken);

        credential.refreshToken();
        return credential.getAccessToken();
    }
}