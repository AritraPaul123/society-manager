package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.payloads.patrol.PatrolRouteDto;
import com.propertymanageruae.api.repositories.*;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PatrolRouteService {

    @Autowired
    private PatrolRouteRepository patrolRouteRepository;

    @Autowired
    private SocietyRepository societyRepository;

    @Autowired
    private QRPointRepository qrPointRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Transactional
    public PatrolRouteDto createRoute(PatrolRouteDto routeDto) {
        PatrolRoute route = new PatrolRoute();
        route.setRouteName(routeDto.getRouteName());
        route.setDescription(routeDto.getDescription());
        route.setFrequency(routeDto.getFrequency());
        
        Society society = societyRepository.findById(routeDto.getSocietyId())
                .orElseThrow(() -> new RuntimeException("Society not found"));
        route.setSociety(society);

        if (routeDto.getQrPoints() != null) {
            for (PatrolRouteDto.RouteQRPointDto pointDto : routeDto.getQrPoints()) {
                QRPoint qrPoint = qrPointRepository.findById(pointDto.getQrPointId())
                        .orElseThrow(() -> new RuntimeException("QR Point not found: " + pointDto.getQrPointId()));
                
                RouteQRPoint routeQRPoint = new RouteQRPoint();
                routeQRPoint.setRoute(route);
                routeQRPoint.setQrPoint(qrPoint);
                routeQRPoint.setSequenceOrder(pointDto.getSequenceOrder());
                routeQRPoint.setIsMandatory(pointDto.getIsMandatory());
                
                route.getQrPoints().add(routeQRPoint);
            }
        }

        PatrolRoute savedRoute = patrolRouteRepository.save(route);
        return convertToDto(savedRoute);
    }

    public List<PatrolRouteDto> getRoutesBySociety(Long societyId) {
        Society society = societyRepository.findById(societyId)
                .orElseThrow(() -> new RuntimeException("Society not found"));
        return patrolRouteRepository.findBySociety(society).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private PatrolRouteDto convertToDto(PatrolRoute route) {
        PatrolRouteDto dto = modelMapper.map(route, PatrolRouteDto.class);
        if (route.getQrPoints() != null) {
            dto.setQrPoints(route.getQrPoints().stream()
                .map(p -> new PatrolRouteDto.RouteQRPointDto(
                    p.getQrPoint().getId(),
                    p.getQrPoint().getLocationName(),
                    p.getSequenceOrder(),
                    p.getIsMandatory()))
                .collect(Collectors.toList()));
        }
        return dto;
    }
}
