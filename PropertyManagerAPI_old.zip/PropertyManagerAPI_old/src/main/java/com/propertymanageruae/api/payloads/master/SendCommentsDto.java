package com.propertymanageruae.api.payloads.master;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.propertymanageruae.api.entities.Complaint;
import com.propertymanageruae.api.entities.Society;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendCommentsDto {
    @NotEmpty(message = "Please write any comments before send")
    private String comments;
    private long complaintId;
    private long societyId;
    private long commentBy;
    private String userType;
}