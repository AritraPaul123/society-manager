package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Role;
import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.entities.UserRoleMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IUserRoleMappingRepository extends JpaRepository<UserRoleMapping, Long>, JpaSpecificationExecutor<UserRoleMapping> {
    boolean existsByUserAndRoleAndSociety(User user, Role role, Society society);
    void deleteByUserAndSociety(User user, Society society);

    List<UserRoleMapping> findByUser(User user);

    List<UserRoleMapping> findByUserAndSociety(User user, Society society);

    @Modifying
    @Query("UPDATE UserRoleMapping urm SET urm.role = :role, urm.updatedAt = CURRENT_TIMESTAMP WHERE urm.user = :user AND urm.society = :society")
    void updateRoleByUserAndSociety(@Param("user") User user, @Param("society") Society society, @Param("role") Role role);

}