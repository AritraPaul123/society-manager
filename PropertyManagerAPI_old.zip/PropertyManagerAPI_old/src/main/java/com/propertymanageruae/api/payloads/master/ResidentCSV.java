package com.propertymanageruae.api.payloads.master;

import com.opencsv.bean.CsvBindByName;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResidentCSV {
    @CsvBindByName(column = "BLOCK")
    private String block;

    @CsvBindByName(column = "Flat")
    private String flat;

    @CsvBindByName(column = "BHK")
    private String bhk;

    @CsvBindByName(column = "Sq Feet Area")
    private String sqFeetArea;

    @CsvBindByName(column = "Owner Name")
    private String ownerName;

    @CsvBindByName(column = "Owner Phone")
    private String ownerPhone;

    @CsvBindByName(column = "Owner Secondary Phone")
    private String ownerSecondaryPhone;

    @CsvBindByName(column = "Owner Email")
    private String ownerEmail;

    @CsvBindByName(column = "Tenant Name")
    private String tenantName;

    @CsvBindByName(column = "Tenant Phone")
    private String tenantPhone;

    @CsvBindByName(column = "Tenant Secondary Phone")
    private String tenantSecondaryPhone;

    @CsvBindByName(column = "Tenant Email")
    private String tenantEmail;

    @CsvBindByName(column = "Resident Type")
    private String residentType; // Owner or Tenant

    @CsvBindByName(column = "PARKING")
    private Boolean parking;

    @CsvBindByName(column = "Accommodation Type")
    private String accommodationType; // VACANT or Occupied by Tenant

    @CsvBindByName(column = "Primary Owner Phone")
    private String primaryOwnerPhone;

    @CsvBindByName(column = "Primary Tenant Phone")
    private String primaryTenantPhone;

    @CsvBindByName(column = "Meter Id")
    private String meterId;

    @CsvBindByName(column = "Consumer id")
    private String consumerId;

    @CsvBindByName(column = "Sanctioned Load (KW)")
    private String sanctionedLoadKW;

    @CsvBindByName(column = "Sanctioned DG Load (KV)")
    private String sanctionedDGLoadKV;

    @CsvBindByName(column = "Number Piped Gas Users")
    private Integer numberPipedGasUsers;

    @CsvBindByName(column = "Possession Date")
    private String possessionDate; // Storing as a String for easier CSV handling of date

}