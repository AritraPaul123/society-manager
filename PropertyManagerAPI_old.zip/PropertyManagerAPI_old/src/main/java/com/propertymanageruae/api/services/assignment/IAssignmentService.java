package com.propertymanageruae.api.services.assignment;

import com.propertymanageruae.api.payloads.assignment.AssignmentRuleDTO;
import com.propertymanageruae.api.payloads.assignment.AssignmentSlotDTO;

import java.util.List;


public interface IAssignmentService {

    List<AssignmentRuleDTO> getAllAssignmentRules();

    AssignmentRuleDTO getAssignmentRuleById(long id);

    /**
     * Add a new assignment rule while handling related entities (e.g., slots, category, subcategory, user).
     * Uses Optimistic Locking for concurrency control.
     */
    AssignmentRuleDTO addAssignmentRule(AssignmentRuleDTO assignmentRuleDTO);

    /**
     * Update an existing assignment rule while ensuring all related entities are correctly updated.
     * Uses Optimistic Locking for concurrency control.
     */
    AssignmentRuleDTO updateAssignmentRule(long id, AssignmentRuleDTO assignmentRuleDTO);

    /**
     * Delete an assignment rule while ensuring related slots and types are removed.
     * Avoids cascading deletion of the category, subcategory, or user.
     */
    boolean deleteAssignmentRule(long id);

    /**
     * Handle assignment slot creation separately.
     */
    boolean addAssignmentSlots(long ruleId, List<AssignmentSlotDTO> slots);

    /**
     * Delete assignment slots associated with a rule, without deleting the rule itself.
     */
    boolean deleteAssignmentSlots(long ruleId);
}