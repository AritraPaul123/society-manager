package com.propertymanageruae.api.payloads.complaint;

import com.propertymanageruae.api.entities.Apartment;
import com.propertymanageruae.api.entities.CommentMaster;
import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.payloads.category.CategoryDTO;
import com.propertymanageruae.api.payloads.category.SubCategoryDTO;
import com.propertymanageruae.api.payloads.location.LocationDTO;
import com.propertymanageruae.api.payloads.master.ViewApartmentDto;
import com.propertymanageruae.api.payloads.master.ViewAreaDto;
import com.propertymanageruae.api.payloads.master.ViewCommentsDto;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.user.UserDTO;
import com.propertymanageruae.api.payloads.user.ViewUserDto;
import com.propertymanageruae.api.payloads.utils.FileDTO;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ViewComplaintDto {
    private long id;
    private LocationDTO location;
    private String priority;
    private CategoryDTO category;
    private SubCategoryDTO subCategory;
    private ViewUserDto assignedUser;// Assigned user (resolver of the complaint)
    private ViewUserDto complainer;// Complainer (who created the complaint)
    private String complaintVisibility;
    private String complaintDescription;
    private List<FileDTO> complaintImages;
    private String ticketStatus;
    private Timestamp createdAt;//
    private LocalDateTime lastUpdated;
    private LocalDateTime resolvedTime;
    private LocalDateTime closedTime;
    private LocalDateTime preferredTime;
    private long societyId;
    private long apartmentId;
    private long areaId;
    private ViewSocietyDto society;
    private ViewAreaDto area;
    private ViewApartmentDto apartment;
    private List<ViewCommentsDto> comments;
    private String ticketId;
}
