package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.sql.Timestamp;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "error_log")
public class ErrorLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // public error code shown to client
    @Column(name = "error_code", nullable = false, unique = true, length = 36)
    private String errorCode;

    @Column(name = "message", length = 1000)
    private String message;

    @Lob
    @Column(name = "stack_trace", columnDefinition = "TEXT")
    private String stackTrace;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Timestamp createdAt;

    public static ErrorLog of(String message, String stackTrace) {
        ErrorLog e = new ErrorLog();
        e.setErrorCode(UUID.randomUUID().toString());
        e.setMessage(message);
        e.setStackTrace(stackTrace);
        return e;
    }
}