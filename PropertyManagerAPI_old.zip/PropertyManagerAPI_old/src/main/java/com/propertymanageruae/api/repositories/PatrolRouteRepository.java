package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.PatrolRoute;
import com.propertymanageruae.api.entities.Society;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PatrolRouteRepository extends JpaRepository<PatrolRoute, Long> {
    List<PatrolRoute> findBySocietyAndIsActiveTrue(Society society);
    List<PatrolRoute> findBySociety(Society society);
}
