package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.Apartment;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.entities.VisitorDraft;
import com.propertymanageruae.api.payloads.visitor.VisitorDraftDto;
import com.propertymanageruae.api.repositories.ApartmentRepository;
import com.propertymanageruae.api.repositories.UserRepository;
import com.propertymanageruae.api.repositories.VisitorDraftRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VisitorDraftService {

    @Autowired
    private VisitorDraftRepository visitorDraftRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ApartmentRepository apartmentRepository;

    @Autowired
    private ModelMapper modelMapper;

    public VisitorDraftDto saveDraft(VisitorDraftDto draftDto) {
        VisitorDraft draft = modelMapper.map(draftDto, VisitorDraft.class);
        
        User guard = userRepository.findById(draftDto.getGuardId())
                .orElseThrow(() -> new RuntimeException("Guard not found"));
        draft.setGuard(guard);

        if (draftDto.getApartmentId() != null) {
            Apartment apartment = apartmentRepository.findById(draftDto.getApartmentId())
                    .orElseThrow(() -> new RuntimeException("Apartment not found"));
            draft.setApartment(apartment);
        }

        VisitorDraft savedDraft = visitorDraftRepository.save(draft);
        return modelMapper.map(savedDraft, VisitorDraftDto.class);
    }

    public List<VisitorDraftDto> getDraftsByGuard(Long guardId) {
        User guard = userRepository.findById(guardId)
                .orElseThrow(() -> new RuntimeException("Guard not found"));
        List<VisitorDraft> drafts = visitorDraftRepository.findByGuard(guard);
        return drafts.stream()
                .map(d -> modelMapper.map(d, VisitorDraftDto.class))
                .collect(Collectors.toList());
    }

    public void deleteDraft(Long draftId) {
        visitorDraftRepository.deleteById(draftId);
    }

    @Scheduled(cron = "0 0 * * * *") // Every hour
    @Transactional
    public void cleanExpiredDrafts() {
        visitorDraftRepository.deleteByExpiresAtBefore(LocalDateTime.now());
    }
}
