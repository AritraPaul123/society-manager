package com.propertymanageruae.api.payloads.master;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResidentDto {
    private long id;
    private String bhk;
    private String sqFeetArea;
    private String ownerName;
    private String ownerPhone;
    private String ownerSecondaryPhone;
    private String ownerEmail;
    private String tenantName;
    private String tenantPhone;
    private String tenantSecondaryPhone;
    private String tenantEmail;
    private String residentType;
    private Boolean parking;
    private String accommodationType;
    private String primaryOwnerPhone;
    private String primaryTenantPhone;
    private String meterId;
    private String consumerId;
    private String sanctionedLoadKW;
    private String sanctionedDGLoadKV;
    private Integer numberPipedGasUsers;
    private LocalDateTime possessionDate;

    private Long apartmentId;
    private Long areaId;
    private Long societyId;

    private String password;
    private String roles;
    private boolean status;
    private Long userId;

    private boolean isDelete;
    private long createdBy;
    private long modifyBy;
    private long deleteBy;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime deletedAt;
}