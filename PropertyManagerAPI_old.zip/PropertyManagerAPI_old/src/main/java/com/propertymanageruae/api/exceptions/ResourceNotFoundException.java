package com.propertymanageruae.api.exceptions;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String resourceName, String fieldName, String fieldValue) {
        super(String.format("%s Not Found", resourceName));
    }
    public ResourceNotFoundException(String msg) {
        super(msg);
    }
}