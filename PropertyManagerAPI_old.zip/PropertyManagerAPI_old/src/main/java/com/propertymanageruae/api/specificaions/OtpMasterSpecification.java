package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.entities.OtpMaster;
import org.springframework.data.jpa.domain.Specification;

public class OtpMasterSpecification {

    public static Specification<OtpMaster> isValidOtp(String otp, String otpIdentifier) {
        return (root, query, criteriaBuilder) -> criteriaBuilder.and(
                criteriaBuilder.equal(root.get("otp"), otp),
                criteriaBuilder.equal(root.get("otpIdentifier"), otpIdentifier),
                criteriaBuilder.isTrue(root.get("status"))
        );
    }
}