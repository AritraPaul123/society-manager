package com.propertymanageruae.api.entities;


import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDevice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "fcm_token", length = 500)
    private String fcmToken;
    @Column(name = "device_id")
    private String deviceId;
    @Column(name = "device_type")
    private String deviceType;
    @Column(name = "active")
    private boolean active = true;
    @Column(name = "device_name")
    private String deviceName;
    @Column(name = "os_version")
    private String osVersion;
    @Column(name = "is_deleted")
    private boolean isDeleted = false;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    @Column(name = "expired_at")
    private LocalDateTime expiredAt;

    @PreRemove
    protected void onDelete() {
        this.isDeleted = true;
        this.expiredAt = ZonedDateTime.now(ZoneId.of("UTC")).toLocalDateTime();
    }
    // Getters and Setters
}