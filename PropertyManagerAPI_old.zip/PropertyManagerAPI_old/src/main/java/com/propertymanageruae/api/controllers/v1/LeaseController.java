package com.propertymanageruae.api.controllers.v1;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.services.lease.LeaseService;
import com.propertymanageruae.api.services.lease.PaymentService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/leases")
@RequiredArgsConstructor
public class LeaseController {

    private final LeaseService leaseService;
    private final PaymentService paymentService;

    /* ------------------------- CRUD ------------------------- */

    @GetMapping
    public ResponseEntity<List<Lease>> getAllLeases() {
        return ResponseEntity.ok(leaseService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Lease> getLeaseById(@PathVariable Long id) {
        return ResponseEntity.ok(leaseService.getById(id));
    }

    @PostMapping
    public ResponseEntity<Lease> createLease(@RequestBody Lease lease) {
        return ResponseEntity.ok(leaseService.create(lease));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Lease> updateLease(@PathVariable Long id, @RequestBody Lease lease) {
        return ResponseEntity.ok(leaseService.update(id, lease));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLease(@PathVariable Long id) {
        leaseService.delete(id);
        return ResponseEntity.noContent().build();
    }

    /* ---------------- Building → Units → Leases ---------------- */

    @GetMapping("/buildings")
    public ResponseEntity<List<String>> getBuildings() {
        return ResponseEntity.ok(leaseService.getBuildingNames());
    }

    @GetMapping("/units/{buildingName}")
    public ResponseEntity<List<String>> getUnitsByBuilding(@PathVariable String buildingName) {
        return ResponseEntity.ok(leaseService.getUnitNamesByBuilding(buildingName));
    }

    @GetMapping("/{buildingName}/{unitName}")
    public ResponseEntity<List<Lease>> getLeasesByBuildingAndUnit(
            @PathVariable String buildingName,
            @PathVariable String unitName) {
        return ResponseEntity.ok(leaseService.getLeasesByBuildingAndUnit(buildingName, unitName));
    }

    /* ---------------- Update Payment Installment ---------------- */
    @PatchMapping("/{leaseId}/payments/{paymentId}/installments/{installmentId}")
    public ResponseEntity<PaymentInstallment> updateInstallmentStatus(
            @PathVariable Long leaseId,
            @PathVariable Long paymentId,
            @PathVariable Long installmentId,
            @RequestBody Map<String, Object> updates) {

        PaymentInstallment updatedInstallment = leaseService.updateInstallmentStatusWithPaymentDetails(
                leaseId, paymentId, installmentId, updates);

        return ResponseEntity.ok(updatedInstallment);
    }

    /**
     * Manual payment - create a transaction. 
     * Body: PaymentTransaction JSON. Optional: attach installment via { "installment": { "installmentId": 123 } }
     * This supports the "both" behaviour: txn saved AND fields mirrored into the installment (if provided).
     */
    @PostMapping("/{leaseId}/payments")
    public ResponseEntity<Payment> createManualPayment(
            @PathVariable Long leaseId,
            @RequestBody PaymentTransaction txn) {

        Payment updatedPayment = paymentService.manualPayment(leaseId, txn);
        return ResponseEntity.ok(updatedPayment);
    }

    /**
     * Delete a transaction (manual or installment transaction). Validates lease/payment relation before deletion.
     */
    @DeleteMapping("/{leaseId}/payments/{paymentId}/transactions/{transactionId}")
    public ResponseEntity<Void> deleteTransaction(
            @PathVariable Long leaseId,
            @PathVariable Long paymentId,
            @PathVariable Long transactionId) {

        paymentService.deleteManualTransaction(leaseId, paymentId, transactionId);
        return ResponseEntity.noContent().build();
    }



    @PatchMapping("/{leaseId}/payments/{paymentId}/transactions/{transactionId}")
public ResponseEntity<PaymentTransaction> updateManualTransaction(
        @PathVariable Long leaseId,
        @PathVariable Long paymentId,
        @PathVariable Long transactionId,
        @RequestBody PaymentTransaction txnUpdate) {

    PaymentTransaction updatedTxn = paymentService.updateManualTransaction(leaseId, paymentId, transactionId, txnUpdate);
    return ResponseEntity.ok(updatedTxn);
}

@PutMapping("{leaseId}/owners")
public ResponseEntity<Lease> updateOwnersForLease(
        @PathVariable Long leaseId,
        @RequestBody List<Owner> owners) {
    Lease updatedLease = leaseService.updateOwnersForLease(leaseId, owners);
    return ResponseEntity.ok(updatedLease);
}

@PutMapping("/{leaseId}/payments/{paymentId}/recalculate")
public Payment recalculatePayment(
        @PathVariable Long leaseId,
        @PathVariable Long paymentId,
        @RequestBody Payment updatedPayment) {

    return paymentService.updatePaymentWithRecalculation(
            leaseId,
            paymentId,
            updatedPayment
    );
}


}



