package com.propertymanageruae.api.services.logger;

public interface ILoggerService {
    void logDebug(String message);
    void logInfo(String message);
    void logWarn(String message);
    void logError(String message);
}