package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Area;
import com.propertymanageruae.api.entities.NoticeFiles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface INoticeFilesRepository extends JpaRepository<NoticeFiles,Long>, JpaSpecificationExecutor<NoticeFiles> {
}