package com.propertymanageruae.api.Filter;

import com.propertymanageruae.api.config.TimeZoneContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class TimeZoneInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String timeZone = request.getHeader("X-Timezone");
        if (timeZone == null || timeZone.isBlank()) {
            timeZone = "UTC"; // default fallback
        }
        TimeZoneContext.setTimeZone(timeZone);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        TimeZoneContext.clear();
    }
}