package com.propertymanageruae.api.config._Mapper;

import com.propertymanageruae.api.entities.Notice;
import com.propertymanageruae.api.helper.AppHelper;
import com.propertymanageruae.api.payloads.notice.ViewNoticeGroupDto;
import jakarta.annotation.PostConstruct;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.stereotype.Component;

@Component
public class NoticeboardMappingProfile {
    private final ModelMapper modelMapper;
    public NoticeboardMappingProfile(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }
    @PostConstruct
    public void configureResidentMapping() {
        TypeMap<Notice, ViewNoticeGroupDto> noticeMap = modelMapper.createTypeMap(Notice.class, ViewNoticeGroupDto.class);
        noticeMap.addMappings(mapper -> {
            mapper.map(src -> {
                byte[] compressedHtml = src.getDescription();
                return compressedHtml != null ? AppHelper.decompressHtml(compressedHtml) : ""; // Ensure correct conversion
            }, ViewNoticeGroupDto::setDescription);
        });
    }


}