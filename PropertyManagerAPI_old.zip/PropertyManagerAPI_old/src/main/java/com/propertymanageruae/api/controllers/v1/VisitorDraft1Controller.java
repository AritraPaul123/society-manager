package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.visitor.VisitorDraftDto;
import com.propertymanageruae.api.services.VisitorDraftService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/visitor-drafts")
public class VisitorDraft1Controller {

    @Autowired
    private VisitorDraftService visitorDraftService;

    @PostMapping("/")
    public ResponseEntity<VisitorDraftDto> saveDraft(@RequestBody VisitorDraftDto draftDto) {
        return new ResponseEntity<>(visitorDraftService.saveDraft(draftDto), HttpStatus.CREATED);
    }

    @GetMapping("/guard/{guardId}")
    public ResponseEntity<List<VisitorDraftDto>> getDraftsByGuard(@PathVariable Long guardId) {
        return ResponseEntity.ok(visitorDraftService.getDraftsByGuard(guardId));
    }

    @DeleteMapping("/{draftId}")
    public ResponseEntity<Void> deleteDraft(@PathVariable Long draftId) {
        visitorDraftService.deleteDraft(draftId);
        return ResponseEntity.noContent().build();
    }
}
