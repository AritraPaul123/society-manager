package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Area;
import com.propertymanageruae.api.entities.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface INoticeRepository extends JpaRepository<Notice,Long> , JpaSpecificationExecutor<Notice> {
    List<Notice> findByNoticeId(String noticeId);
    List<Notice> findByNoticeIdAndIsDeletedFalseAndExpiredFalse(String noticeId);

}