package com.propertymanageruae.api.controllers.v1;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.UnitHelper;
import com.propertymanageruae.api.payloads.complaint.AddComplaintDTO;
import com.propertymanageruae.api.payloads.complaint.ComplaintFilterDto;
import com.propertymanageruae.api.payloads.complaint.ComplaintStatusUpdateDto;
import com.propertymanageruae.api.payloads.complaint.ViewComplaintDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.List;


@RestController
@RequestMapping("/api/v${api.version}/complaints")
@SecurityRequirement(name = "auth")
@Tag(name = "Complaint")
public class Complaint1Controller {

    @Value("${api.version}")
    private String apiVersion;

    @Autowired
    private UnitService _uniService;
    @Autowired
    private UnitHelper _unitHelper;

    @GetMapping(value = "/pdf/generate-thumbnail/{pdfName}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> geneRateThumbnail(@PathVariable("pdfName") String pdfName) throws IOException {
        try (InputStream resource = this._unitHelper.s3FileHandler.getResource(pdfName)) {
            byte[] pdfBytes = resource.readAllBytes();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(ContentDisposition.inline().filename(pdfName).build());
            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        }
    }


    @GetMapping(value = "/image/{imageName}", produces = MediaType.IMAGE_JPEG_VALUE)
    public void downloadImage(@PathVariable("imageName") String imageName, HttpServletResponse httpServletResponse) throws IOException {
        InputStream resource = this._unitHelper.s3FileHandler.getResource(imageName);
        httpServletResponse.setContentType(MediaType.IMAGE_JPEG_VALUE);
        StreamUtils.copy(resource, httpServletResponse.getOutputStream());
    }
    @GetMapping(value = "/pdf/{pdfName}", produces = MediaType.APPLICATION_PDF_VALUE)
    public void downloadPdf(@PathVariable("pdfName") String pdfName, HttpServletResponse response) throws IOException {
        InputStream resource = this._unitHelper.s3FileHandler.getResource(pdfName);
        response.setContentType(MediaType.APPLICATION_PDF_VALUE);
        response.setHeader("Content-Disposition", "inline; filename=\"" + pdfName + "\"");
        StreamUtils.copy(resource, response.getOutputStream());
        response.flushBuffer();
    }



    @Operation(summary = "Get all complaints")
    @GetMapping("/all-complaint/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewComplaintDto>>> getAllComplaints(
            @RequestParam(defaultValue = "ALL") String status,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String priority,
            @RequestParam(required = false) String complaintVisibility,
            @RequestParam(required = false) Long assigneeId,
            @RequestParam(required = false) Long locationId,
            @RequestParam(required = false) Long apartmentId,
            @RequestParam(required = false) Long blockId,
            @RequestParam(required = false) Long ticketNo,
            @RequestParam(required = false) Integer days,  // New parameter for last X days
            @RequestParam(required = false) LocalDate startDate, // New parameter for custom start date
            @RequestParam(required = false) LocalDate endDate,
            @RequestParam(value = "searchText",required = false) String searchText,
            @RequestParam(defaultValue = "0") int offset,  // Offset to skip records
            @RequestParam(defaultValue = "10") int limit,
            @RequestParam(defaultValue = "createdAt") String sortBy,   // Default sort by "createdAt"
            @RequestParam(defaultValue = "ASC") String sortDir,        // Default sort direction "ASC"
            @PathVariable("societyId") long societyId
    ) {
        // Validation: If endDate is provided, startDate must be required
        if (endDate != null && startDate == null) {
            throw new IllegalArgumentException("Start date must be provided when end date is specified.");
        }

        // Validation: Start date should not be greater than end date
        if (startDate != null && endDate != null && startDate.isAfter(endDate)) {
            throw new IllegalArgumentException("Start date cannot be greater than end date.");
        }
        ComplaintFilterDto filter = new ComplaintFilterDto();
        filter.setStatus(status.equals("ALL") ? null : status);
        filter.setCategoryId(categoryId);
        filter.setPriority(priority);
        filter.setComplaintVisibility(complaintVisibility);
        filter.setAssigneeId(assigneeId);
        filter.setLocationId(locationId);
        filter.setApartmentId(apartmentId);
        filter.setAreaId(blockId);
        filter.setTicketNo(ticketNo);
        filter.setDays(days);               // Set days for last X days filter
        filter.setStartDate(startDate);     // Set custom start date
        filter.setEndDate(endDate);
        filter.setSearchText(searchText);
        List<ViewComplaintDto> complaints = this._uniService.complaintService.getAllComplaints(filter, offset, limit,sortBy,sortDir,societyId);
        return ResponseEntity
                .ok(ApiResponse.success(complaints, "Fetched all complaints successfully", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Update Complaint Status")
    @PatchMapping("/{complaintId}/status")
    public ResponseEntity<ApiResponse<ViewComplaintDto>> updateComplaintStatus(
            @PathVariable Long complaintId,
            @Valid @RequestBody ComplaintStatusUpdateDto statusUpdateDTO) throws FirebaseMessagingException {
        ViewComplaintDto complaintDto = this._uniService.complaintService.updateComplaintStatus(complaintId, statusUpdateDTO);


        if (complaintDto!=null) {
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(ApiResponse.success(complaintDto, "Complaint status updated successfully", null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.success(null, "Complaint status Not Updated", null, HttpStatus.BAD_REQUEST.value()));
        }
    }


    @Operation(summary = "Delete a complaint")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> deleteComplaint(
            @PathVariable("id") long id) {
        try {
            this._uniService.complaintService.deleteComplaint(id);
            return ResponseEntity
                    .status(HttpStatus.OK)
                    .body(ApiResponse.success(null, "Complaint deleted successfully", null, HttpStatus.NO_CONTENT.value()));
        } catch (ResourceNotFoundException ex) {
            // Handle specific exception for resource not found
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(null, ex.getMessage(), null, HttpStatus.NOT_FOUND.value()));
        } catch (Exception ex) {
            // Handle any other unexpected exceptions
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error(null, "An unexpected error occurred", null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @Operation(summary = "Get a complaint by ID")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ViewComplaintDto>> getComplaintById(@PathVariable("id") Long id) {
        ViewComplaintDto complaintDTO = this._uniService.complaintService.getComplaintById(id);
        return ResponseEntity
                .ok(ApiResponse.success(complaintDTO, "Complaint retrieved successfully", null, HttpStatus.OK.value()));
    }


    @Operation(summary = "Create a new complaint")
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<ViewComplaintDto>> addComplaint(
            @Valid @RequestPart("complaint") AddComplaintDTO complaintDTO,
            @RequestPart(value = "files", required = false) List<MultipartFile> files) throws IOException {
        ViewComplaintDto complaintDto1 = this._uniService.complaintService.addComplaint(complaintDTO, files);
        if (complaintDto1!=null) {
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(ApiResponse.success(complaintDto1, "Complaint created successfully", null, HttpStatus.CREATED.value()));
        } else {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.success(null, "Complaint Not Added", null, HttpStatus.BAD_REQUEST.value()));
        }
    }

    @Operation(summary = "Get all complaints by societyId and apartmentId")
    @GetMapping("/all-complaint/{societyId}/{apartmentId}")
    public ResponseEntity<ApiResponse<List<ViewComplaintDto>>> getAllComplaintsBySocietyAndApartment(
            @RequestParam(defaultValue = "ALL") String status,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String priority,
            @RequestParam(required = false) String complaintVisibility,
            @RequestParam(required = false) Long assigneeId,
            @RequestParam(required = false) Long locationId,
            @RequestParam(required = false) Long ticketNo,
            @RequestParam(required = false) Integer days,  // New parameter for last X days
            @RequestParam(required = false) LocalDate startDate, // New parameter for custom start date
            @RequestParam(required = false) LocalDate endDate,
            @RequestParam(value = "searchText",required = false) String searchText,
            @RequestParam(defaultValue = "0") int offset,  // Offset to skip records
            @RequestParam(defaultValue = "10") int limit,
            @RequestParam(defaultValue = "createdAt") String sortBy,   // Default sort by "createdAt"
            @RequestParam(defaultValue = "ASC") String sortDir,        // Default sort direction "ASC"
            @PathVariable("societyId") long societyId,
            @PathVariable("apartmentId") long apartmentId
    ) {
        // Validation: If endDate is provided, startDate must be required
        if (endDate != null && startDate == null) {
            throw new IllegalArgumentException("Start date must be provided when end date is specified.");
        }

        // Validation: Start date should not be greater than end date
        if (startDate != null && endDate != null && startDate.isAfter(endDate)) {
            throw new IllegalArgumentException("Start date cannot be greater than end date.");
        }
        ComplaintFilterDto filter = new ComplaintFilterDto();
        filter.setStatus(status.equals("ALL") ? null : status);
        filter.setCategoryId(categoryId);
        filter.setPriority(priority);
        filter.setComplaintVisibility(complaintVisibility);
        filter.setAssigneeId(assigneeId);
        filter.setLocationId(locationId);
        filter.setTicketNo(ticketNo);
        filter.setDays(days);               // Set days for last X days filter
        filter.setStartDate(startDate);     // Set custom start date
        filter.setEndDate(endDate);
        filter.setSearchText(searchText);
        List<ViewComplaintDto> complaints = this._uniService.complaintService.getAllComplaintsBySocietyAndApartment(filter, offset, limit,sortBy,sortDir,societyId,apartmentId);
        return ResponseEntity
                .ok(ApiResponse.success(complaints, "Fetched all complaints successfully", null, HttpStatus.OK.value()));
    }



}