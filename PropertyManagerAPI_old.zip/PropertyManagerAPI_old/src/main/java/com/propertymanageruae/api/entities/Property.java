package com.propertymanageruae.api.entities;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "property")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Property {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private PropertyType propertyType; // simple enum field, no functionality

    private String address;
    private String plotNo;
    private String dewaNo;
    private Double unitArea;
    private Double makaniNo;

    private String buildingName; // now belongs directly to property
    private String unitName;     // directly under property (no subclass needed)
    private Integer noOfBedrooms;

    @ManyToMany(mappedBy = "properties", fetch = FetchType.LAZY)
    @JsonIgnoreProperties("properties")
    private Set<Owner> owners = new HashSet<>();

    @OneToMany(mappedBy = "property", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Lease> leases = new HashSet<>();

    public enum PropertyType {
    APARTMENT,
    COMMERCIAL,
    RESIDENTIAL,
    VILLA,
    OTHER
    }
}




