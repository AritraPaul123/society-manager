package com.propertymanageruae.api.payloads.member;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MemberRevokeDto {
    private boolean isRevoked;
    private long societyId;
}