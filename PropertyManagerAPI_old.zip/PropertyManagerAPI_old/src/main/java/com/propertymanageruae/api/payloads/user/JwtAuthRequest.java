package com.propertymanageruae.api.payloads.user;


import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JwtAuthRequest {
    @NotEmpty(message = "Email must not be empty")
    @Email
    private String username;
    private String password;
    private String platform;

    public JwtAuthRequest(String username, String password) {
        this.username = username;
    }
}