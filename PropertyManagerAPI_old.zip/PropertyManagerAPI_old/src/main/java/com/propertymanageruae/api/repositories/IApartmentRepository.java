package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Apartment;
import com.propertymanageruae.api.entities.Area;
import com.propertymanageruae.api.entities.Resident;
import com.propertymanageruae.api.entities.Society;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IApartmentRepository extends JpaRepository<Apartment, Long> , JpaSpecificationExecutor<Apartment> {
    Optional<Apartment> findByAreaAndFlat(Area area, String flat);
    List<Apartment> findByAreaAndSociety(Area area, Society society);
    List<Apartment> findBySociety(Society society);
    boolean existsByBlockAndFloorAndFlatAndAreaAndSociety(
            String block,
            String floor,
            String flat,
            Area area,
            Society society
    );
    @Query("SELECT a FROM Apartment a JOIN a.society s WHERE s.id = :societyId")
    List<Apartment> findApartmentBySocietyId(@Param("societyId") Long societyId);

    @Query("SELECT a FROM Apartment a JOIN a.society s WHERE s.id = :societyId")
    Page<Apartment> findApartmentBySocietyId(@Param("societyId") Long societyId, Pageable pageable);
    @Query("SELECT a FROM Apartment a RIGHT JOIN a.resident r WHERE " +
            "LOWER(r.ownerName) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
            "LOWER(r.tenantName) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
            "LOWER(a.flat) LIKE LOWER(CONCAT('%', :searchText, '%'))")
    Page<Apartment> findBySearchText(@Param("searchText") String searchText, Pageable pageable);




}