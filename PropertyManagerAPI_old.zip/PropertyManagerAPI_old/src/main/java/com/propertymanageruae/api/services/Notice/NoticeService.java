package com.propertymanageruae.api.services.Notice;


import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.config.TimeZoneContext;
import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.AppHelper;
import com.propertymanageruae.api.helper.S3FileHandler;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.master.ViewApartmentDto;
import com.propertymanageruae.api.payloads.master.ViewAreaDto;
import com.propertymanageruae.api.payloads.notice.AddNoticeDto;
import com.propertymanageruae.api.payloads.notice.ViewNoticeDto;
import com.propertymanageruae.api.payloads.notice.ViewNoticeFileDto;
import com.propertymanageruae.api.payloads.notice.ViewNoticeGroupDto;
import com.propertymanageruae.api.repositories.*;
import com.propertymanageruae.api.services.ExternalService.IGmailOAuthService;
import com.propertymanageruae.api.services.ExternalService.IMailService;
import com.propertymanageruae.api.services.logger.ILoggerService;
import com.propertymanageruae.api.services.user.ICustomUserDetailService;
import com.propertymanageruae.api.specificaions.NoticeSpecification;
import com.propertymanageruae.api.specificaions.ResidentSpecification;
import jakarta.transaction.Transactional;
import org.hibernate.service.spi.ServiceException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLIntegrityConstraintViolationException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class NoticeService implements INoticeService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    private INoticeReadTrackingRepository noticeReadTrackingRepository;
    @Autowired
    private INoticeRepository noticeRepository;
    @Autowired
    private IResidentRepository residentRepository;
    @Autowired
    private ICustomUserDetailService customUserDetailService;
    @Autowired
    private ISocietyRepository societyRepository;
    @Autowired
    private IApartmentRepository apartmentRepository;
    @Autowired
    private IAreaRepository areaRepository;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private ILoggerService loggerService;
    @Autowired
    private S3FileHandler s3FileHandler;
    @Autowired
    private IMailService mailService;
    @Autowired
    private IGmailOAuthService gmailOAuthService;

    private static PaginationDto<ViewNoticeGroupDto> getViewNoticeGroupDtoPaginationDto(int pageNumber, int pageSize, Map<String, ViewNoticeGroupDto> noticeGroupMap) {
        List<ViewNoticeGroupDto> groupedNotices = new ArrayList<>(noticeGroupMap.values());
        int totalElements = groupedNotices.size();
        int totalPages = (int) Math.ceil((double) totalElements / pageSize);
        int fromIndex = pageNumber * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, totalElements);
        List<ViewNoticeGroupDto> paginatedList = (fromIndex < totalElements) ? groupedNotices.subList(fromIndex, toIndex) : Collections.emptyList();
        PaginationDto<ViewNoticeGroupDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(paginatedList);
        paginationDto.setPageNumber(pageNumber);
        paginationDto.setPageSize(pageSize);
        paginationDto.setTotalPages(totalPages);
        paginationDto.setTotalElements(totalElements);
        paginationDto.setLastPage(pageNumber == totalPages - 1);
        return paginationDto;
    }

    @Override
    public void markNoticeAsRead(long noticeId, long residentId) {
        Notice notice = noticeRepository.findById(noticeId)
                .orElseThrow(() -> new ResourceNotFoundException("Notice not found"));
        Resident resident = residentRepository.findById(residentId)
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found"));
        Optional<NoticeReadTracking> existingTracking =
                noticeReadTrackingRepository.findByNoticeIdAndResidentId(noticeId, residentId);
        if (existingTracking.isPresent()) {
            NoticeReadTracking tracking = existingTracking.get();
            tracking.setRead(true);
            tracking.setReadAt(LocalDateTime.now());
            noticeReadTrackingRepository.save(tracking);
        } else {
            NoticeReadTracking newTracking = NoticeReadTracking.builder()
                    .notice(notice)
                    .resident(resident)
                    .isRead(true)
                    .readAt(LocalDateTime.now())
                    .build();
            noticeReadTrackingRepository.save(newTracking);
        }
    }

    @Override
    public long getReadCountByNoticeId(long noticeId) {
        return noticeReadTrackingRepository.countReadByNoticeId(noticeId);
    }

    @Override
    public PaginationDto<ViewNoticeDto> getNotices(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, String noticeTimeline, long societyId) {
        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }
        Sort.Direction direction = Sort.Direction.fromString(sortDir);
        PageRequest pageable = PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));
        Page<Notice> pageNoticeList;
        User loggedInUser = customUserDetailService.LoggedInUser();
        long loggedInId = loggedInUser.getId();
        Specification<Notice> spec = Specification
                .where(NoticeSpecification.hasSocietyId(societyId))
                .and(NoticeSpecification.isNotDeleted(false))
                .and(NoticeSpecification.filterByTimeline(noticeTimeline));
        if (searchText != null && !searchText.trim().isEmpty()) {
            spec = spec.and(NoticeSpecification.searchByText(searchText));
        }
        pageNoticeList = this.noticeRepository.findAll(spec, pageable);
        List<ViewNoticeDto> viewNoticeDtoList = pageNoticeList.getContent()
                .stream()
                .map(notice -> modelMapper.map(notice, ViewNoticeDto.class))
                .collect(Collectors.toList());
        PaginationDto<ViewNoticeDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(viewNoticeDtoList);
        paginationDto.setPageNumber(pageNoticeList.getNumber());
        paginationDto.setPageSize(pageNoticeList.getSize());
        paginationDto.setTotalPages(pageNoticeList.getTotalPages());
        paginationDto.setTotalElements(pageNoticeList.getTotalElements());
        paginationDto.setLastPage(pageNoticeList.isLast());
        return paginationDto;
    }

    @Override
    public PaginationDto<ViewNoticeGroupDto> getNoticesGroup(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, String noticeTimeline, long societyId,String userTimezone) {
        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }
        Specification<Notice> spec = Specification
                .where(NoticeSpecification.hasSocietyId(societyId))
                .and(NoticeSpecification.isNotDeleted(false))
                .and(NoticeSpecification.filterByTimelineZoneWise(noticeTimeline));
        if (searchText != null && !searchText.trim().isEmpty()) {
            spec = spec.and(NoticeSpecification.searchByText(searchText));
        }
        Sort sort = Sort.by(Sort.Direction.fromString(sortDir), sortBy);
        List<Notice> allNotices = noticeRepository.findAll(spec, sort);

        Map<String, ViewNoticeGroupDto> noticeGroupMap = new HashMap<>();
        for (Notice notice : allNotices) {
            noticeGroupMap.computeIfAbsent(notice.getNoticeId(), id -> {
                ViewNoticeGroupDto dto = modelMapper.map(notice, ViewNoticeGroupDto.class);
                dto.setDescription(AppHelper.decompressHtml(notice.getDescription()));
                dto.setAreas(new HashSet<>());
                dto.setApartments(new HashSet<>());
                dto.setNoticeFiles(new HashSet<>());
                return dto;
            });
            ViewNoticeGroupDto dto = noticeGroupMap.get(notice.getNoticeId());
            dto.getAreas().add(modelMapper.map(notice.getArea(), ViewAreaDto.class));
            dto.getApartments().add(modelMapper.map(notice.getApartment(), ViewApartmentDto.class));
            if (notice.getNoticeFile() != null) {
                for (NoticeFiles file : notice.getNoticeFile()) {
                    dto.getNoticeFiles().add(modelMapper.map(file, ViewNoticeFileDto.class));
                }
            }
            // Timezone conversion if not using ModelMapper converter
            dto.setPostedAt(AppHelper.convertToUserZone(notice.getPostedAt(), userTimezone));
            dto.setUpdatedAt(AppHelper.convertToUserZone(notice.getUpdatedAt(), userTimezone));
            dto.setExpiredAt(AppHelper.convertToUserZone(notice.getExpiredAt(), userTimezone));
        }
        return getViewNoticeGroupDtoPaginationDto(pageNumber, pageSize, noticeGroupMap);
    }

    @Override
    @Transactional
    public void doExpiredNotice(long id) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            Notice notice = this.noticeRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Notice not found for expired"));
            List<Notice> notices = this.noticeRepository.findByNoticeId(notice.getNoticeId());
            String userZone = Optional.ofNullable(TimeZoneContext.getTimeZone()).orElse("UTC");
            for (Notice nt : notices) {
                // User's current time in their zone
                ZonedDateTime userNow = ZonedDateTime.now(ZoneId.of(userZone));
                // Convert to UTC and subtract 1 day
                Instant utcInstant = userNow.withZoneSameInstant(ZoneId.of("UTC"))
                        .minusDays(1)
                        .toInstant();
                nt.setExpiredAt(utcInstant);
                nt.setExpired(true);
                this.noticeRepository.save(nt);
            }
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while soft deleting user: " + e.getMessage());
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Transactional
    @Override
    public String postNotice(AddNoticeDto noticeDto, List<MultipartFile> files) throws IOException {
        try {
            long loggedInUserId = customUserDetailService.LoggedInUser().getId();
            User postedBy = userRepository.findById(loggedInUserId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found"));
            Society society = societyRepository.findById(noticeDto.getSocietyId())
                    .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
            Map<Long, Apartment> apartmentMap = apartmentRepository.findAllById(noticeDto.getApartments())
                    .stream().collect(Collectors.toMap(Apartment::getId, a -> a));
            Map<Long, Area> areaMap = areaRepository.findAllById(noticeDto.getBlocks())
                    .stream().collect(Collectors.toMap(Area::getId, a -> a));
            List<Notice> notices = new ArrayList<>();
            String noticeId = AppHelper.generateUniqueId();
            for (Long apartmentId : noticeDto.getApartments()) {
                Apartment apartment = apartmentMap.get(apartmentId);
                if (apartment == null) {
                    throw new ResourceNotFoundException("Apartment not found: " + apartmentId);
                }
                for (Long areaId : noticeDto.getBlocks()) {
                    Area area = areaMap.get(areaId);
                    if (area == null) {
                        throw new ResourceNotFoundException("Area not found: " + areaId);
                    }
                    Notice notice = new Notice();
                    notice.setPostedBy(postedBy);
                    notice.setCreatedBy(loggedInUserId);
                    notice.setSociety(society);
                    notice.setDescription(AppHelper.compressHtml(noticeDto.getDescription()));
                    notice.setNotificationType(noticeDto.getNotificationType());
                    notice.setEmailNotification(noticeDto.isEmailNotification());
                    notice.setTitle(String.format("Notice: %s", noticeDto.getSubject()));
                    notice.setNotifyTo(noticeDto.getNotify());
                    notice.setTargetAudience(noticeDto.getRecipients());
                    notice.setScheduleNotification(noticeDto.isScheduleNotification());
                    notice.setNoticeId(noticeId);
                    if (noticeDto.getExpiredAt() != null) {
                        notice.setExpiredAt(noticeDto.getExpiredAt().atZone(ZoneId.of("UTC")).toInstant()); // Convert back to LocalDateTime
                    }
                    notice.setPostedAt(
                            noticeDto.isScheduleNotification()
                                    ? noticeDto.getPostedAt().atZone(ZoneId.of("UTC")).toInstant()
                                    : Instant.now()
                    );

                    notice.setApartment(apartment);
                    notice.setArea(area);
                    notices.add(notice);
                }
            }
            noticeRepository.saveAll(notices);
            if (!files.isEmpty()) {
                if (!notices.isEmpty()) {
                    List<NoticeFiles> noticeFiles = fileUpload(files, notices.get(0), noticeId); // Use first Notice
                    notices.get(0).setNoticeFile(new ArrayList<>(noticeFiles));
                }
            }
            noticeRepository.saveAll(notices);
            loggerService.logInfo("Successfully posted " + notices.size() + " notices");
            if (noticeDto.isEmailNotification()) {
//
                List<String> emails = Arrays.asList(
                        "kayzzy04@gmail.com,admonishpaul141@gmail.com,gopal27936@gmail.com,monish.paul2000@gmail.com,monishpaul856@gmail.com,paulmonish35@gmail.com,paulmonish732@gmail.com,paulmonish.mp@gmail.com,cs.saikat.work@gmail.com,rudraneelghoshrg@gmail.com,rudraneelghosh007@gmail.com,saikatchatterjee2000@gmail.com"
                                .split(",")
                );
//                Set<String> emailSet=fetchEmailsForNoticesUsingQuery(notices);
//                List<String> emails=new ArrayList<>(emailSet);
                List<MultipartFile> filteredFiles=files.isEmpty()?null:files;
                this.gmailOAuthService.sendBulkEmail(emails,noticeDto.getSubject(),noticeDto.getDescription(),filteredFiles);
            }
            return "Notices posted successfully";
        } catch (ResourceNotFoundException ex) {
            loggerService.logError("Resource not found: " + ex.getMessage());
            throw ex;
        } catch (DataIntegrityViolationException ex) {
            loggerService.logError("Database related error: " + ex);
            throw new RuntimeException(ex.getMessage());
        } catch (Exception ex) {
            loggerService.logError("Unexpected error while posting notice: " + ex);
            throw new RuntimeException("Failed to post notice", ex);
        }
    }
    private Set<String> fetchEmailsForNoticesUsingQuery(List<Notice> notices) {
        Set<String> emails = new HashSet<>();
        for (Notice notice : notices) {
            String normalizedTargetAudience = notice.getTargetAudience().trim().toUpperCase();
            emails.addAll(getResidentEmailsForNoticeSend(notice.getSociety().getId(),
                    notice.getArea().getId(),
                    notice.getApartment().getId(),
                    normalizedTargetAudience));
        }
        return emails;
    }

    private Set<String> getResidentEmailsForNoticeSendUsingSpecification(long societyId, long areaId, long apartmentId, String targetAudience) {
        Specification<Resident> spec = ResidentSpecification.filterResidentsForNotice(societyId, areaId, apartmentId, targetAudience);
        List<Resident> residents = residentRepository.findAll(spec);
        return residents.stream()
                .flatMap(resident -> {
                    Set<String> emails = new HashSet<>();
                    if (resident.getOwnerEmail() != null && !resident.getOwnerEmail().trim().isEmpty()) {
                        emails.add(resident.getOwnerEmail());
                    }
                    if (resident.getTenantEmail() != null && !resident.getTenantEmail().trim().isEmpty()) {
                        emails.add(resident.getTenantEmail());
                    }
                    return emails.stream();
                })
                .collect(Collectors.toSet()); // Remove duplicates
    }

    public Set<String> getResidentEmailsForNoticeSend(long societyId, long areaId, long apartmentId, String targetAudience) {
        Set<String> emails = new HashSet<>();
        emails.addAll(residentRepository.findOwnerEmailsForNoticeSend(societyId, areaId, apartmentId, targetAudience));
        emails.addAll(residentRepository.findTenantEmailsForNoticeSend(societyId, areaId, apartmentId, targetAudience));
        return new HashSet<>(emails); // Remove duplicates
    }


    private Set<String> fetchEmailsForNotices(List<Notice> notices) {
        Set<String> emails = new HashSet<>();
        for (Notice notice : notices) {
            long societyId = notice.getSociety().getId();
            long areaId = notice.getArea().getId();
            long apartmentId = notice.getApartment().getId();
            String targetAudience = notice.getTargetAudience().toUpperCase();
            List<Resident> residents = fetchResidents(societyId, areaId, apartmentId);
            for (Resident resident : residents) {
                addEmailsBasedOnTargetAudience(emails, resident, targetAudience);
            }
        }
        return emails;
    }

    private List<Resident> fetchResidents(long societyId, long areaId, long apartmentId) {
        if (societyId > 1 && areaId == 1 && apartmentId == 1) {
            return residentRepository.findBySocietyId(societyId);
        } else if (societyId > 1 && areaId > 1 && apartmentId == 1) {
            return residentRepository.findBySocietyIdAndAreaId(societyId, areaId);
        } else if (societyId > 1 && areaId == 1 && apartmentId > 1) {
            return residentRepository.findBySocietyIdAndApartmentId(societyId, apartmentId);
        }
        return Collections.emptyList();
    }

    private void addEmailsBasedOnTargetAudience(Set<String> emails, Resident resident, String targetAudience) {
        switch (targetAudience.toLowerCase()) {
            case AppConstants.TargetAudience.OWNERS:
                if (resident.getOwnerEmail() != null && !resident.getOwnerEmail().isEmpty()) {
                    loggerService.logInfo(resident.getOwnerEmail());
                    emails.add(resident.getOwnerEmail());
                }
                break;
            case AppConstants.TargetAudience.TENANTS:
                if (resident.getTenantEmail() != null && !resident.getTenantEmail().isEmpty()) {
                    loggerService.logInfo(resident.getTenantEmail());
                    emails.add(resident.getTenantEmail());
                }
                break;
            case AppConstants.TargetAudience.BOTH:
                if (resident.getOwnerEmail() != null && !resident.getOwnerEmail().isEmpty()) {
                    loggerService.logInfo(resident.getOwnerEmail());
                    emails.add(resident.getOwnerEmail());
                }
                if (resident.getTenantEmail() != null && !resident.getTenantEmail().isEmpty()) {
                    loggerService.logInfo(resident.getTenantEmail());
                    emails.add(resident.getTenantEmail());
                }
                break;
            default:
                break;
        }
    }

    @Async
    private List<NoticeFiles> fileUpload(List<MultipartFile> files, Notice notice, String noticeId) throws IOException {
        String fileDownloadUri = "";
        List<NoticeFiles> fileEntityList = new ArrayList<>();
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (!file.isEmpty()) {
                    s3FileHandler.validateFile(file);
                    String uniqueFileName = s3FileHandler.storeFile(file);
                    URL filePath = s3FileHandler.getFilePath(uniqueFileName);
                    if (!uniqueFileName.isEmpty()) {
                        if (Objects.requireNonNull(file.getContentType()).equalsIgnoreCase(MediaType.APPLICATION_PDF_VALUE)) {
                            fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                                    .path("/api/v1/pdf/")
                                    .path(uniqueFileName)
                                    .toUriString();
                        } else {
                            fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                                    .path("/api/v1/image/")
                                    .path(uniqueFileName)
                                    .toUriString();
                        }
                    }
                    NoticeFiles fileEntity = NoticeFiles.builder()
                            .fileName(uniqueFileName)
                            .awsUrl(filePath.toString())
                            .filePath(filePath.toString())
                            .fileUrl(fileDownloadUri)
                            .fileSize(file.getSize())
                            .fileType(file.getContentType())
                            .fileCategory("NOTICE")
                            .noticeTrackId(noticeId)
                            .notice(notice)
                            .build();
                    fileEntityList.add(fileEntity);
                }
            }
        }
        return fileEntityList;
    }


    @Override
    public List<ViewNoticeGroupDto> getFilteredNotices(Long societyId, Long areaId, Long apartmentId, String targetAudience) {
        Specification<Notice> spec = NoticeSpecification.filterNotices(societyId, areaId, apartmentId, targetAudience);
        List<Notice> allNotices = noticeRepository.findAll(spec);
        Map<String, ViewNoticeGroupDto> noticeGroupMap = new HashMap<>();
        for (Notice notice : allNotices) {
            noticeGroupMap.computeIfAbsent(notice.getNoticeId(), id -> {
                ViewNoticeGroupDto dto = modelMapper.map(notice, ViewNoticeGroupDto.class);
                dto.setAreas(new HashSet<>());
                dto.setApartments(new HashSet<>());
                dto.setNoticeFiles(new HashSet<>());
                return dto;
            });
            ViewNoticeGroupDto dto = noticeGroupMap.get(notice.getNoticeId());
            dto.setDescription(AppHelper.decompressHtml(notice.getDescription()));
            dto.getAreas().add(modelMapper.map(notice.getArea(), ViewAreaDto.class));
            dto.getApartments().add(modelMapper.map(notice.getApartment(), ViewApartmentDto.class));
            if (notice.getNoticeFile() != null) {
                for (NoticeFiles file : notice.getNoticeFile()) {
                    dto.getNoticeFiles().add(modelMapper.map(file, ViewNoticeFileDto.class));
                }
            }
            // Timezone conversion if not using ModelMapper converter
            String userTimezone = Optional.ofNullable(TimeZoneContext.getTimeZone()).orElse("UTC");
            dto.setPostedAt(AppHelper.convertToUserZone(notice.getPostedAt(), userTimezone));
            dto.setUpdatedAt(AppHelper.convertToUserZone(notice.getUpdatedAt(), userTimezone));
            dto.setExpiredAt(AppHelper.convertToUserZone(notice.getExpiredAt(), userTimezone));
        }
        return new ArrayList<>(noticeGroupMap.values());
    }

    @Override
    public ViewNoticeGroupDto getActiveNoticeById(String noticeId) {
        try {
            List<Notice> notices = noticeRepository.findByNoticeIdAndIsDeletedFalseAndExpiredFalse(noticeId);
            if (notices.isEmpty()) {
                throw new ResourceNotFoundException("Notice not found with ID: " + noticeId);
            }
            Map<String, ViewNoticeGroupDto> noticeGroupMap = new HashMap<>();
            for (Notice notice : notices) {
                noticeGroupMap.computeIfAbsent(notice.getNoticeId(), id -> {
                    ViewNoticeGroupDto dto = modelMapper.map(notice, ViewNoticeGroupDto.class);
                    dto.setAreas(new HashSet<>());
                    dto.setApartments(new HashSet<>());
                    dto.setNoticeFiles(new HashSet<>());
                    return dto;
                });
                ViewNoticeGroupDto dto = noticeGroupMap.get(notice.getNoticeId());
                dto.setDescription(AppHelper.decompressHtml(notice.getDescription()));
                if (notice.getArea() != null) {
                    dto.getAreas().add(modelMapper.map(notice.getArea(), ViewAreaDto.class));
                }
                if (notice.getApartment() != null) {
                    dto.getApartments().add(modelMapper.map(notice.getApartment(), ViewApartmentDto.class));
                }
                if (notice.getNoticeFile() != null) {
                    for (NoticeFiles file : notice.getNoticeFile()) {
                        dto.getNoticeFiles().add(modelMapper.map(file, ViewNoticeFileDto.class));
                    }
                }
                // Timezone conversion if not using ModelMapper converter
                String userTimezone = Optional.ofNullable(TimeZoneContext.getTimeZone()).orElse("UTC");
                dto.setPostedAt(AppHelper.convertToUserZone(notice.getPostedAt(), userTimezone));
                dto.setUpdatedAt(AppHelper.convertToUserZone(notice.getUpdatedAt(), userTimezone));
                dto.setExpiredAt(AppHelper.convertToUserZone(notice.getExpiredAt(), userTimezone));
            }
            return noticeGroupMap.values().iterator().next();
        } catch (Exception e) {
            throw new ServiceException("An error occurred while retrieving the notice", e);
        }
    }

}