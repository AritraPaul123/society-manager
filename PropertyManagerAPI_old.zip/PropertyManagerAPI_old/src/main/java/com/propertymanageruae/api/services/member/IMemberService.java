package com.propertymanageruae.api.services.member;

import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.location.LocationDTO;
import com.propertymanageruae.api.payloads.member.AddMemberDto;
import com.propertymanageruae.api.payloads.member.MemberRevokeDto;
import com.propertymanageruae.api.payloads.member.UpdateMemberDto;
import com.propertymanageruae.api.payloads.member.ViewMemberDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;


public interface IMemberService {
    String addMember(AddMemberDto memberDto) throws SQLIntegrityConstraintViolationException;

    String updateMember(UpdateMemberDto memberDto, long id) throws SQLIntegrityConstraintViolationException;

    String addMemberWithProfile(AddMemberDto memberDto, MultipartFile profileImage) throws SQLIntegrityConstraintViolationException;

    String updateMemberWithProfile(UpdateMemberDto memberDto, long id, MultipartFile profileImage) throws SQLIntegrityConstraintViolationException, IOException;

    void deleteMember(long id);

    ViewMemberDto getMember(long id);

    PaginationDto<ViewMemberDto> getMembers(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, long societyId);

    public List<ViewMemberDto> getAllUser(Long roleId, long societyId);

    public List<RoleDTO> getAllUserRole();

    public List<RoleDTO> getAllUserRole(long societyId);

    public List<LocationDTO> getAllLocation();

    public void softDeleteMember(long id, long societyId) throws SQLIntegrityConstraintViolationException;

    public String revokeMember(Long memberId, MemberRevokeDto statusUpdateDTO);

    PaginationDto<ViewMemberDto> getMembersFromResident(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, long societyId);
}