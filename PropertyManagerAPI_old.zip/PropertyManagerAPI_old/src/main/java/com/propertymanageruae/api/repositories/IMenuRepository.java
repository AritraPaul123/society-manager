package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Menu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IMenuRepository extends JpaRepository<Menu, Long> {
    List<Menu> findByParentMenuId(Long parentId);
    List<Menu> findByParentMenuIsNullOrderByOrderNoAsc();

    List<Menu> findByParentMenuOrderByOrderNoAsc(Menu parentMenu);

    @Query("SELECT MAX(m.orderNo) FROM Menu m WHERE m.parentMenu IS NULL")
    Integer findMaxOrderNoByParentMenuIsNull();

    @Query("SELECT MAX(m.orderNo) FROM Menu m WHERE m.parentMenu.id = :parentId")
    Integer findMaxOrderNoByParentMenuId(@Param("parentId") Long parentId);

    @Query("FROM Menu m WHERE m.id = :id OR m.parentMenu.id = :id")
    List<Menu> findAllByIdOrParentMenuId(@Param("id") Long id);
}