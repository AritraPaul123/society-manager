package com.propertymanageruae.api.specificaions;


import com.propertymanageruae.api.entities.Role;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.entities.UserRoleMapping;
import jakarta.persistence.criteria.Join;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public class MemberSpecification {
    public static Specification<User> hasSocietyId(long societyId) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.equal(root.get("society").get("id"), societyId);
    }
    public static Specification<User> isNotDeleted(boolean isDelete) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.equal(root.get("isDelete"), isDelete);
    }
    public static Specification<User> hasNotUserId(long userId) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.notEqual(root.get("id"), userId);
    }
    public static Specification<User> hasRoleNotIn(List<Long> excludedRoleIds) {
        return (root, query, criteriaBuilder) -> {
            Join<User, UserRoleMapping> userMap = root.join("userRoleMappings");
            return criteriaBuilder.not(userMap.get("role").get("id").in(excludedRoleIds));
        };
    }
    public static Specification<User> searchByText(String searchText) {
        return (root, query, criteriaBuilder) -> {
            String searchPattern = "%" + searchText.toLowerCase() + "%";
            return criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("name")), searchPattern),
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("email")), searchPattern),
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("contactNumber")), searchPattern)
            );
        };
    }
}