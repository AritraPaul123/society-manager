package com.propertymanageruae.api.payloads.inspection;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ViewHomeInspectionDTO {

    private Long id;
    private Long societyId;
    private Long apartmentId;
    private String block;
    private String flat;
    private String floor;
    private String societyName;
    private String witness;
    private String remarks;
    private boolean isMoveIn;
    private String uniqueId;
    private int status;
    private String createdAt;
    private int totalImages;
   // private List<ViewInspectionSectionDTO> sections;



}
