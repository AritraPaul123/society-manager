package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.incident.IncidentDto;
import com.propertymanageruae.api.services.IncidentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/incidents")
public class Incident1Controller {

    @Autowired
    private IncidentService incidentService;

    @PostMapping("/")
    public ResponseEntity<IncidentDto> reportIncident(@RequestBody IncidentDto incidentDto) {
        return new ResponseEntity<>(incidentService.reportIncident(incidentDto), HttpStatus.CREATED);
    }

    @GetMapping("/society/{societyId}")
    public ResponseEntity<List<IncidentDto>> getIncidentsBySociety(@PathVariable Long societyId) {
        return ResponseEntity.ok(incidentService.getIncidentsBySociety(societyId));
    }

    @PostMapping("/{incidentId}/assign/{userId}")
    public ResponseEntity<IncidentDto> assignIncident(@PathVariable Long incidentId, @PathVariable Long userId) {
        return ResponseEntity.ok(incidentService.assignIncident(incidentId, userId));
    }
}
