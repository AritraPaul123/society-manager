package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "maillog")
public class MailLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name = "mail_to", length = 255, nullable = false)
    private String mailTo;
    @Column(name = "mail_from", length = 255, nullable = false)
    private String mailFrom;
    @Column(name = "mail_cc", length = 255)
    private String mailCC;
    @Column(name = "mail_bcc", length = 255)
    private String mailBCC;
    @Column(name = "mail_subject", length = 500)
    private String mailSubject;
    @Column(name = "status", length = 100)
    private String status;
    @Column(name = "purpose", length = 255)
    private String purpose;
    @Column(name = "mail_date", nullable = false)
    private LocalDateTime mailDate;
    @Column(name = "error_msg", length = 1000)
    private String errorMsg;
    @Column(name = "smtp", length = 255)
    private String smtp;
    @Column(name = "attachments", length = 500)
    private String attachments;
    @Column(name = "template_used", length = 255)
    private String templateUsed;
    @Column(name = "response_time_ms")
    private Long responseTimeMs;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @Column(name = "deleted_at", nullable = true)
    private LocalDateTime deletedAt;

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}