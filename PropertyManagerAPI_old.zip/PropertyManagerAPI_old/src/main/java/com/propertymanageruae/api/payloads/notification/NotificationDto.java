package com.propertymanageruae.api.payloads.notification;

import com.propertymanageruae.api.enums.NotificationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NotificationDto {
    public Long id;
    public Long userId;
    public String title;
    public String message;
    public NotificationType type;
    public boolean seen;
    public LocalDateTime createdAt;
}