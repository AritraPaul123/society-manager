//package com.propertymanageruae.api.services.user;
//
//import com.propertymanageruae.api.entities.Resident;
//import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
//import com.propertymanageruae.api.repositories.IResidentRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//
//@Service("customResidentDetailService")
//public class CustomResidentDetailService implements UserDetailsService,ICustomResidentDetailService{
//    @Autowired
//    private IResidentRepository residentRepository;
//    @Override
//    public Resident loadUserByUsername(String username)
//            throws UsernameNotFoundException {
//        return this.residentRepository.findByOwnerEmail(username)
//                .orElseThrow(()->new ResourceNotFoundException("Resident not found"));
//    }
//
//    @Override
//    public Resident LoggedInUser() {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        if (authentication != null && authentication.isAuthenticated()) {
//            return (Resident) authentication.getPrincipal();
//        }
//        return null;
//    }
//}