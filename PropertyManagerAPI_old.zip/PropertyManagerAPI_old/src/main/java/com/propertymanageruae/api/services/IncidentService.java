package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.payloads.incident.IncidentDto;
import com.propertymanageruae.api.repositories.*;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class IncidentService {

    @Autowired
    private IncidentRepository incidentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PatrolRepository patrolRepository;

    @Autowired
    private SocietyRepository societyRepository;

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Transactional
    public IncidentDto reportIncident(IncidentDto incidentDto) {
        Incident incident = modelMapper.map(incidentDto, Incident.class);
        
        User guard = userRepository.findById(incidentDto.getGuardId())
                .orElseThrow(() -> new RuntimeException("Guard not found"));
        incident.setGuard(guard);

        Society society = societyRepository.findById(incidentDto.getSocietyId())
                .orElseThrow(() -> new RuntimeException("Society not found"));
        incident.setSociety(society);

        if (incidentDto.getPatrolId() != null) {
            Patrol patrol = patrolRepository.findById(incidentDto.getPatrolId())
                    .orElseThrow(() -> new RuntimeException("Patrol not found"));
            incident.setPatrol(patrol);
        }

        // Auto-create a Helpdesk Complaint
        Complaint complaint = new Complaint();
        complaint.setComplainer(guard);
        complaint.setTitle("INCIDENT: " + incident.getTitle());
        complaint.setDescription(incident.getDescription());
        complaint.setStatus("OPEN");
        complaint.setSociety(society);
        // Map priority
        complaint.setPriority(incident.getPriority());
        
        Complaint savedComplaint = complaintRepository.save(complaint);
        incident.setComplaint(savedComplaint);

        Incident savedIncident = incidentRepository.save(incident);
        return convertToDto(savedIncident);
    }

    public List<IncidentDto> getIncidentsBySociety(Long societyId) {
        Society society = societyRepository.findById(societyId)
                .orElseThrow(() -> new RuntimeException("Society not found"));
        return incidentRepository.findBySociety(society).stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public IncidentDto assignIncident(Long incidentId, Long userId) {
        Incident incident = incidentRepository.findById(incidentId)
                .orElseThrow(() -> new RuntimeException("Incident not found"));
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        incident.setAssignedTo(user);
        incident.setStatus("ASSIGNED");
        
        // Also update the linked complaint
        if (incident.getComplaint() != null) {
            Complaint complaint = incident.getComplaint();
            complaint.setAssignedUser(user);
            complaint.setStatus("ASSIGNED");
            complaintRepository.save(complaint);
        }
        
        return convertToDto(incidentRepository.save(incident));
    }

    private IncidentDto convertToDto(Incident incident) {
        IncidentDto dto = modelMapper.map(incident, IncidentDto.class);
        dto.setGuardName(incident.getGuard().getName());
        if (incident.getAssignedTo() != null) {
            dto.setAssignedToName(incident.getAssignedTo().getName());
        }
        if (incident.getComplaint() != null) {
            dto.setComplaintId(incident.getComplaint().getComplaintId());
        }
        return dto;
    }
}
