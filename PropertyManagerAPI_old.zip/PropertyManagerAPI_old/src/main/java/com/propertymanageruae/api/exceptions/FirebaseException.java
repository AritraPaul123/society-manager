package com.propertymanageruae.api.exceptions;

import java.io.Serial;

public class FirebaseException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 1L;

    public FirebaseException(String message) {
        super(message);
    }

    public FirebaseException(String message, Throwable cause) {
        super(message, cause);
    }

    public FirebaseException(Throwable cause) {
        super(cause);
    }
}