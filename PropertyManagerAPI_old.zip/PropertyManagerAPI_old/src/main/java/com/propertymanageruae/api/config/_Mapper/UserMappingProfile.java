package com.propertymanageruae.api.config._Mapper;

import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import com.propertymanageruae.api.payloads.user.UserDTO;
import com.propertymanageruae.api.payloads.user.ViewUserDto;
import com.propertymanageruae.api.payloads.utils.SocietyRoleDto;
import jakarta.annotation.PostConstruct;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class UserMappingProfile {

    private final ModelMapper modelMapper;


    public UserMappingProfile(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;

    }

    @PostConstruct
    public void configureUserMapping() {

        //Configure UserDTO -> User (for incoming data)
        modelMapper.addMappings(new org.modelmapper.PropertyMap<ViewUserDto, User>() {
            @Override
            protected void configure() {
                skip(destination.getPassword());
                skip(destination.getCreatedAt());
                skip(destination.getUpdatedAt());
            }
        });

        // Configure User -> UserDTO (for outgoing data)
        TypeMap<User, UserDTO> typeMap = modelMapper.createTypeMap(User.class, UserDTO.class);
        typeMap.addMappings(mapper -> {
            mapper.skip(UserDTO::setPassword);
            mapper.skip(UserDTO::setSocietyRoles); // We handle it manually in postConverter
        });

        // User → UserDTO mapping
        typeMap.setPostConverter(context -> {
            User source = context.getSource();
            UserDTO destination = context.getDestination();
            if (source.getUserRoleMappings() != null) {
                List<SocietyRoleDto> societyRoles = source.getUserRoleMappings().stream()
                        .map(mapping -> {
                            SocietyRoleDto srd = new SocietyRoleDto();
                            srd.setSociety(modelMapper.map(mapping.getSociety(), ViewSocietyDto.class));
                            srd.setRole(modelMapper.map(mapping.getRole(), RoleDTO.class));
                            return srd;
                        })
                        .collect(Collectors.toList());
                destination.setSocietyRoles(societyRoles);
            }
            return destination;
        });

        // Post converter to populate societyRoles
        typeMap.setPostConverter(context -> {
            User source = context.getSource();
            UserDTO destination = context.getDestination();

            List<SocietyRoleDto> societyRoles = source.getUserRoleMappings().stream()
                    .map(mapping -> {
                        SocietyRoleDto srd = new SocietyRoleDto();
                        srd.setSociety(modelMapper.map(mapping.getSociety(), ViewSocietyDto.class));
                        srd.setRole(modelMapper.map(mapping.getRole(), RoleDTO.class));
                        return srd;
                    })
                    .collect(Collectors.toList());

            destination.setSocietyRoles(societyRoles);
            return context.getDestination();
        });

        // User → ViewUserDto mapping (THIS WAS MISSING)
        TypeMap<User, ViewUserDto> userToViewUserMap = modelMapper.createTypeMap(User.class, ViewUserDto.class);
        userToViewUserMap.setPostConverter(context -> {
            User source = context.getSource();
            ViewUserDto destination = context.getDestination();

            if (source.getUserRoleMappings() != null) {
                List<SocietyRoleDto> societyRoles = source.getUserRoleMappings().stream()
                        .map(mapping -> {
                            SocietyRoleDto srd = new SocietyRoleDto();
                            srd.setSociety(modelMapper.map(mapping.getSociety(), ViewSocietyDto.class));
                            srd.setRole(modelMapper.map(mapping.getRole(), RoleDTO.class));
                            return srd;
                        })
                        .collect(Collectors.toList());
                destination.setSocietyRoles(societyRoles);
            }

            return destination;
        });
    }
}