package com.propertymanageruae.api.repositories;


import com.propertymanageruae.api.entities.LeaseTerm;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LeaseTermRepository extends JpaRepository<LeaseTerm, Long> {
    List<LeaseTerm> findByLeaseId(Long leaseId);
}