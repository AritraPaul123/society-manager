package com.propertymanageruae.api.payloads.inspection;
import lombok.*;

import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ViewInspectionSectionDTO {
    private long id;
    private String title;
    private List<ViewSectionImageDTO> images;
}



