package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;

import java.sql.Timestamp;
import java.util.Collection;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "section_image")
public class SectionImage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fileName;

    @Column(nullable = false, columnDefinition = "DOUBLE DEFAULT 0.0")
    private double amount;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(length = 500)
    private String awsUrl;

    private Long imageSize;

    private String imageType;

    private String imageUrl;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "home_inspection_id", nullable = false)
    private HomeInspection homeInspection;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inspection_section_id", nullable = false)
    private InspectionSection inspectionSection;

    @Column(name = "is_deleted", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDeleted = false;

    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;


}
