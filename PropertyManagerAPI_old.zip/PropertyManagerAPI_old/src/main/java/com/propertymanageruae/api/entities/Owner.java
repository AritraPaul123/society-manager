package com.propertymanageruae.api.entities;

import java.util.HashSet;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Owner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String ownerName;
    // private String phonenumber;
    // @Column(unique = true)
    // private String email;
    // @Column(unique = true)
    // private String emiratesId;
    // private String passportNumber;
    private String lessorName;
    private String lessorMobileNo;
     @Column(unique = true)
    private String lessorEmail;
    private String lessorEmiratesId;
    private String lessorAuthority;
    private Integer licenseNo;
    // private String address;
    // private String city;
    // private String country;

    @ManyToMany
    @JoinTable(
            name = "property_owner",
            joinColumns = @JoinColumn(name = "owner_id"),
            inverseJoinColumns = @JoinColumn(name = "property_id")
    )
    @JsonIgnoreProperties("owners")
    private Set<Property> properties = new HashSet<>();


}
