//package com.propertymanageruae.api.scheduler;
//
//import org.quartz.spi.TriggerFiredBundle;
//import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
//import org.springframework.context.ApplicationContext;
//import org.springframework.scheduling.quartz.SpringBeanJobFactory;
//
//
//public class AutowiringSpringBeanJobFactory extends SpringBeanJobFactory {
//
//
//    private final AutowireCapableBeanFactory beanFactory;
//
//
//    public AutowiringSpringBeanJobFactory(ApplicationContext context) {
//        this.beanFactory = context.getAutowireCapableBeanFactory();
//    }
//
//
//    @Override
//    protected Object createJobInstance(TriggerFiredBundle bundle) throws Exception {
//        Object job = super.createJobInstance(bundle);
//        beanFactory.autowireBean(job);
//        return job;
//    }
//}