//package com.nbhood.api.services.user;
//
//import com.nbhood.api.entities.Resident;
//
//public interface ICustomResidentDetailService {
//    Resident LoggedInUser();
//
//}