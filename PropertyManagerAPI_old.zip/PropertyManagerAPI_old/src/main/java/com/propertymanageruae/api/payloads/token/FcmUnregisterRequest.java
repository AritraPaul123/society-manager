package com.propertymanageruae.api.payloads.token;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FcmUnregisterRequest {
    private Long userId;
    private String deviceId;
}