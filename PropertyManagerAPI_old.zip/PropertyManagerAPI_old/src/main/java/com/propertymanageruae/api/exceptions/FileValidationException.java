package com.propertymanageruae.api.exceptions;


public class FileValidationException extends RuntimeException {
    public FileValidationException(String message) {
        super(message);
    }
}