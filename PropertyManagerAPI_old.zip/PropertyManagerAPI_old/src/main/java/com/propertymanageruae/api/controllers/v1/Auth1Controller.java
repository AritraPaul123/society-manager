package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.RefreshToken;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.exceptions.AuthException;
import com.propertymanageruae.api.payloads.ExternalDTO.MailDto;
import com.propertymanageruae.api.payloads.OTP.OtpReqDto;
import com.propertymanageruae.api.payloads.OTP.OtpResponseDto;
import com.propertymanageruae.api.payloads.OTP.OtpValidateDto;
import com.propertymanageruae.api.payloads.token.RefreshTokenDTO;
import com.propertymanageruae.api.payloads.user.*;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.repositories.IUserRepository;
import com.propertymanageruae.api.security.JwtTokenHelper;
import com.propertymanageruae.api.services.OTP.OtpService;
import com.propertymanageruae.api.services.UnitService;
import com.propertymanageruae.api.services.user.CustomUserDetailService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v${api.version}/auth")
@Tag(name = "Auth")
public class Auth1Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Autowired
    private JwtTokenHelper jwtTokenHelper;

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private UnitService _unitService;
    @Autowired
    private CustomUserDetailService userDetailsService;
    @Autowired
    private OtpService otpService;
    @Value("${app.member.password}")
    private String password;

    @PostMapping("/authenticate")
    public ResponseEntity<ApiResponse<JwtAuthResponse>> createToken(@Valid @RequestBody JwtAuthRequest request) throws Exception {
        Authentication authentication = this.authenticate(request.getUsername(), request.getPassword());
        UserDetails userDetails = this.userDetailsService.loadUserByUsername(request.getUsername());
        User user = (User) userDetails;
        Set<Long> roles = user.getUserRoleMappings().stream().map(x -> x.getRole().getId()).collect(Collectors.toSet());
        List<Long> webAllowedRoles = List.of(AppConstants.RoleConstant.MASTER_ACCESS_USER,
                AppConstants.RoleConstant.ADMIN_USER, AppConstants.RoleConstant.SUPERADMIN_USER, AppConstants.RoleConstant.STAFF_USER);
        List<Long> mobileAllowedRoles = List.of(AppConstants.RoleConstant.RESIDENTIAL_USER, AppConstants.RoleConstant.ADMIN_USER,AppConstants.RoleConstant.SUPERADMIN_USER, AppConstants.RoleConstant.STAFF_USER, AppConstants.RoleConstant.GROUNDSTAFF_USER);
        if (AppConstants.Platform.WEB.equalsIgnoreCase(request.getPlatform()) &&
                roles.stream().noneMatch(webAllowedRoles::contains)) {
            throw new AuthException("Unauthorized: Your role is not allowed to log in via Web");
        }
        if (AppConstants.Platform.MOBILE.equalsIgnoreCase(request.getPlatform()) &&
                roles.stream().noneMatch(mobileAllowedRoles::contains)) {
            throw new AuthException("Unauthorized: Your role is not allowed to log in via Mobile");
        }
        String token = this.jwtTokenHelper.generateToken(userDetails);
        RefreshToken refreshToken = this._unitService.refreshTokenService.createRefreshToken(userDetails.getUsername());
        JwtAuthResponse response = new JwtAuthResponse();
        response.setRefreshToken(refreshToken.getToken());
        response.setToken(token);
        response.setUser(this.modelMapper.map((User) userDetails, ViewUserDto.class));
        return ResponseEntity.ok(
                ApiResponse.success(response, "Authentication successful", null, HttpStatus.OK.value())
        );
    }

    @PostMapping("/logout")
    @SecurityRequirement(name = "auth")
    public ResponseEntity<ApiResponse<String>> logout(@RequestBody JwtAuthRequest requestBody, HttpServletRequest request) {
        UserDetails userDetails = this.userDetailsService.loadUserByUsername(requestBody.getUsername());
        String token = jwtTokenHelper.getTokenFromRequest(request);
        if (token == null || !jwtTokenHelper.validateToken(token, userDetails)) {
            throw new AuthException("Invalid or missing token!");
        }
        String username = jwtTokenHelper.getUsernameFromToken(token);
        _unitService.refreshTokenService.revokeRefreshTokens(requestBody);
        return ResponseEntity.ok(
                ApiResponse.success(null, "Logout successful", null, HttpStatus.OK.value())
        );
    }

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<UserDTO>> register(@Valid @RequestBody UserDTO userDto) throws SQLIntegrityConstraintViolationException {
        // userDto.setPassword(password); // Removed overwrite
        UserDTO registeredUser = this._unitService.userService.register(userDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(registeredUser, "User registered successfully", null, HttpStatus.CREATED.value()));
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<ApiResponse<JwtAuthResponse>> refreshToken(@Valid @RequestBody RefreshTokenDTO refreshTokenDto) {
        RefreshToken refreshToken = this
                ._unitService
                .refreshTokenService
                .verifyRefreshToken(refreshTokenDto.getToken());
        JwtAuthResponse response = new JwtAuthResponse();
        response.setRefreshToken(refreshTokenDto.getToken());
        User user = refreshToken.getUser();
        String token = this.jwtTokenHelper.generateToken(user);
        response.setToken(token);
        response.setUser(this.modelMapper.map(user, ViewUserDto.class));
        return ResponseEntity.ok(
                ApiResponse.success(response, "Token refreshed successfully", null, HttpStatus.OK.value())
        );
    }

    private Authentication authenticate(String username, String password) throws Exception {
        try {
            return this.authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username, password));
        } catch (InternalAuthenticationServiceException e) {
            throw new AuthException("Invalid Email");
        } catch (BadCredentialsException e) {
            throw new AuthException("Wrong Password! ");
        }
    }

    @PostMapping("/send-otp")
    public ResponseEntity<ApiResponse<OtpResponseDto>> sendOtp(@RequestBody OtpReqDto req) throws Exception {
        OtpValidateDto otpValidateDto = this._unitService.otpService.generateOtp(req.getEmail());
        if (otpValidateDto.getOtpIdentifier() == null || otpValidateDto.getOtp() == null) {
            OtpResponseDto otp1 = new OtpResponseDto("ERROR", null, false, false);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error on OTP send", null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
        OtpResponseDto otp1 = new OtpResponseDto("SUCCESS", otpValidateDto, true, false);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(otp1, "OTP sent successfully", null, HttpStatus.CREATED.value()));

    }

    @PostMapping("/validate-otp")
    public ResponseEntity<ApiResponse<OtpResponseDto>> validateOtp(@RequestBody OtpValidateDto otpValidate) {
        boolean isValid = this._unitService.otpService.validateOtp(otpValidate);
        if (isValid) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.success(new OtpResponseDto("SUCCESS", null, true, true), "OTP validate successfully", null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.success(new OtpResponseDto("ERROR", null, false, false), "Invalid OTP", null, HttpStatus.BAD_REQUEST.value()));
        }
    }

    @PostMapping("/send-email")
    public ResponseEntity<String> sendEmail(@RequestBody MailDto request) {
        long loggedInId = this.userDetailsService.LoggedInUser().getId();
        CompletableFuture<Boolean> result = this._unitService.gmailOAuthService.sendEmail(request);
        return ResponseEntity.ok("Email is being processed asynchronously.");
    }

    @GetMapping("/me/{userId}")
    @SecurityRequirement(name = "auth")
    public ResponseEntity<ApiResponse<UserProfileDto>> getProfileDetails(@PathVariable ("userId") long userId) {
        UserProfileDto userProfile = this._unitService.userService.getUserProfile(userId);
        if (userProfile == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error("User not found", null, null, HttpStatus.NOT_FOUND.value()));
        }
        return ResponseEntity.ok(ApiResponse.success(userProfile, "User profile retrieved successfully", null, HttpStatus.OK.value()));
    }

}