package com.propertymanageruae.api.config;

public class TimeZoneContext {
    private static final ThreadLocal<String> userTimeZone = new ThreadLocal<>();

    public static void setTimeZone(String timeZone) {
        userTimeZone.set(timeZone);
    }

    public static String getTimeZone() {
        return userTimeZone.get();
    }

    public static void clear() {
        userTimeZone.remove();
    }
}