package com.propertymanageruae.api.services.utils;

import com.propertymanageruae.api.entities.ErrorLog;
import com.propertymanageruae.api.repositories.IErrorLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;


@Service
public class ErrorLogService implements IErrorLogService {

    private final IErrorLogRepository repository;

    public ErrorLogService(IErrorLogRepository repository) {
        this.repository = repository;
    }

    @Override
    @Transactional
    public String saveException(Throwable ex, String requestUri) {
        StringWriter sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        String stack = sw.toString();
        String message = ex.getMessage();
        if (message == null) message = "No message";

        ErrorLog log = ErrorLog.of("Request: " + requestUri + " | " + message, stack);
        ErrorLog saved = repository.save(log);
        return saved.getErrorCode();
    }

    @Override
    @Transactional
    public void deleteLogsOlderThan(Timestamp ts) {
        repository.deleteByCreatedAtBefore(ts);
    }
}