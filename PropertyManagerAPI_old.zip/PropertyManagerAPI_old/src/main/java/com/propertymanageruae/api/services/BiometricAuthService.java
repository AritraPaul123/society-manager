package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.user.BiometricEnrollmentDto;
import com.propertymanageruae.api.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class BiometricAuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void enrollBiometric(Long userId, BiometricEnrollmentDto enrollmentDto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (enrollmentDto.getFaceIdData() != null) {
            user.setFaceIdData(enrollmentDto.getFaceIdData()); // In real app, this should be encrypted
            user.setFaceIdEnrolled(true);
        }

        if (enrollmentDto.getPasscode() != null) {
            user.setPasscode(passwordEncoder.encode(enrollmentDto.getPasscode()));
        }

        if (enrollmentDto.getBiometricRequired() != null) {
            user.setBiometricRequired(enrollmentDto.getBiometricRequired());
        }

        user.setLastBiometricUpdate(LocalDateTime.now());
        userRepository.save(user);
    }

    public boolean verifyPasscode(Long userId, String passcode) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        if (user.getPasscode() == null) {
            return false;
        }
        
        return passwordEncoder.matches(passcode, user.getPasscode());
    }

    public boolean isFaceIdEnrolled(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return user.getFaceIdEnrolled();
    }
}
