package com.propertymanageruae.api.Filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class SwaggerBasicAuthFilter extends OncePerRequestFilter {

    private static final String SWAGGER_PATH = "/swagger";
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "rms@dev";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getRequestURI();
        if (path.startsWith(SWAGGER_PATH)) {
            String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
            if (authHeader != null && authHeader.startsWith("Basic ")) {
                // Decode credentials
                String base64Credentials = authHeader.substring("Basic ".length());
                byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
                String credentials = new String(credDecoded, StandardCharsets.UTF_8);
                String[] values = credentials.split(":", 2);
                if (values.length == 2 &&
                        USERNAME.equals(values[0]) &&
                        PASSWORD.equals(values[1])) {
                    filterChain.doFilter(request, response);
                    return;
                }
            }
            // Unauthorized
            response.setHeader("WWW-Authenticate", "Basic realm=\"Swagger\"");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        } else {
            filterChain.doFilter(request, response);
        }
    }
}