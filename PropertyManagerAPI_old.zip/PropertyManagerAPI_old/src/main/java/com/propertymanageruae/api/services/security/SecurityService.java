package com.propertymanageruae.api.services.security;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

@Service
public class SecurityService implements ISecurityService {
    @Value("${security.encryptionKey}")
    private String encryptionKey;

    @Value("${security.encryptionVI}")
    private String encryptionVI;

    private SecretKeySpec secretKey;
    private IvParameterSpec iv;

    @PostConstruct
    private void init() {
        secretKey = new SecretKeySpec(encryptionKey.getBytes(), "AES");
        iv = new IvParameterSpec(encryptionVI.getBytes());
    }

    @Override
    public String encryptText(String plainText) {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
            byte[] encrypted = cipher.doFinal(plainText.getBytes());

            return bytesToHex(encrypted);
        } catch (Exception e) {
            throw new RuntimeException("Encryption failed: " + e.getMessage(), e);
        }
    }

    @Override
    public String decryptText(String hexCipher) {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
            byte[] cipherBytes = hexToBytes(hexCipher);
            byte[] decrypted = cipher.doFinal(cipherBytes);

            return new String(decrypted);
        } catch (Exception e) {
            throw new RuntimeException("Decryption failed: " + e.getMessage(), e);
        }
    }

    // 🔹 Utility Methods
    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));  // lowercase hex
        }
        return sb.toString();
    }

    private byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] result = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            result[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i+1), 16));
        }
        return result;
    }

}