package com.propertymanageruae.api.services.inspection;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

import com.itextpdf.text.pdf.draw.LineSeparator;
import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.S3FileHandler;
import com.propertymanageruae.api.payloads.inspection.*;
import com.propertymanageruae.api.repositories.IHomeInspectionRepository;
import com.propertymanageruae.api.repositories.IInspectionSectionRepository;
import com.propertymanageruae.api.repositories.ISectionImageRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import com.propertymanageruae.api.services.user.ICustomUserDetailService;
import com.propertymanageruae.api.specificaions.HomeInspectionSpecification;
import com.propertymanageruae.api.utility.Status;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

@Service
public class HomeInspectionService implements IHomeInspectionService {

    private static final Logger logger = LoggerFactory.getLogger(HomeInspectionService.class);

    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private IHomeInspectionRepository homeInspectionRepository;
    @Autowired
    private IInspectionSectionRepository iInspectionSection;
    @Autowired
    private ISectionImageRepository iSectionImageRepository;
    @Autowired
    private ICustomUserDetailService customUserDetailService;
    @Autowired
    private S3FileHandler s3FileHandler;

    @Override
    public String createInspection(HomeInspectionDTO inspectionDTO) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            User user = userRepository.findById(loggedInId).orElseThrow(() -> new ResourceNotFoundException("User not found with id " + loggedInId));
            if (inspectionDTO.getSocietyId() == null) {
                throw new IllegalArgumentException("Society Name is required for home inspection");
            }
            HomeInspection model = modelMapper.map(inspectionDTO, HomeInspection.class);
            model.setCreatedBy(user.getId());
            model.setStatus(Status.DRAFTED);
            model.setUniqueId(generateUniqueId());
            HomeInspection savedInspection = homeInspectionRepository.save(model);
            if(savedInspection.getId() !=0){
            return null;
            } else {
                return AppConstants.Message.NOT_SAVED;
            }
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while adding inspection");
        } catch (Exception ex) {
            throw ex;
        }
    }
    private String generateUniqueId() {
        String lastId = homeInspectionRepository.findLastUniqueId();
        if (lastId == null || lastId.isEmpty()) {
            return "ID-001";
        }
        int num = Integer.parseInt(lastId.substring(3));
        num++;
        return String.format("ID-%03d", num);
    }


    @Override
    public ViewHomeInspectionDTO editInspection(HomeInspectionDTO inspectionDTO, long id) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            User user = userRepository.findById(loggedInId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + loggedInId));

            HomeInspection existingInspection = homeInspectionRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException(AppConstants.Message.NOT_EXISTS));

            if (existingInspection.getStatus() == Status.ACTIVE) {
                throw new IllegalArgumentException(AppConstants.Message.NOT_UPDATED);
            }

            // Update only provided fields
            if (inspectionDTO.getSocietyId() != null)
                existingInspection.setSocietyId(inspectionDTO.getSocietyId());
            existingInspection.setApartmentId(inspectionDTO.getApartmentId());
            existingInspection.setSocietyName(inspectionDTO.getSocietyName());
            existingInspection.setBlock(inspectionDTO.getBlock());
            existingInspection.setFlat(inspectionDTO.getFlat());
            existingInspection.setFloor(inspectionDTO.getFloor());
            //existingInspection.setMoveIn(inspectionDTO.get);
            existingInspection.setModifiedBy(user.getId());
            // Save updated inspection
            HomeInspection updated = homeInspectionRepository.save(existingInspection);
            return modelMapper.map(updated, ViewHomeInspectionDTO.class);
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while editing inspection");
        }
    }

    @Override
    public ViewHomeInspectionDTO finalSubmit(InspectionFinalRequest request, long inspectionId) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            User user = userRepository.findById(loggedInId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id " + loggedInId));

            HomeInspection inspection = homeInspectionRepository.findById(inspectionId)
                    .orElseThrow(() -> new ResourceNotFoundException(AppConstants.Message.NOT_EXISTS));

            if (inspection.getStatus() == Status.ACTIVE) {
                throw new IllegalArgumentException(AppConstants.Message.ALREADY_EXISTS);
            }
            inspection.setModifiedBy(user.getId());
            inspection.setStatus(Status.ACTIVE);
            inspection.setWitness(request.getWitness());
            inspection.setRemarks(request.getRemarks());
            // Save updated inspection
            HomeInspection savedInspection = homeInspectionRepository.save(inspection);
            return modelMapper.map(savedInspection, ViewHomeInspectionDTO.class);
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while finalizing inspection");
        }
    }

    @Override
    public List<ViewHomeInspectionDTO> getAllInspections(long societyId,String searchText, String dateRange)
            throws SQLIntegrityConstraintViolationException {
        Specification<HomeInspection> spec = Specification
                .where(HomeInspectionSpecification.hasSocietyId(societyId))
                .and(HomeInspectionSpecification.hasStatus(Status.ACTIVE))
                .and(HomeInspectionSpecification.searchByText(searchText))
                .and(HomeInspectionSpecification.inDateRange(dateRange));
        return homeInspectionRepository.findAll(spec).stream()
                .map(inspection -> {
                    ViewHomeInspectionDTO dto = modelMapper.map(inspection, ViewHomeInspectionDTO.class);
                    dto.setTotalImages(inspection.getInspectionSections().stream()
                            .mapToInt(section -> section.getSectionImages().size())
                            .sum()
                    );
                    return dto;
                })
                .toList();
    }

    @Override
    public String uploadSectionImage(SectionImageDTO dto, MultipartFile file) throws IOException {
        try {
            SectionImage sectionImage = modelMapper.map(dto, SectionImage.class);

            HomeInspection homeInspection = homeInspectionRepository
                    .findById(dto.getInspectionId())
                    .orElseThrow(() -> new RuntimeException("Home Inspection not found"));

            InspectionSection inspectionSection = iInspectionSection
                    .findById(dto.getSectionId())
                    .orElseThrow(() -> new RuntimeException("Inspection Section not found"));

            sectionImage.setHomeInspection(homeInspection);
            sectionImage.setInspectionSection(inspectionSection);

            if (file != null && !file.isEmpty()) {
                s3FileHandler.validateFile(file);

                String uniqueFileName = s3FileHandler.storeFile(file);
                URL filePath = s3FileHandler.getFilePath(uniqueFileName);

                String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/api/v1/image/")
                        .path(uniqueFileName)
                        .toUriString();

                sectionImage.setFileName(uniqueFileName);
                sectionImage.setAwsUrl(filePath.toString());
                sectionImage.setImageSize(file.getSize());
                sectionImage.setImageType(file.getContentType());
                sectionImage.setImageUrl(fileDownloadUri);
            }
            SectionImage savedImage = iSectionImageRepository.saveAndFlush(sectionImage);
            if (savedImage.getId() != null) {
                return null;
            } else {
                return AppConstants.Message.FILE_NOT_UPLOADED;
            }
        } catch (Exception e) {
            return "Failed: " + e.getMessage();
        }
    }


    @Override
    public byte[] generateInspectionPDF(Long inspectionId) throws Exception {

        HomeInspection inspection = homeInspectionRepository.findById(inspectionId)
                .orElseThrow(() -> new RuntimeException("Inspection not found with id: " + inspectionId));

        List<SectionImage> images = iSectionImageRepository.findByHomeInspectionId(inspectionId);

        double totalAmount = images.stream()
                .mapToDouble(SectionImage::getAmount)
                .sum();

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            Document document = new Document(PageSize.A4, 36, 36, 54, 36);
            PdfWriter writer = PdfWriter.getInstance(document, baos);
            document.open();

            // FONTS
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.WHITE);
            Font h1Font = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD);
            Font labelFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
            Font valueFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
            Font descFont = new Font(Font.FontFamily.HELVETICA, 11, Font.NORMAL);
            Font missingDetailFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC, BaseColor.GRAY);

            // HEADER
            PdfPTable headerTable = new PdfPTable(1);
            headerTable.setWidthPercentage(100);

            Paragraph heading = new Paragraph("Property Inspection Report", h1Font);
            heading.setAlignment(Element.ALIGN_CENTER);

            PdfPCell headerCell = new PdfPCell(heading);
            headerCell.setBorder(Rectangle.NO_BORDER);
            headerCell.setPaddingTop(10);
            headerCell.setPaddingBottom(15);
            headerTable.addCell(headerCell);

            PdfPCell subHeaderCell = new PdfPCell(
                    new Phrase(inspection.getSocietyName() + " | UNIT-" + inspection.getFlat(), titleFont)
            );
            subHeaderCell.setBackgroundColor(new BaseColor(102, 102, 153));
            subHeaderCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            subHeaderCell.setPadding(8);
            subHeaderCell.setBorder(Rectangle.NO_BORDER);
            headerTable.addCell(subHeaderCell);

            document.add(headerTable);
            document.add(Chunk.NEWLINE);

            // DETAILS TABLE (LEFT + RIGHT)
            Date generationDate = new Date();
            PdfPTable mainTable = new PdfPTable(2);
            mainTable.setWidthPercentage(100);
            mainTable.setWidths(new float[]{0.5f, 0.5f});
            mainTable.setSpacingBefore(10f);
            mainTable.setSpacingAfter(10f);

            // LEFT TABLE
            PdfPTable leftTable = new PdfPTable(2);
            leftTable.setWidthPercentage(100);
            addDetail(leftTable, "Date:", new SimpleDateFormat("dd MMMM yyyy").format(generationDate), labelFont, valueFont, missingDetailFont);
            addDetail(leftTable, "Time:", new SimpleDateFormat("hh:mm a").format(generationDate), labelFont, valueFont, missingDetailFont);
            addDetail(leftTable, "Inspector’s Name:", "none", labelFont, valueFont, missingDetailFont);
            addDetail(leftTable, "Block:", inspection.getBlock(), labelFont, valueFont, missingDetailFont);

            // RIGHT TABLE
            PdfPTable rightTable = new PdfPTable(2);
            rightTable.setWidthPercentage(100);
            addDetail(rightTable, "Remarks:", inspection.getRemarks(), labelFont, valueFont, missingDetailFont);
            addDetail(rightTable, "Witness:", inspection.getWitness(), labelFont, valueFont, missingDetailFont);
            addDetail(rightTable, "Total Amount:", "$" + String.format("%.2f", totalAmount), labelFont, valueFont, missingDetailFont);

            PdfPCell leftCell = new PdfPCell(leftTable);
            leftCell.setBorder(Rectangle.NO_BORDER);

            PdfPCell rightCell = new PdfPCell(rightTable);
            rightCell.setBorder(Rectangle.NO_BORDER);

            mainTable.addCell(leftCell);
            mainTable.addCell(rightCell);

            document.add(mainTable);

            // LINE SEPARATOR
            LineSeparator horizontalLine = new LineSeparator();
            horizontalLine.setLineWidth(1);
            horizontalLine.setLineColor(BaseColor.GRAY);
            document.add(new Chunk(horizontalLine));

            // GROUP IMAGES BY SECTION
            Map<InspectionSection, List<SectionImage>> sectionMap = new LinkedHashMap<>();
            for (SectionImage img : images) {
                sectionMap.computeIfAbsent(img.getInspectionSection(), k -> new ArrayList<>()).add(img);
            }

            // SECTIONS LOOP
            for (Map.Entry<InspectionSection, List<SectionImage>> entry : sectionMap.entrySet()) {

                InspectionSection section = entry.getKey();
                List<SectionImage> sectionImages = entry.getValue();

                // Section Title
                String titleText = (section != null) ? section.getTitle() : "Unassigned Section";
                Paragraph sectionTitle = new Paragraph(titleText, labelFont);
                sectionTitle.setSpacingBefore(15);
                sectionTitle.setSpacingAfter(5);
                document.add(sectionTitle);

                // IMAGE GRID (4 per row)
                PdfPTable imageTable = new PdfPTable(4);
                imageTable.setWidthPercentage(100);
                imageTable.setSpacingBefore(5);
                imageTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

                float imgWidth = 100f;
                float imgHeight = 100f;
                int serial1 = 1;

                for (SectionImage img : sectionImages) {

                    PdfPCell imageCell = new PdfPCell();
                    imageCell.setBorder(Rectangle.NO_BORDER);
                    imageCell.setPadding(5);
                    imageCell.setHorizontalAlignment(Element.ALIGN_CENTER);

                    try {
                        Image pdfImage = Image.getInstance(new URL(img.getAwsUrl()));
                        pdfImage.scaleAbsolute(imgWidth, imgHeight);

                        Anchor clickable = new Anchor("");
                        clickable.setReference(img.getAwsUrl());
                        clickable.add(new Chunk(pdfImage, 0, 0, true));

                        Paragraph imgPara = new Paragraph();
                        imgPara.setAlignment(Element.ALIGN_CENTER);
                        imgPara.add(clickable);

                        imageCell.addElement(imgPara);

                        Paragraph serialPara = new Paragraph(serial1 + ".", valueFont);
                        serialPara.setAlignment(Element.ALIGN_CENTER);
                        serialPara.setSpacingBefore(4);
                        serialPara.setSpacingAfter(4);
                        imageCell.addElement(serialPara);

                    } catch (Exception e) {

                        Paragraph failed = new Paragraph("⚠️ Image not available", descFont);
                        failed.setAlignment(Element.ALIGN_CENTER);
                        imageCell.addElement(failed);

                        Paragraph serialPara = new Paragraph(serial1 + ".", valueFont);
                        serialPara.setAlignment(Element.ALIGN_CENTER);
                        imageCell.addElement(serialPara);
                    }

                    imageTable.addCell(imageCell);
                    serial1++;
                }

                // Fill empty cells if needed (4 per row)
                int remainder = sectionImages.size() % 4;

                if (remainder != 0) {
                    for (int i = 0; i < (4 - remainder); i++) {
                        PdfPCell empty = new PdfPCell(new Phrase(""));
                        empty.setBorder(Rectangle.NO_BORDER);
                        imageTable.addCell(empty);
                    }
                }


                document.add(imageTable);

                // REMARKS + AMOUNT LIST
                int serial = 1;
                for (SectionImage img : sectionImages) {

                    if (img.getDescription() != null && !img.getDescription().trim().isEmpty()) {

                        PdfPTable table = new PdfPTable(2);
                        table.setWidthPercentage(100);
                        table.setWidths(new float[]{4, 1});

                        PdfPCell descCell = new PdfPCell(new Phrase(serial + ". " + img.getDescription(), descFont));
                        descCell.setBorder(Rectangle.NO_BORDER);
                        table.addCell(descCell);

                        PdfPCell amountCell = new PdfPCell(
                                new Phrase("$" + String.format("%.2f", img.getAmount()), descFont)
                        );
                        amountCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                        amountCell.setBorder(Rectangle.NO_BORDER);
                        table.addCell(amountCell);
                        document.add(table);
                        // Add a blank line after each table
                        Paragraph blankLine = new Paragraph(" ");
                        blankLine.setSpacingAfter(2f);
                        document.add(blankLine);
                        serial++;
                    }
                }

            }

            // FOOTER
            LineSeparator endLine = new LineSeparator();
            endLine.setLineWidth(1);
            endLine.setLineColor(BaseColor.GRAY);
            document.add(new Chunk(endLine));

            Paragraph footer = new Paragraph("Property Inspection Report - Confidential",
                    new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.DARK_GRAY));
            footer.setAlignment(Element.ALIGN_CENTER);
            footer.setSpacingBefore(5);
            document.add(footer);

            document.close();
            writer.close();

            return baos.toByteArray();

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("PDF generation failed: " + e.getMessage());
        }
    }
    private void addDetail(PdfPTable table, String label, String value,
                           Font labelFont, Font valueFont, Font missingFont) {

        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setPadding(4);

        Phrase valuePhrase = (value != null && !value.trim().isEmpty())
                ? new Phrase(value, valueFont)
                : new Phrase("- Missing Data -", missingFont);

        PdfPCell valueCell = new PdfPCell(valuePhrase);
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setPadding(4);

        table.addCell(labelCell);
        table.addCell(valueCell);
    }





}

