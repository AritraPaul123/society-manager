package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.entities.Area;
import org.springframework.data.jpa.domain.Specification;
import jakarta.persistence.criteria.Predicate;

public class AreaSpecification {
    public static Specification<Area> searchByText(String searchText, long societyId) {
        return (root, query, criteriaBuilder) -> {
            Predicate societyPredicate = criteriaBuilder.equal(root.get("society").get("id"), societyId);
            if (searchText == null || searchText.trim().isEmpty()) {
                return societyPredicate; // Only filter by societyId if searchText is empty
            }
            String likePattern = "%" + searchText.toLowerCase() + "%";
            Predicate areaPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("area")), likePattern);
            return criteriaBuilder.and(areaPredicate, societyPredicate);
        };
    }
}