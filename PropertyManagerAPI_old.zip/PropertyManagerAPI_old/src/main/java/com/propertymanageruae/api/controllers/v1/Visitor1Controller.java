package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.visitor.VisitorDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.VisitorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/api/v${api.version}/visitors")
@SecurityRequirement(name = "auth")
@Tag(name = "Visitor")
public class Visitor1Controller {

    @Value("${api.version}")
    private String apiVersion;

    @Autowired
    private VisitorService visitorService;

    @Operation(summary = "Check In Visitor")
    @PostMapping("/check-in")
    public ResponseEntity<ApiResponse<VisitorDto>> checkInVisitor(@RequestBody VisitorDto dto) {
        VisitorDto result = visitorService.visitorCheckIn(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(result, "Visitor check-in successful", null, HttpStatus.CREATED.value()));
    }

    @Operation(summary = "Check Out Visitor")
    @PostMapping("/check-out/{visitorId}")
    public ResponseEntity<ApiResponse<VisitorDto>> checkOutVisitor(@PathVariable Long visitorId) {
        VisitorDto result = visitorService.visitorCheckOut(visitorId);
        return ResponseEntity.ok(ApiResponse.success(result, "Visitor check-out successful", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Get All Active Visitors")
    @GetMapping("/active")
    public ResponseEntity<ApiResponse<List<VisitorDto>>> getActiveVisitors() {
        List<VisitorDto> list = visitorService.getAllActiveVisitors();
        return ResponseEntity.ok(ApiResponse.success(list, "Active visitors fetched", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Get All Visitors History")
    @GetMapping("/history")
    public ResponseEntity<ApiResponse<List<VisitorDto>>> getAllVisitors() {
        List<VisitorDto> list = visitorService.getAllVisitors();
        return ResponseEntity.ok(ApiResponse.success(list, "Visitor history fetched", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Find Visitor by Emirates ID")
    @GetMapping("/search/{emiratesId}")
    public ResponseEntity<ApiResponse<VisitorDto>> findByEmiratesId(@PathVariable String emiratesId) {
        VisitorDto result = visitorService.findByEmiratesId(emiratesId);
        return ResponseEntity.ok(ApiResponse.success(result, "Visitor found", null, HttpStatus.OK.value()));
    }
}
