package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.patrol.PatrolDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.PatrolService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v${api.version}/patrols")
@SecurityRequirement(name = "auth")
@Tag(name = "Patrol")
public class Patrol1Controller {

    @Value("${api.version}")
    private String apiVersion;

    @Autowired
    private PatrolService patrolService;

    @Operation(summary = "Start Patrol")
    @PostMapping("/start")
    public ResponseEntity<ApiResponse<PatrolDto>> startPatrol(
            @RequestParam Long guardId,
            @RequestParam(required = false) Long routeId,
            @RequestParam(defaultValue = "false") Boolean isOffline) {
        PatrolDto dto = patrolService.startPatrol(guardId, routeId, isOffline);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(dto, "Patrol started", null, HttpStatus.CREATED.value()));
    }

    @Operation(summary = "Pause Patrol")
    @PostMapping("/{patrolId}/pause")
    public ResponseEntity<ApiResponse<PatrolDto>> pausePatrol(@PathVariable Long patrolId) {
        PatrolDto dto = patrolService.pausePatrol(patrolId);
        return ResponseEntity.ok(ApiResponse.success(dto, "Patrol paused", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Resume Patrol")
    @PostMapping("/{patrolId}/resume")
    public ResponseEntity<ApiResponse<PatrolDto>> resumePatrol(@PathVariable Long patrolId) {
        PatrolDto dto = patrolService.resumePatrol(patrolId);
        return ResponseEntity.ok(ApiResponse.success(dto, "Patrol resumed", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Log Checkpoint")
    @PostMapping("/{patrolId}/log")
    public ResponseEntity<ApiResponse<PatrolDto>> logCheckpoint(
            @PathVariable Long patrolId,
            @RequestParam Long qrPointId,
            @RequestParam(required = false) String comments,
            @RequestParam(required = false) String photoUrl,
            @RequestParam(required = false) java.math.BigDecimal latitude,
            @RequestParam(required = false) java.math.BigDecimal longitude) {
        PatrolDto dto = patrolService.logCheckpoint(patrolId, qrPointId, comments, photoUrl, latitude, longitude);
        return ResponseEntity.ok(ApiResponse.success(dto, "Checkpoint logged", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "End Patrol")
    @PostMapping("/{patrolId}/end")
    public ResponseEntity<ApiResponse<PatrolDto>> endPatrol(@PathVariable Long patrolId) {
        PatrolDto dto = patrolService.endPatrol(patrolId);
        return ResponseEntity.ok(ApiResponse.success(dto, "Patrol ended", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Sync Offline Patrols")
    @PostMapping("/sync")
    public ResponseEntity<ApiResponse<List<PatrolDto>>> syncPatrols(@RequestBody List<PatrolDto> offlinePatrols) {
        List<PatrolDto> dtos = patrolService.syncPatrols(offlinePatrols);
        return ResponseEntity.ok(ApiResponse.success(dtos, "Patrols synced", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Get All Patrols")
    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<PatrolDto>>> getAllPatrols() {
        List<PatrolDto> dtos = patrolService.getAllPatrols();
        return ResponseEntity.ok(ApiResponse.success(dtos, "All patrols fetched", null, HttpStatus.OK.value()));
    }
}
