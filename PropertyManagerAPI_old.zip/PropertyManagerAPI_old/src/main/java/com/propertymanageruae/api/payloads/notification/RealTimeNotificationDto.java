package com.propertymanageruae.api.payloads.notification;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RealTimeNotificationDto {
    private Long id;
    private String type; // COMPLAINT_STATUS_CHANGE, NEW_COMPLAINT, NEW_COMMENT, etc.
    private String title;
    private String message;
    private Object payload; // Flexible data
    private Long userId;
    private Long societyId;
    private LocalDateTime timestamp;
    private boolean read;

    public static RealTimeNotificationDto create(String type, String title,
                                                 String message, Object payload,
                                                 Long userId, Long societyId) {
        RealTimeNotificationDto dto = new RealTimeNotificationDto();
        dto.setType(type);
        dto.setTitle(title);
        dto.setMessage(message);
        dto.setPayload(payload);
        dto.setUserId(userId);
        dto.setSocietyId(societyId);
        dto.setTimestamp(LocalDateTime.now());
        dto.setRead(false);
        return dto;
    }
}