package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Table(name = "visitor_drafts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VisitorDraft {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "guard_id", nullable = false)
    private User guard;

    @Column(name = "name")
    private String name;

    @Column(name = "emirates_id")
    private String emiratesId;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "visit_purpose")
    private String visitPurpose;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "apartment_id")
    private Apartment apartment;

    @Column(name = "photo_url", length = 500)
    private String photoUrl;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (expiresAt == null) {
            // Default expiration: 24 hours from creation
            expiresAt = LocalDateTime.now().plusHours(24);
        }
    }
}
