package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "assignmentRule")
public class AssignmentRule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoryId", nullable = false)
    private Category category;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subCategoryId", nullable = false)
    private SubCategory subCategory;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    @OneToMany(fetch = FetchType.EAGER, mappedBy = "assignmentRule", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private List<AssignmentSlot> assignmentSlots = new ArrayList<>();
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "societyId", nullable = false)
    @JsonBackReference
    private Society society;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;
    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}