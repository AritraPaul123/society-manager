package com.propertymanageruae.api.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UnitHelper {
    @Autowired
    public FileHandler fileHandler;
    @Autowired
    public TableHandler tableHandler;
    @Autowired
    public AppHelper appHelper;
    @Autowired
    public S3FileHandler s3FileHandler;
}