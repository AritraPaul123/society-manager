package com.propertymanageruae.api.payloads.analytics;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GuardPerformanceDto {
    private Long id;
    private Long guardId;
    private String guardName;
    private LocalDate date;
    private Integer patrolsAssigned;
    private Integer patrolsCompleted;
    private Integer patrolsMissed;
    private Integer incidentsReported;
    private Integer visitorsProcessed;
    private String attendanceStatus;
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private BigDecimal totalDutyHours;
    private BigDecimal performanceScore;
}
