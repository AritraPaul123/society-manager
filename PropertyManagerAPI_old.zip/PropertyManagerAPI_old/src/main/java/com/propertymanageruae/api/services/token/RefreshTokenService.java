package com.propertymanageruae.api.services.token;

import com.propertymanageruae.api.entities.RefreshToken;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.user.JwtAuthRequest;
import com.propertymanageruae.api.repositories.IRefreshTokenRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class RefreshTokenService implements IRefreshTokenService {
    private static final Logger logger = LoggerFactory.getLogger(RefreshTokenService.class);
    public long refreshTokenValidity = 30L * 24 * 60 * 60 * 1000;//30days
    @Autowired
    private IRefreshTokenRepository refreshTokenRepository;
    @Autowired
    private IUserRepository userRepository;

    @Override
    @Transactional
    public RefreshToken createRefreshToken(String userName) {
        User user = this.userRepository.findByEmail(userName).get();
        RefreshToken rT = user.getRefreshToken();
        if (rT == null) {
            rT = RefreshToken.builder()
                    .token(UUID.randomUUID().toString())
                    .expiryDate(Instant.now().plusMillis(refreshTokenValidity))
                    .user(user)
                    .build();
        } else {
            rT.setExpiryDate(Instant.now().plusMillis(refreshTokenValidity));
        }
        user.setRefreshToken(rT);
        this.refreshTokenRepository.save(rT);
        return rT;
    }

    @Override
    public RefreshToken verifyRefreshToken(String refreshToken) {
        RefreshToken refreshTokenOb = this.refreshTokenRepository.findByToken(refreshToken)
                .orElseThrow(() -> new ResourceNotFoundException("Token does no exits!"));
        if (refreshTokenOb.getExpiryDate().compareTo(Instant.now()) < 0) {
            this.refreshTokenRepository.delete(refreshTokenOb);
            throw new RuntimeException("Refresh token was expired. Please make a new sign in request");
        }
        return refreshTokenOb;
    }

    @Override
    @Transactional
    public void revokeRefreshTokens(JwtAuthRequest request) {
        User u = this.userRepository.findByEmail(request.getUsername()).orElseThrow(() -> new ResourceNotFoundException("User Not found!"));
        refreshTokenRepository.deleteByToken(u.getRefreshToken().getToken());
    }

}