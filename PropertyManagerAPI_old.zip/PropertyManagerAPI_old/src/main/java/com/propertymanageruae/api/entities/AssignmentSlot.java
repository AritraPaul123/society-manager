package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "assignmentSlot")
public class AssignmentSlot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "start_time", nullable = false)
    private String startTime;
    @Column(name = "end_time", nullable = false)
    private String endTime;
    @Column(name = "day", nullable = false)
    private String day;
    @Column(name = "duration", nullable = false)
    private String duration;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignment_type_id", nullable = false)
    private AssignmentType assignmentType;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignment_rule_id", nullable = false)
    @JsonBackReference
    private AssignmentRule assignmentRule;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}