package com.propertymanageruae.api.payloads.ExternalDTO;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "google")
public class GmailProperties {
    private String clientId;
    private String clientSecret;
    private String refreshToken;
    private String fromEmail;
}