package com.propertymanageruae.api.enums;

public enum NotificationType {
    COMPLAINT_ASSIGNED,
    COMPLAINT_STATUS_CHANGED,
    GENERAL
}