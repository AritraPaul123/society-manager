package com.propertymanageruae.api.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.servers.Server;

@OpenAPIDefinition(
        info = @Info(
                contact = @Contact(
                        name = "Property Manager",
                        email = "noreply@propertymanageruae.com",
                        url = "https://propertymanageruae.com/"
                ),
                description = "A Spring Boot API for Property Manager, providing robust backend services for community management,\n" +
                        "including property, payments, communication, and other essential features to enhance the living experience for\n" +
                        "residents.",
                title = "Property Manager API",
                version = "1.0",
                license = @License(
                        name = "Licence name",
                        url = "https://some-url.com"
                ),
                termsOfService = "Terms of service"
        ),
        servers = {
                @Server(
                        description = "DEV ENV",
                        url = "http://localhost:5001"
                ),
                @Server(
                        description = "PROD ENV",
                        url = "https://api.propertymanageruae.com"
                )
        }
//        security = {
//                @SecurityRequirement(
//                        name = "auth"
//                )
//        }
)
@SecurityScheme(
        name = "auth",
        description = "Put the JWT token in the header as 'Authorization",
        scheme = "bearer",
        type = SecuritySchemeType.HTTP,
        bearerFormat = "JWT",
        in = SecuritySchemeIn.HEADER
)
public class OpenApiConfig {
}