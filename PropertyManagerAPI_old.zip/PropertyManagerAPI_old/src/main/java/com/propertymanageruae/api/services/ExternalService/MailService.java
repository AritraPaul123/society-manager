package com.propertymanageruae.api.services.ExternalService;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.propertymanageruae.api.entities.MailLog;
import com.propertymanageruae.api.exceptions.AuthException;
import com.propertymanageruae.api.payloads.ExternalDTO.MailDto;
import com.propertymanageruae.api.payloads.ExternalDTO.WelcomeEmailDto;
import com.propertymanageruae.api.payloads.utils.BulkEmailResponse;
import com.propertymanageruae.api.repositories.ExternalRepository.IMailLogRepository;
import com.propertymanageruae.api.services.logger.ILoggerService;
import com.propertymanageruae.api.services.logger.LoggerService;
import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.util.ByteArrayDataSource;
import org.eclipse.angus.mail.smtp.SMTPTransport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class MailService implements IMailService {

    @Autowired
    private SpringTemplateEngine templateEngine;
    @Autowired
    private ILoggerService loggerService;
    @Autowired
    private IMailLogRepository mailLogRepository;

    @Autowired
    private JavaMailSender mailSender;

    @Value("${email.gateway}")
    private String mailGateway;

    @Value("${email.gmail.from-email}")
    private String gmailFromEmail;

    @Value("${email.gmail.app-key}")
    private String gmailAppKey;

    @Value("${email.sparkpost.email}")
    private String sparkpostEmail;

    @Value("${email.sparkpost.key}")
    private String sparkpostKey;

    @Value("${email.sendgrid.api-key}")
    private String sendGridApiKey;

    private static final int BATCH_SIZE = 20; // Set batch size (e.g., 20 emails at a time)

    @Async
    @Retryable(value = MailSendException.class,        // Retry only on MailSendException
            maxAttempts = 3,                        // Max retry attempts
            backoff = @Backoff(delay = 2000)        // Delay between retries (in milliseconds)
    )
    @Override
    public CompletableFuture<Boolean> sendMail(MailDto mailModel) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setTo(mailModel.getTo().toArray(new String[0]));
            if (mailModel.getCc() != null) {
                helper.setCc(mailModel.getCc().stream().map(String::trim).filter(this::isValidEmail).toArray(String[]::new));
            }
            if (mailModel.getBcc() != null) {
                helper.setBcc(mailModel.getBcc().stream().map(String::trim).filter(this::isValidEmail).toArray(String[]::new));
            }
            helper.setSubject(mailModel.getSubject());
            helper.setText(mailModel.getBody(), true);
            if (mailModel.getAttachments() != null) {
                for (MailDto.Attachment attachment : mailModel.getAttachments()) {
                    helper.addAttachment(attachment.getName(), new ByteArrayDataSource(attachment.getData(), attachment.getType()));
                }
            }
            mailSender.send(message);
            logMailStatus(mailModel.getTo(), "true", null, mailModel.getPurpose());
            return CompletableFuture.completedFuture(true);
        } catch (Exception e) {
            logMailStatus(mailModel.getTo(), "false", e.getMessage(), mailModel.getPurpose());
            return CompletableFuture.completedFuture(false);
        }
    }

    private void logMailStatus(List<String> recipients, String status, String errorMsg, String purpose) {
        LocalDateTime currentDateTime =  LocalDateTime.now(ZoneId.of("UTC"));
        for (String recipient : recipients) {
            MailLog mailLog = new MailLog();
            mailLog.setMailFrom(gmailFromEmail);
            mailLog.setMailDate(currentDateTime);
            mailLog.setMailTo(recipient);
            mailLog.setStatus(status);
            mailLog.setErrorMsg(errorMsg);
            mailLog.setPurpose(purpose);
            mailLog.setSmtp(mailGateway);
            mailLogRepository.save(mailLog);
        }
    }

    private void logMailStatusOne(String recipient, String status, String errorMsg, String purpose){
        LocalDateTime currentDateTime =  LocalDateTime.now(ZoneId.of("UTC"));
        MailLog mailLog = new MailLog();
        mailLog.setMailFrom(gmailFromEmail);
        mailLog.setMailDate(currentDateTime);
        mailLog.setMailTo(recipient);
        mailLog.setStatus(status);
        mailLog.setErrorMsg(errorMsg);
        mailLog.setPurpose(purpose);
        mailLog.setSmtp(mailGateway);
        mailLogRepository.save(mailLog);
    }

    private boolean isValidEmail(String email) {
        try {
            InternetAddress internetAddress = new InternetAddress(email);
            internetAddress.validate();
            return true;
        } catch (AddressException e) {
            return false;
        }
    }

    @Async
    @Override
    public CompletableFuture<Boolean> sendEmail(MailDto request) {
        try {
            switch (mailGateway) {
                case "Gmail":
                    sendFromGmail(request);
                    break;
                case "SparkPost":
                    sendFromSparkPost(request);
                    break;
                default:
                    throw new IllegalArgumentException("Unsupported email gateway");
            }
            return CompletableFuture.completedFuture(true);
        } catch (Exception e) {
            return CompletableFuture.completedFuture(false);
        }
    }

    private void sendFromGmail(MailDto sendEmailModel) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setFrom(gmailFromEmail);
        helper.setTo(sendEmailModel.getTo().toArray(new String[0]));
        helper.setSubject(sendEmailModel.getSubject());
        helper.setText(sendEmailModel.getBody(), true);
        if (sendEmailModel.getAttachments() != null) {
            for (MailDto.Attachment attachment : sendEmailModel.getAttachments()) {
                helper.addAttachment(attachment.getName(), new ByteArrayResource(attachment.getData()));
            }
        }
        mailSender.send(message);
    }

    private void sendFromSparkPost(MailDto sendEmailModel) {
        // SparkPost client setup and sending logic
        // Similar to your .NET implementation
    }

    private void sendFromSendGrid(MailDto sendEmailModel) throws IOException, IOException {
        Email from = new Email(gmailFromEmail);
        String subject = sendEmailModel.getSubject();
        Email to = new Email(sendEmailModel.getTo().get(0));
        Content content = new Content("text/html", sendEmailModel.getBody());
        Mail mail = new Mail(from, subject, to, content);
        SendGrid sg = new SendGrid(sendGridApiKey);
        Request request = new Request();
        request.setMethod(Method.POST);
        request.setEndpoint("mail/send");
        request.setBody(mail.build());
        sg.api(request);
    }

    @Override
    public CompletableFuture<Boolean> sendWelcomeEmail(WelcomeEmailDto welcomeEmail) {
        String body = String.format("Welcome %s %s! Your username is %s.", welcomeEmail.getMemberFirstName(), welcomeEmail.getMemberLastName(), welcomeEmail.getUsername());
        MailDto email = new MailDto();
        email.setTo(List.of(welcomeEmail.getToEmail()));
        email.setSubject("Welcome to our service!");
        email.setBody(body);
        return sendEmail(email);
    }


    @Async
    public void sendBulkEmail(List<String> recipients, String name,String description, List<MultipartFile> files) {
        for (int i = 0; i < recipients.size(); i += BATCH_SIZE) {
            List<String> batch = recipients.subList(i, Math.min(i + BATCH_SIZE, recipients.size()));
            sendEmailBatch(batch, name,description, files);
        }
    }


    private void sendEmailBatch(List<String> batch,  String name,String description, List<MultipartFile> files) {
        BulkEmailResponse response = new BulkEmailResponse();
        batch.forEach(recipient -> {
            try {
                sendEmailWithAttachment(recipient, name,description, files);
                logMailStatusOne(recipient, "true", null,"NOTICEBOARD");
                response.getSuccessEmails().add(recipient);
            } catch (MessagingException | IOException e) {
                logMailStatusOne(recipient, "false", e.getMessage(),"NOTICEBOARD");
                response.getFailedEmails().add(recipient);
                loggerService.logError("Failed to send email to " + recipient + ": " + e.getMessage());
            }
        });
    }

    @Retryable(value = MessagingException.class, maxAttempts = 3, backoff = @Backoff(delay = 5000))
    private void sendEmailWithAttachment(String recipient, String name, String description, List<MultipartFile> files)
            throws MessagingException, IOException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setFrom(gmailFromEmail);
        helper.setTo(recipient);
        helper.setSubject(name);
        helper.setText(description, true);
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (file != null && !file.isEmpty()) {
                    helper.addAttachment(Objects.requireNonNull(file.getOriginalFilename()), file);
                }
            }
        }
        mailSender.send(message);
    }


    @Recover
    private void recoverFromEmailFailure(MessagingException e, String recipient, String name, MultipartFile file) {
        loggerService.logError("Failed to send email to " + recipient + " after multiple retries: " + e.getMessage());
        logMailStatusOne(recipient, "false", e.getMessage(),"NOTICEBOARD");
    }
}