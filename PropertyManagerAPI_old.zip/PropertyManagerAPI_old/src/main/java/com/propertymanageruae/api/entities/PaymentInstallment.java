package com.propertymanageruae.api.entities;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "payment_installments")
public class PaymentInstallment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long installmentId;

    private Integer installmentNo;

    @Column(precision = 12, scale = 2)
    private BigDecimal installmentAmount;

    @Column(name = "scheduled_date")
    private LocalDate installmentDate; // scheduled date

    private LocalDate paymentDate; // actual payment date when fully paid

    @Column(precision = 12, scale = 2)
    private BigDecimal amountPaid = BigDecimal.ZERO; // accumulates as transactions are added

    /**
     * status can be: pending, partial, paid, overdue, on_time
     */
    @Column(length = 20)
    private String status = "pending";

    // moved here from Payment: payment mode, bank, cheque, and purpose of manual payment
    @Column(name = "payment_mode")
    private String paymentMode;

    // @Column(name = "bank_name")
    // private String bankName;

    private String transRef;

    // // human-readable purpose/note for manual payments made for this installment
    // @Column(name = "payment_purpose", length = 500)
    // private String paymentPurpose;

    private String remarks;

    // NEW fields from React form (also stored at transaction level)
    @Column(name = "issuer_bank")
    private String issuerBank;

    @Column(name = "issuer_account_number")
    private String issuerAccountNumber;

    @Column(name = "deposited_bank")
    private String depositedBank;

    @Column(name = "depositor_account_number")
    private String depositorAccountNumber;

    @Column(name = "payment_type")
    private String type; // e.g., "rent", "security_deposit", etc.

    @ManyToOne
    @JoinColumn(name = "payment_id")
    @JsonIgnoreProperties({ "paymentInstallments", "manualTransactions" })
    private Payment payment;

    @OneToMany(mappedBy = "installment", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("installment")
    private List<PaymentTransaction> transactions = new ArrayList<>();
}
