package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "otp_master")
public class OtpMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name = "member_id", nullable = false)
    private String memberId;
    @Column(name = "user_id", nullable = false)
    private long userId;
    @Column(name = "otp", length = 6, nullable = false)
    private String otp;
    @Column(name = "status", nullable = false, columnDefinition = "BOOLEAN DEFAULT false")
    private boolean status;
    @Column(name = "otp_identifier", unique = true)
    private String otpIdentifier;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @Column(name = "expire_at", nullable = false)
    private Timestamp expireAt;
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @PrePersist
    protected void onCreate() {
        this.expireAt = Timestamp.valueOf(LocalDateTime.now().plusMinutes(5));
    }

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}