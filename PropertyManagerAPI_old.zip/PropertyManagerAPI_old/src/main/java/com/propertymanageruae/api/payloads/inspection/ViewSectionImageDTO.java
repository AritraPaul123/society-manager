package com.propertymanageruae.api.payloads.inspection;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ViewSectionImageDTO {
    private long id;
    private String description;
    private double amount;
    private String fileName;
    private String awsUrl;
    private Long imageSize;
    private String imageType;
    private String imageUrl;
}

