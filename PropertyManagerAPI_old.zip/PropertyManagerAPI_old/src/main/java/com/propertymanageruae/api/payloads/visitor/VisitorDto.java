package com.propertymanageruae.api.payloads.visitor;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class VisitorDto {
    private Long id;
    private String name;
    private String mobileNumber;
    private String visitPurpose;
    private Long apartmentId;
    private String apartmentNumber; // Helper for UI
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private String status;
    private String gateNumber;
    private String photoUrl;
    private String emiratesId;
    private String companyName;
    private Boolean isRepeatVisitor;
    private LocalDateTime lastVisitDate;
    private Integer visitCount;
    private Long guardId;
    private String guardName;
}
