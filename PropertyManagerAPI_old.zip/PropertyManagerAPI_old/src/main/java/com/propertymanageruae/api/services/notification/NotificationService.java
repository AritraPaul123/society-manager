package com.propertymanageruae.api.services.notification;

import com.google.firebase.messaging.*;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.enums.NotificationType;
import com.propertymanageruae.api.events.NotificationCreatedEvent;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.notification.ComplaintStatusChangePayload;
import com.propertymanageruae.api.payloads.notification.NotificationDto;
import com.propertymanageruae.api.payloads.notification.RealTimeNotificationDto;
import com.propertymanageruae.api.repositories.INotificationRepository;
import com.propertymanageruae.api.repositories.IUserDeviceRepository;
import com.propertymanageruae.api.services.utils.RealTimeNotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class NotificationService implements INotificationService {
    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);
    private final IUserDeviceRepository userDeviceRepository;
    private final RealTimeNotificationService realTimeNotificationService;
    private final INotificationRepository notificationRepository;
    private final ApplicationEventPublisher eventPublisher;

    public NotificationService(INotificationRepository notificationRepository,
                               ApplicationEventPublisher eventPublisher,
                               IUserDeviceRepository userDeviceRepository,
                               RealTimeNotificationService realTimeNotificationService
    ) {
        this.notificationRepository = notificationRepository;
        this.eventPublisher = eventPublisher;
        this.userDeviceRepository = userDeviceRepository;
        this.realTimeNotificationService = realTimeNotificationService;
    }

    // ---------------------- SINGLE USER NOTIFICATION ----------------------

    @Async
    @Override
    public void sendNotificationToUser(User user, String title, String body) throws FirebaseMessagingException {
        sendNotificationToUser(user, title, body, null);
    }

    @Async
    private void sendNotificationToUser(User user, String title, String body, Map<String, String> data)
            throws FirebaseMessagingException {

        // Send real-time notification via WebSocket
        RealTimeNotificationDto realtimeNotif = RealTimeNotificationDto.create(
                "GENERAL",
                title,
                body,
                data,
                user.getId(),
                null
        );
        realTimeNotificationService.sendToUser(String.valueOf(user.getId()), realtimeNotif);

        // Send push notification via FCM
        List<String> fcmTokens = userDeviceRepository.findActiveTokensByUserId(user.getId());

        if (fcmTokens == null || fcmTokens.isEmpty()) {
            logger.info("No active FCM tokens found for user: {}", user.getId());
            return;
        }

        sendInBatches(fcmTokens, title, body, data, "UserID: " + user.getId());
    }


    // ---------------------- COMPLAINT STATUS CHANGE ----------------------

    @Async
    @Override
    public void notifyComplaintStatusChange(User user, Long complaintId, String oldStatus,
                                            String newStatus, String complaintTitle)
            throws FirebaseMessagingException {

        ComplaintStatusChangePayload payload = new ComplaintStatusChangePayload(
                complaintId, oldStatus, newStatus, complaintTitle
        );

        RealTimeNotificationDto realtimeNotif = RealTimeNotificationDto.create(
                "COMPLAINT_STATUS_CHANGE",
                "Complaint Status Updated",
                String.format("Your complaint #%d has been marked as %s", complaintId, newStatus),
                payload,
                user.getId(),
                null
        );

        realTimeNotificationService.sendToUser(String.valueOf(user.getId()), realtimeNotif);

        // Also send push notification
        Map<String, String> data = new HashMap<>();
        data.put("type", "COMPLAINT_STATUS_CHANGE");
        data.put("complaintId", complaintId.toString());
        data.put("newStatus", newStatus);

        sendNotificationToUser(user, "Complaint Status Updated",
                String.format("Your complaint #%d has been marked as %s", complaintId, newStatus), data);
    }

    // ---------------------- MULTIPLE USERS NOTIFICATION ----------------------

    /**
     * Sends notification to multiple users efficiently.
     * This method will:
     * - Collect all active tokens from all users
     * - Send in batches of 500
     * - Mark invalid tokens inactive
     */
    @Async
    @Override
    public void sendNotificationToUsers(List<User> users, String title, String body)
            throws FirebaseMessagingException {
        sendNotificationToUsers(users, title, body, null);
    }

    @Async
    private void sendNotificationToUsers(List<User> users, String title, String body, Map<String, String> data)
            throws FirebaseMessagingException {

        if (users == null || users.isEmpty()) {
            logger.info("User list is empty. No notifications sent.");
            return;
        }

        List<String> allTokens = new ArrayList<>();

        for (User user : users) {
            // Send real-time notification to each user
            RealTimeNotificationDto realtimeNotif = RealTimeNotificationDto.create(
                    "GENERAL",
                    title,
                    body,
                    data,
                    user.getId(),
                    null
            );
            realTimeNotificationService.sendToUser(String.valueOf(user.getId()), realtimeNotif);

            // Collect FCM tokens
            List<String> userTokens = userDeviceRepository.findActiveTokensByUserId(user.getId());
            if (userTokens != null && !userTokens.isEmpty()) {
                allTokens.addAll(userTokens);
            } else {
                logger.info("No active FCM tokens found for userId: {}", user.getId());
            }
        }

        if (allTokens.isEmpty()) {
            logger.info("No active FCM tokens found for any of the provided users.");
            return;
        }

        sendInBatches(allTokens, title, body, data, "Multiple Users");
    }
    // ---------------------- COMMON PRIVATE METHODS ----------------------

    /**
     * Handles sending messages in 500-token batches
     */
    private void sendInBatches(List<String> tokens, String title, String body,
                               Map<String, String> data, String contextInfo)
            throws FirebaseMessagingException {

        int batchSize = 500;
        for (int i = 0; i < tokens.size(); i += batchSize) {
            List<String> batchTokens = tokens.subList(i, Math.min(i + batchSize, tokens.size()));

            MulticastMessage.Builder messageBuilder = MulticastMessage.builder()
                    .addAllTokens(batchTokens)
                    .setNotification(Notification.builder()
                            .setTitle(title)
                            .setBody(body)
                            .build());

            if (data != null && !data.isEmpty()) {
                messageBuilder.putAllData(data);
            }

            MulticastMessage message = messageBuilder.build();
            BatchResponse response = FirebaseMessaging.getInstance().sendEachForMulticast(message);

            logger.info("Notification batch sent ({}) → Success: {}, Failure: {}",
                    contextInfo, response.getSuccessCount(), response.getFailureCount());

            List<SendResponse> responses = response.getResponses();
            for (int j = 0; j < responses.size(); j++) {
                SendResponse sendResponse = responses.get(j);
                if (!sendResponse.isSuccessful()) {
                    String failedToken = batchTokens.get(j);
                    markTokenAsInactive(failedToken);
                    logger.warn("Failed to send notification ({}): Token: {} | Reason: {}",
                            contextInfo, failedToken, sendResponse.getException().getMessage());
                }
            }
        }
    }

    private void markTokenAsInactive(String token) {
        userDeviceRepository.findByFcmToken(token).ifPresent(device -> {
            device.setActive(false);
            userDeviceRepository.save(device);
            logger.info("Marked FCM token as inactive: {}", token);
        });
    }

    @Override
    public List<com.propertymanageruae.api.entities.Notification> getMyNotifications(Long userId){
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    @Override
    @Transactional
    public void markAllRead(Long userId){
        List<com.propertymanageruae.api.entities.Notification> list = notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
        list.forEach(n -> n.setSeen(true));
        notificationRepository.saveAll(list);
    }
    @Override
    @Transactional
    public void markRead(Long notificationId, Long userId) {
        var notification = notificationRepository
                .findByIdAndUserId(notificationId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        notification.setSeen(true);
        notificationRepository.save(notification);
    }


    @Override
    @Transactional
    public NotificationDto createAndPublish(Long userId, String title, String message, NotificationType type) {
        var n = new com.propertymanageruae.api.entities.Notification();
        n.setUserId(userId);
        n.setTitle(title);
        n.setMessage(message);
        n.setType(type);
        n.setSeen(false);
        n.setCreatedAt(LocalDateTime.now());
        var saved = this.notificationRepository.save(n);
        NotificationDto dto = new NotificationDto(
                saved.getId(),
                saved.getUserId(),
                saved.getTitle(),
                saved.getMessage(),
                saved.getType(),
                saved.isSeen(),
                saved.getCreatedAt()
        );
        // Publish an application event (we will handle sending after commit)
        eventPublisher.publishEvent(new com.propertymanageruae.api.events.NotificationCreatedEvent(dto));
        return dto;
    }

    @Transactional
    @Override
    public List<NotificationDto> createAndPublishToUsers(
            List<Long> userIds,
            String title,
            String message,
            NotificationType type
    ) {
        List<com.propertymanageruae.api.entities.Notification> entities = new ArrayList<>();

        for (Long userId : userIds) {
            var n = new com.propertymanageruae.api.entities.Notification();
            n.setUserId(userId);
            n.setTitle(title);
            n.setMessage(message);
            n.setType(type);
            n.setSeen(false);
            n.setCreatedAt(LocalDateTime.now());
            entities.add(n);
        }

        // 🔥 Save all notifications in one batch (faster + production grade)
        var savedList = notificationRepository.saveAll(entities);

        // Convert to DTOs
        List<NotificationDto> dtoList = savedList.stream()
                .map(saved -> new NotificationDto(
                        saved.getId(),
                        saved.getUserId(),
                        saved.getTitle(),
                        saved.getMessage(),
                        saved.getType(),
                        saved.isSeen(),
                        saved.getCreatedAt()
                ))
                .toList();

        // 🔥 Now publish events for each saved notification
        dtoList.forEach(dto ->
                eventPublisher.publishEvent(new NotificationCreatedEvent(dto))
        );

        return dtoList;
    }

}