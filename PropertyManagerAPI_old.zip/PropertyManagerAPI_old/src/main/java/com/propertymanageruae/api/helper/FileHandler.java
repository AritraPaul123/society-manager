package com.propertymanageruae.api.helper;


import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Objects;
import java.util.UUID;

@Component
public class FileHandler {

//    private final Path fileStorageLocation;
//    @Value("${file.upload-dir}")
//    private String UPLOAD_DIR;
//    @Value("${file.max-size:50MB}")
//    private String maxFileSize;
//
//    @Value("${file.allowed-types:image/jpeg,image/png}")
//    private String allowedTypes;
//
//    public FileHandler(@Value("${file.upload-dir}") String uploadDir) throws IOException {
//        this.fileStorageLocation = Paths.get(uploadDir).toAbsolutePath().normalize();
//        if (!Files.exists(this.fileStorageLocation)) {
//            Files.createDirectories(this.fileStorageLocation);
//        }
//    }
//
//    public void validateFile(MultipartFile file) {
//        long fileSizeLimit = parseSize(maxFileSize); // Convert maxFileSize to bytes
//        if (file.getSize() > fileSizeLimit) {
//            throw new IllegalArgumentException("File size exceeds the limit of " + maxFileSize);
//        }
//        String contentType = file.getContentType();
//        String[] allowedContentTypes = allowedTypes.split(",");
//        boolean isValidType = false;
//
//        for (String allowedType : allowedContentTypes) {
//            if (allowedType.equals(contentType)) {
//                isValidType = true;
//                break;
//            }
//        }
//        if (!isValidType) {
//            throw new IllegalArgumentException("Invalid file type. Allowed types are: " + allowedTypes);
//        }
//    }
//
//    private long parseSize(String size) {
//        if (size.endsWith("MB")) {
//            return Long.parseLong(size.replace("MB", "")) * 1024 * 1024;
//        } else if (size.endsWith("KB")) {
//            return Long.parseLong(size.replace("KB", "")) * 1024;
//        } else if (size.endsWith("B")) {
//            return Long.parseLong(size.replace("B", ""));
//        } else {
//            return 0; // Handle invalid cases
//        }
//    }
//
//    public String storeFile(MultipartFile file) throws IOException {
//        String originalFileName = StringUtils.cleanPath(Objects.requireNonNull(file.getOriginalFilename()));
//        if (originalFileName.contains("..")) {
//            throw new SecurityException("Invalid file path: " + originalFileName);
//        }
//        String fileExtension = getFileExtension(originalFileName);
//        String uniqueFileName = UUID.randomUUID().toString() + "." + fileExtension;
//        Path targetLocation = this.fileStorageLocation.resolve(uniqueFileName);
//        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
//        return uniqueFileName;
//    }
//
//    public void deleteFile(String filePath, String fileName) throws IOException {
//        Path fileToDelete = fileStorageLocation.resolve(filePath).normalize();
//        try {
//            Files.delete(fileToDelete);
//        } catch (ResourceNotFoundException ex) {
//            throw new ResourceNotFoundException(filePath, "not exits", "");
//        } catch (IOException ex) {
//            throw new IOException("Could not delete file: " + fileToDelete.toString(), ex);
//        }
//    }
//
//    public InputStream getResource(String fileName) throws IOException {
//        Path filePath = this.fileStorageLocation.resolve(fileName);
//        return Files.newInputStream(filePath);
//    }
//    public Path getFilePath(String fileName) {
//        return this.fileStorageLocation.resolve(fileName).normalize();
//    }
//
//    private String getFileExtension(String fileName) {
//        if (fileName == null) return "";
//        int dotIndex = fileName.lastIndexOf('.');
//        return (dotIndex >= 0) ? fileName.substring(dotIndex + 1) : "";
//    }
}