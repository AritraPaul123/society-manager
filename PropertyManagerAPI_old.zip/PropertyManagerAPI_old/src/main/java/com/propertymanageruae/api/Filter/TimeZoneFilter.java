package com.propertymanageruae.api.Filter;

import com.propertymanageruae.api.config.TimeZoneContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.ZoneId;

@Component
public class TimeZoneFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String timeZone = request.getHeader("X-Timezone");
        if (timeZone == null || timeZone.isBlank()) {
            timeZone = "UTC";
        } else {
            try {
                ZoneId.of(timeZone); // validate
            } catch (Exception e) {
                timeZone = "UTC";
            }
        }

        try {
            TimeZoneContext.setTimeZone(timeZone);
            filterChain.doFilter(request, response);
        } finally {
            TimeZoneContext.clear(); // Always clean up
        }
    }
}