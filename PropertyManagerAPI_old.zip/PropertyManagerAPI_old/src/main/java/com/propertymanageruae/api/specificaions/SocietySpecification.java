package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.entities.Resident;
import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.enums.SocietyType;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import org.springframework.data.jpa.domain.Specification;



public class SocietySpecification {
    public static Specification<Society> leftJoinResidentsWithUMemberIdAndSocietyType(String memberId, SocietyType societyType) {
        return (root, query, criteriaBuilder) -> {
            Join<Society, Resident> userJoin = root.join("resident", JoinType.LEFT);
            var userIdCondition = criteriaBuilder.equal(userJoin.get("user").get("memberId"), memberId);
            var societyTypeCondition = criteriaBuilder.equal(root.get("societyType"), societyType);
            return criteriaBuilder.and(userIdCondition, societyTypeCondition);
        };
    }
    public static Specification<Society> leftJoinUsersWithUserIdAndSocietyType(String userId, SocietyType societyType) {
        return (root, query, criteriaBuilder) -> {
            Join<Society, User> userJoin = root.join("user", JoinType.LEFT);
            var userIdCondition = criteriaBuilder.equal(userJoin.get("id"), userId);
            var societyTypeCondition = criteriaBuilder.equal(root.get("societyType"), societyType);
            return criteriaBuilder.and(userIdCondition, societyTypeCondition);
        };
    }


}