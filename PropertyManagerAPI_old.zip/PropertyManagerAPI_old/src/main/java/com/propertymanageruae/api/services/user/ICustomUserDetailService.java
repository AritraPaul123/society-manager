package com.propertymanageruae.api.services.user;

import com.propertymanageruae.api.entities.User;
import org.springframework.security.core.userdetails.UserDetails;

public interface ICustomUserDetailService {
    User LoggedInUser();
}