package com.propertymanageruae.api.payloads.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import com.propertymanageruae.api.payloads.utils.SocietyRoleDto;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
public class UserDTO {

    private int id;

    @NotEmpty(message = "Name must not be empty")
    private String name;

    @NotEmpty(message = "Email must not be empty")
    @Email
    private String email;

    @NotEmpty(message = "Phone Number must not be empty")
    private String contactNumber;

    @NotEmpty(message = "Password must not be empty")
    @jakarta.validation.constraints.Size(min = 6, message = "Password size minimum 6 characters")
    private String password;
    private boolean status;
//    private Set<RoleDTO> roles = new HashSet<>();
    private long societyId;
    private long roleId;
    private List<SocietyRoleDto> societyRoles;

    @JsonIgnore // Prevent password from being exposed in API responses
    public String getPassword() {
        return password;
    }

    @JsonProperty // Allow setting password
    public void setPassword(String password) {
        this.password = password;
    }
}