package com.propertymanageruae.api.services.OTP;

import com.propertymanageruae.api.payloads.OTP.OtpValidateDto;

public interface IOtpService {
    OtpValidateDto generateOtp(String email) throws Exception;
    boolean validateOtp(OtpValidateDto otp);
}