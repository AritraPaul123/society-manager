package com.propertymanageruae.api.services.Society;

import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.enums.SocietyType;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.master.AddSocietyDto;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.repositories.ISocietyRepository;
import org.modelmapper.ModelMapper;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SocietyService implements ISocietyService {

    private final ISocietyRepository repository;
    private final ModelMapper mapper;

    public SocietyService(ISocietyRepository repository, ModelMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Override
    @Transactional
    public String addSociety(AddSocietyDto dto) {

        // Generate unique societyId
        String societyId = generateSocietyCode(dto.getSocietyName());
        int suffix = 0;
        String candidate = societyId;

        while (repository.existsBySocietyId(candidate)) {
            suffix++;
            candidate = societyId + "-" + suffix;
        }

        Society s = new Society();
        s.setSocietyId(candidate);
        s.setSocietyName(dto.getSocietyName());
        s.setSocietyPhone(dto.getSocietyPhone());
        s.setSocietyEmail(dto.getSocietyEmail());
        s.setSocietyType(dto.getSocietyType()); // ENUM
        s.setCity(dto.getCity());
        s.setCountry(dto.getCountry());
        s.setLongitude(dto.getLongitude());
        s.setLatitude(dto.getLatitude());
        s.setDelete(false);

        try {
            repository.save(s);
        } catch (DataIntegrityViolationException ex) {
            throw ex;  // handled globally
        }

        return candidate;
    }

    @Override
    @Transactional(readOnly = true)
    public List<ViewSocietyDto> getAllSocietyForWeb() {
        List<Society> list = repository.findByIsDeleteFalseAndSocietyType(SocietyType.PUBLISH);
        return list.stream().map(this::toViewDto).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public PaginationDto<ViewSocietyDto> getAllSocietyInWebWithPaginate(
            int pageNumber,
            int pageSize,
            String sortBy,
            String sortDir,
            String searchText
    ) {

        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }

        Sort.Direction direction = Sort.Direction.fromString(sortDir);
        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));

        Page<Society> societyPage;

        if (searchText != null && !searchText.trim().isEmpty()) {
            societyPage = repository.searchSociety(searchText.trim(), pageable);
        } else {
            societyPage = repository.findByIsDeleteFalse(pageable);
        }

        List<ViewSocietyDto> content = societyPage.getContent()
                .stream()
                .map(society -> mapper.map(society, ViewSocietyDto.class))
                .toList();

        PaginationDto<ViewSocietyDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(content);
        paginationDto.setPageNumber(societyPage.getNumber());
        paginationDto.setPageSize(societyPage.getSize());
        paginationDto.setTotalPages(societyPage.getTotalPages());
        paginationDto.setTotalElements(societyPage.getTotalElements());
        paginationDto.setLastPage(societyPage.isLast());

        return paginationDto;
    }


    @Override
    @Transactional(readOnly = true)
    public ViewSocietyDto getSocietyById(Long id) {

        Society s = repository.findByIdAndIsDeleteFalseAndSocietyType(id, SocietyType.PUBLISH)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found"));

        return toViewDto(s);
    }

    @Override
    @Transactional
    public ViewSocietyDto updateSociety(Long id, AddSocietyDto dto) {

        Society s = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found"));

        if (s.isDelete()) {
            throw new ResourceNotFoundException("Society not found");
        }

        s.setSocietyName(dto.getSocietyName());
        s.setSocietyPhone(dto.getSocietyPhone());
        s.setSocietyEmail(dto.getSocietyEmail());
        s.setSocietyType(dto.getSocietyType()); // ENUM
        s.setCity(dto.getCity());
        s.setCountry(dto.getCountry());
        s.setLongitude(dto.getLongitude());
        s.setLatitude(dto.getLatitude());

        repository.save(s);
        return toViewDto(s);
    }

    @Override
    @Transactional
    public void deleteSociety(Long id, long deletedBy) {

        Society s = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found"));

        if (s.isDelete()) return;

        s.setDelete(true);
        s.setDeletedAt(LocalDateTime.now());
        s.setDeleteBy(deletedBy);

        repository.save(s);
    }

    @Override
    @Transactional
    public ViewSocietyDto togglePublish(Long id, boolean publish, long modifyBy) {

        Society s = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found"));

        if (s.isDelete()) {
            throw new ResourceNotFoundException("Society not found");
        }

        s.setSocietyType(publish ? SocietyType.PUBLISH : SocietyType.UNPUBLISH);
        s.setModifyBy(modifyBy);

        repository.save(s);

        return toViewDto(s);
    }

    // ---------------------- Helper Methods ----------------------

    private ViewSocietyDto toViewDto(Society s) {
        ViewSocietyDto dto = mapper.map(s, ViewSocietyDto.class);
        dto.setSocietyId(s.getSocietyId());
        return dto;
    }

    private String generateSocietyCode(String name) {
        if (name == null) name = "society";

        String code = name.trim().toLowerCase().replaceAll("[^a-z0-9]+", "-");

        if (code.length() > 40) code = code.substring(0, 40);

        return code + "-" + (System.currentTimeMillis() % 10000);
    }
}