package com.propertymanageruae.api.payloads.assignment;

import com.propertymanageruae.api.payloads.category.CategoryDTO;
import com.propertymanageruae.api.payloads.category.SubCategoryDTO;
import com.propertymanageruae.api.payloads.user.UserDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssignmentRuleDTO {
    private Long id;
    private CategoryDTO category;
    private SubCategoryDTO subCategory;
    private List<AssignmentSlotDTO> assignmentSlots;
    private UserDTO user;
}