package com.propertymanageruae.api.repositories;


import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IUserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {
    Optional<User> findByEmail(String email);
    Optional<User> findByEmailAndIsDeleteNot(String email, boolean isDelete);
    Optional<User> findById(Long id);//override
    User findByMemberId(String memberId);
//    @Query("SELECT u FROM User u JOIN u.userRoleMappings r WHERE r.role.id = :roleId AND u.society.id=:societyId AND u.isDelete=:isDelete AND u.status=:status")
//    List<User> findUsersByRoleIdAndSocietyIdAndIsDeleteAndStatus(@Param("roleId") Long roleId,@Param("societyId") long societyId,@Param("isDelete") boolean isDelete,@Param("status") boolean status);
@Query("SELECT u FROM User u JOIN u.userRoleMappings r WHERE r.role.id = :roleId AND r.society.id = :societyId AND u.isDelete = :isDelete AND u.status = :status")
List<User> findUsersByRoleIdAndSocietyIdAndIsDeleteAndStatus(
        @Param("roleId") Long roleId,
        @Param("societyId") long societyId,
        @Param("isDelete") boolean isDelete,
        @Param("status") boolean status
);
    List<User> findAllByStatus(boolean active);
    @Query("SELECT u FROM User u WHERE " +
            "LOWER(u.name) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
            "LOWER(u.email) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
            "LOWER(u.contactNumber) LIKE LOWER(CONCAT('%', :searchText, '%'))")
    Page<User> findBySearchText(@Param("searchText") String searchText, Pageable pageable);

//    Page<User> findBySocietyIdAndIsDelete(long societyId, boolean isDelete, Pageable pageable);
//    List<User> findBySocietyIdAndIsDelete(long societyId, boolean isDelete);

    @Query("SELECT urm.user FROM UserRoleMapping urm WHERE urm.society.id = :societyId AND urm.isDelete = :isDelete")
    Page<User> findBySocietyIdAndIsDelete(@Param("societyId") long societyId,
                                               @Param("isDelete") boolean isDelete,
                                               Pageable pageable);

    @Query("SELECT urm.user FROM UserRoleMapping urm WHERE urm.society.id = :societyId AND urm.isDelete = :isDelete")
    List<User> findBySocietyIdAndIsDelete(@Param("societyId") long societyId,
                                               @Param("isDelete") boolean isDelete);

//    @Query("SELECT u FROM User u WHERE " +
//            "LOWER(u.name) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
//            "LOWER(u.email) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
//            "LOWER(u.contactNumber) LIKE LOWER(CONCAT('%', :searchText, '%')) AND " +
//            "u.society.id = :societyId AND "+
//            "u.isDelete = false")
//    Page<User> findBySocietyIdAndSearchText(@Param("societyId") long societyId,
//                                                @Param("searchText") String searchText,
//                                                Pageable pageable);


    @Query("""
    SELECT DISTINCT u FROM User u
    JOIN u.userRoleMappings r
    WHERE 
        (LOWER(u.name) LIKE LOWER(CONCAT('%', :searchText, '%')) OR 
         LOWER(u.email) LIKE LOWER(CONCAT('%', :searchText, '%')) OR 
         LOWER(u.contactNumber) LIKE LOWER(CONCAT('%', :searchText, '%')))
      AND r.society.id = :societyId
      AND u.isDelete = false
""")
    Page<User> findBySocietyIdAndSearchText(
            @Param("societyId") long societyId,
            @Param("searchText") String searchText,
            Pageable pageable);



//    @Query("SELECT DISTINCT u FROM User u " +
//            "JOIN u.userRoleMappings r " +
//            "WHERE " +
//            "(LOWER(u.name) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
//            "LOWER(u.email) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
//            "LOWER(u.contactNumber) LIKE LOWER(CONCAT('%', :searchText, '%'))) AND " +
//            "u.society.id = :societyId AND " +
//            "u.isDelete = false AND " +
//            "r.role.id != 6")
//    Page<User> findBySocietyIdAndSearchTextAndRoleNot(
//            @Param("societyId") long societyId,
//            @Param("searchText") String searchText,
//            Pageable pageable);

    @Query("""
    SELECT DISTINCT u FROM User u
    JOIN u.userRoleMappings r
    WHERE 
        (LOWER(u.name) LIKE LOWER(CONCAT('%', :searchText, '%')) OR 
         LOWER(u.email) LIKE LOWER(CONCAT('%', :searchText, '%')) OR 
         LOWER(u.contactNumber) LIKE LOWER(CONCAT('%', :searchText, '%')))
      AND r.society.id = :societyId
      AND u.isDelete = false
      AND r.role.id != 6
""")
    Page<User> findBySocietyIdAndSearchTextAndRoleNot(
            @Param("societyId") long societyId,
            @Param("searchText") String searchText,
            Pageable pageable);




//    @Query("SELECT u FROM User u " +
//            "JOIN u.roles r " +
//            "WHERE u.society.id = :societyId " +
//            "AND u.isDelete = :isDelete " +
//            "AND r.id != 6")
//    Page<User> findBySocietyIdAndIsDeleteAndRoleNot(
//            @Param("societyId") long societyId,
//            @Param("isDelete") boolean isDelete,
//            Pageable pageable);


//    @Query("SELECT DISTINCT u FROM User u " +
//            "JOIN u.userRoleMappings r " +
//            "WHERE " +
//            "(LOWER(u.name) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
//            "LOWER(u.email) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
//            "LOWER(u.contactNumber) LIKE LOWER(CONCAT('%', :searchText, '%'))) AND " +
//            "u.society.id = :societyId AND " +
//            "u.isDelete = false AND " +
//            "u.id != :excludedUserId AND " +
//            "r.role.id NOT IN :excludedRoleIds")
//    Page<User> findBySocietyIdAndSearchTextAndRolesNot(
//            @Param("societyId") long societyId,
//            @Param("searchText") String searchText,
//            @Param("excludedUserId") long excludedUserId,
//            @Param("excludedRoleIds") List<Long> excludedRoleIds,
//            Pageable pageable);
@Query("""
    SELECT DISTINCT u FROM User u
    JOIN u.userRoleMappings r
    WHERE 
        (LOWER(u.name) LIKE LOWER(CONCAT('%', :searchText, '%')) OR 
         LOWER(u.email) LIKE LOWER(CONCAT('%', :searchText, '%')) OR 
         LOWER(u.contactNumber) LIKE LOWER(CONCAT('%', :searchText, '%')))
      AND r.society.id = :societyId
      AND u.isDelete = false
      AND u.id != :excludedUserId
      AND r.role.id NOT IN :excludedRoleIds
""")
Page<User> findBySocietyIdAndSearchTextAndRolesNot(
        @Param("societyId") long societyId,
        @Param("searchText") String searchText,
        @Param("excludedUserId") long excludedUserId,
        @Param("excludedRoleIds") List<Long> excludedRoleIds,
        Pageable pageable);


//    @Query("SELECT u FROM User u " +
//            "JOIN u.userRoleMappings r " +
//            "WHERE u.society.id = :societyId " +
//            "AND u.isDelete = :isDelete " +
//            "AND u.id != :userId " +
//            "AND r.role.id NOT IN (:excludedRoleIds)")
//    Page<User> findBySocietyIdAndIsDeleteAndRolesNot(
//            @Param("societyId") long societyId,
//            @Param("isDelete") boolean isDelete,
//            @Param("userId") long userId,
//            @Param("excludedRoleIds") List<Long> excludedRoleIds,
//            Pageable pageable);


    @Query("""
    SELECT DISTINCT u FROM User u
    JOIN u.userRoleMappings urm
    WHERE urm.society.id = :societyId
      AND u.isDelete = :isDelete
      AND u.id != :userId
      AND urm.role.id NOT IN (:excludedRoleIds)
""")
    Page<User> findBySocietyIdAndIsDeleteAndRolesNot(
            @Param("societyId") long societyId,
            @Param("isDelete") boolean isDelete,
            @Param("userId") long userId,
            @Param("excludedRoleIds") List<Long> excludedRoleIds,
            Pageable pageable);


}