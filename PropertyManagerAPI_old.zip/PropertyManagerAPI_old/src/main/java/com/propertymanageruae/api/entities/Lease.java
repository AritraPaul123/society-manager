package com.propertymanageruae.api.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "id"
)
public class Lease {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;   // ✅ Reverted to Long ID

    private LocalDate startDate;
    private LocalDate endDate;

    // ---------------- Property ----------------
    @ManyToOne
    @JoinColumn(name = "property_id", nullable = false)
    private Property property;

    @ManyToOne
    @JoinColumn(name = "tenant_id", nullable = false)
    private Tenant tenant;

    // ---------------- Payments ----------------
    @OneToMany(mappedBy = "lease", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Payment> payments = new ArrayList<>();

    // // ---------------- Terms & Conditions ----------------
    // @ElementCollection
    // @CollectionTable(
    //     name = "lease_terms",
    //     joinColumns = @JoinColumn(name = "lease_id")
    // )
    // @Column(name = "term")
    // private List<String> termsAndConditions = new ArrayList<>();


    //fix code for termsandconditions new entity.with creating new leaseterm entity creating change in service class and also make leasetermrepo.
    // ---------------- Terms & Conditions ----------------
@OneToMany(mappedBy = "lease", cascade = CascadeType.ALL, orphanRemoval = true)
private List<LeaseTerm> termsAndConditions = new ArrayList<>();


    // ---------------- Lease Status ----------------
    @Enumerated(EnumType.STRING)
    private LeaseStatus status; // OPEN, CLOSED, IN_PROGRESS

    // ---------------- Custom Reference (Optional) ----------------
    @Column(unique = true, updatable = false)
    private String leaseRef;

    @PrePersist
    private void generateLeaseRef() {
        if (this.leaseRef == null || this.leaseRef.isEmpty()) {
            this.leaseRef = "SR" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        }
    }

    // Enum for lease status
    public enum LeaseStatus {
        OPEN,
        CLOSED,
        STEP_1,
        STEP_2
    }

    

   
}







