package com.propertymanageruae.api.payloads.incident;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IncidentDto {
    private Long id;
    private Long patrolId;
    private Long guardId;
    private String guardName;
    private String incidentType;
    private String title;
    private String description;
    private String photoUrl;
    private String location;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private String priority;
    private String status;
    private Long assignedToId;
    private String assignedToName;
    private Long complaintId;
    private Long societyId;
    private LocalDateTime createdAt;
    private LocalDateTime resolvedAt;
}
