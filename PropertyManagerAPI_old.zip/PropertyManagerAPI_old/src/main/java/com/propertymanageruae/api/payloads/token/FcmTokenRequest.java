package com.propertymanageruae.api.payloads.token;

import jakarta.validation.constraints.NotEmpty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FcmTokenRequest {
    private Long userId;
    @NotEmpty(message = "fcm token is required")
    private String fcmToken;
    private String deviceId;
    private String deviceType;
    private String deviceName;
    private String osVersion;
}