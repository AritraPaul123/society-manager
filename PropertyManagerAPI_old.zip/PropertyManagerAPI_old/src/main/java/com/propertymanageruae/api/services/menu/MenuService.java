package com.propertymanageruae.api.services.menu;

import com.propertymanageruae.api.entities.Menu;
import com.propertymanageruae.api.payloads.menu.EditMenuDto;
import com.propertymanageruae.api.repositories.IMenuRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
public class MenuService implements IMenuService {


    private final IMenuRepository menuRepository;

    private final ModelMapper modelMapper;

    @Override
    public List<Menu> getMenus() {
        List<Menu> menus = menuRepository.findAll();
        List<Menu> rootMenus = menus.stream()
                .filter(m -> m.getParentMenu() == null)
                .sorted(Comparator.comparing(Menu::getOrderNo, Comparator.nullsFirst(Integer::compareTo)))
                .collect(Collectors.toList());

        for (Menu menu : rootMenus) {
            buildMenuTree(menu, menus);
        }

        return rootMenus;
    }

    @Override
    public List<Menu> addParentMenu(EditMenuDto menuDto) {
        Integer maxOrderNo = menuRepository.findMaxOrderNoByParentMenuIsNull();
        Menu menu = modelMapper.map(menuDto, Menu.class);
        menu.setOrderNo(maxOrderNo == null ? 0 : maxOrderNo + 1);
        menuRepository.save(menu);
        return getMenus();
    }

    @Override
    public List<Menu> addChildMenu(Long parentId, EditMenuDto menuDto) {
        Menu parent = menuRepository.findById(parentId)
                .orElseThrow(() -> new RuntimeException("Parent menu not found"));
        Integer maxOrderNo = menuRepository.findMaxOrderNoByParentMenuId(parentId);
        Menu menu = modelMapper.map(menuDto, Menu.class);
        menu.setParentMenu(parent);
        menu.setOrderNo(maxOrderNo == null ? 0 : maxOrderNo + 1);
        menuRepository.save(menu);
        return getMenus();
    }

    @Override
    public List<Menu> updateMenu(Long menuId, EditMenuDto dto) {
        Menu menu = menuRepository.findById(menuId)
                .orElseThrow(() -> new RuntimeException("Menu not found"));
        menu.setName(dto.getName());
        menu.setPath(dto.getPath());
        menu.setIcon(dto.getIcon());
        menu.setDescription(dto.getDescription());
        menu.setActive(dto.isActive());
        return getMenus();
    }

    @Override
    public List<Menu> deleteMenu(Long menuId) {
        Menu menu = menuRepository.findById(menuId)
                .orElseThrow(() -> new RuntimeException("Menu not found"));
        List<Menu> menusToDelete = menuRepository.findAllByIdOrParentMenuId(menuId);
        menuRepository.deleteAll(menusToDelete);

        reorderMenus(menu.getParentMenu() == null);

        return getMenus();
    }

    @Override
    public List<Menu> moveMenuOrderUp(Long menuId) {
        Menu menu = menuRepository.findById(menuId)
                .orElseThrow(() -> new RuntimeException("Menu not found"));
        List<Menu> sameLevelMenus = menu.getParentMenu() == null
                ? menuRepository.findByParentMenuIsNullOrderByOrderNoAsc()
                : menuRepository.findByParentMenuOrderByOrderNoAsc(menu.getParentMenu());

        int index = sameLevelMenus.indexOf(menu);
        if (index <= 0) throw new RuntimeException("Menu already at the top");

        Menu previousMenu = sameLevelMenus.get(index - 1);
        int temp = menu.getOrderNo();
        menu.setOrderNo(previousMenu.getOrderNo());
        previousMenu.setOrderNo(temp);

        return getMenus();
    }

    @Override
    public List<Menu> moveMenuOrderDown(Long menuId) {
        Menu menu = menuRepository.findById(menuId)
                .orElseThrow(() -> new RuntimeException("Menu not found"));
        List<Menu> sameLevelMenus = menu.getParentMenu() == null
                ? menuRepository.findByParentMenuIsNullOrderByOrderNoAsc()
                : menuRepository.findByParentMenuOrderByOrderNoAsc(menu.getParentMenu());

        int index = sameLevelMenus.indexOf(menu);
        if (index >= sameLevelMenus.size() - 1) throw new RuntimeException("Menu already at the bottom");

        Menu nextMenu = sameLevelMenus.get(index + 1);
        int temp = menu.getOrderNo();
        menu.setOrderNo(nextMenu.getOrderNo());
        nextMenu.setOrderNo(temp);

        return getMenus();
    }

    // Helper methods
    private void buildMenuTree(Menu parentMenu, List<Menu> menus) {
        List<Menu> children = menus.stream()
                .filter(m -> m.getParentMenu() != null && m.getParentMenu().getId()==parentMenu.getId())
                .sorted(Comparator.comparing(Menu::getOrderNo, Comparator.nullsFirst(Integer::compareTo)))
                .collect(Collectors.toList());

        parentMenu.setChildMenus(children);
        for (Menu child : children) {
            buildMenuTree(child, menus);
        }
    }

    private void reorderMenus(boolean isParentLevel) {
        List<Menu> menus = isParentLevel
                ? menuRepository.findByParentMenuIsNullOrderByOrderNoAsc()
                : menuRepository.findAll(); // optional: child-level reordering
        int order = 0;
        for (Menu m : menus) {
            m.setOrderNo(order++);
        }
    }
}