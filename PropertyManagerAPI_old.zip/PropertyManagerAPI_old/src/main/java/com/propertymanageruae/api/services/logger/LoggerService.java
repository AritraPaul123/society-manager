package com.propertymanageruae.api.services.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LoggerService  implements  ILoggerService{
    private static final Logger logger = LoggerFactory.getLogger(LoggerService.class);
    @Override
    public void logDebug(String message) {
        logger.debug(message);
    }
    @Override
    public void logError(String message) {
        logger.error(message);
    }
    @Override
    public void logInfo(String message) {
        logger.info(message);
    }
    @Override
    public void logWarn(String message) {
        logger.warn(message);
    }
}