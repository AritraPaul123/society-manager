package com.propertymanageruae.api.controllers.v1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.Notice;
import com.propertymanageruae.api.helper.UnitHelper;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.notice.AddNoticeDto;
import com.propertymanageruae.api.payloads.notice.ViewNoticeDto;
import com.propertymanageruae.api.payloads.notice.ViewNoticeGroupDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v${api.version}/notice")
@SecurityRequirement(name = "auth")
@Tag(name = "Notice")
public class Notice1Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Autowired
    private UnitService _unitService;
    @Autowired
    private UnitHelper _unitHelper;


    @Operation(description = "Get endpoint for notices", summary = "This is summary for notices get endpoint")
    @GetMapping("/all-notice/app/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewNoticeDto>>> getNotices(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(defaultValue = AppConstants.NoticeTimeline.UPCOMING) String noticeTimeline,
            @RequestParam(value = "searchText", required = false) String searchText,
            @PathVariable("societyId") long societyId
    ) throws JsonProcessingException {
        PaginationDto<ViewNoticeDto> noticeDTOs = this._unitService.noticeService.getNotices(pageNumber, pageSize, sortBy, sortDir, searchText, noticeTimeline, societyId);
        List<ViewNoticeDto> noticeDto = noticeDTOs.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", noticeDTOs.getPageSize());
        metadata.put("PageNumber", noticeDTOs.getPageNumber());
        metadata.put("TotalPages", noticeDTOs.getTotalPages());
        metadata.put("TotalElements", noticeDTOs.getTotalElements());
        metadata.put("IsFirstPage", noticeDTOs.isFirstPage());
        metadata.put("IsLastPage", noticeDTOs.isLastPage());
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(noticeDto, "Notices retrieved successfully", null, HttpStatus.OK.value())
        );
    }


    @Operation(description = "Get endpoint for notices group", summary = "This is summary for notices get endpoint")
    @GetMapping("/all-notice/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewNoticeGroupDto>>> getNoticeByGroup(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(defaultValue = AppConstants.NoticeTimeline.UPCOMING) String noticeTimeline,
            @RequestParam(value = "searchText", required = false) String searchText,
            @PathVariable("societyId") long societyId,
            @RequestHeader(value = "X-Timezone", defaultValue = "UTC") String userTimezone
    ) throws JsonProcessingException {
        PaginationDto<ViewNoticeGroupDto> noticeDTOs = this._unitService.noticeService.getNoticesGroup(pageNumber, pageSize, sortBy, sortDir, searchText, noticeTimeline, societyId,userTimezone);
        List<ViewNoticeGroupDto> noticeDto = noticeDTOs.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", noticeDTOs.getPageSize());
        metadata.put("PageNumber", noticeDTOs.getPageNumber());
        metadata.put("TotalPages", noticeDTOs.getTotalPages());
        metadata.put("TotalElements", noticeDTOs.getTotalElements());
        metadata.put("IsFirstPage", noticeDTOs.isFirstPage());
        metadata.put("IsLastPage", noticeDTOs.isLastPage());
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(noticeDto, "Notices retrieved successfully", null, HttpStatus.OK.value())
        );
    }

    @GetMapping("/{noticeId}/read-count")
    public ResponseEntity<Long> getReadCount(@PathVariable long noticeId) {
        long readCount = this._unitService.noticeService.getReadCountByNoticeId(noticeId);
        return ResponseEntity.ok(readCount);
    }


    @Operation(summary = "Create a new notice")
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<String>> postNotice(
            @RequestPart(value = "notices") AddNoticeDto notices,
            @RequestPart(value = "attachments", required = false) List<MultipartFile> attachments) throws IOException {
        List<MultipartFile> safeAttachments = (attachments != null) ? attachments : new ArrayList<>();
        String noticeRes = this._unitService.noticeService.postNotice(notices, safeAttachments);
        if (noticeRes != null) {
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, noticeRes, null, HttpStatus.CREATED.value()));
        } else {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.success(null, "Notice Not Posted", null, HttpStatus.BAD_REQUEST.value()));
        }

    }

    @Operation(summary = "Expired notice")
    @PutMapping("/expired-notice/{id}")
    public ResponseEntity<ApiResponse<Void>> doExpiredNotice(@PathVariable("id") int id) throws Exception {
        this._unitService.noticeService.doExpiredNotice(id);
        return ResponseEntity.ok(
                ApiResponse.success(null, "Notice expired successfully", null, HttpStatus.OK.value())
        );
    }

    @GetMapping("/app/get-notices")
    public ResponseEntity<ApiResponse<List<ViewNoticeGroupDto>>> getFilteredNotices(@RequestParam(required = false) Long societyId,
                                                                        @RequestParam(required = false) Long areaId,
                                                                        @RequestParam(required = false) Long apartmentId,
                                                                        @RequestParam(required = false) String targetAudience) {
        List<ViewNoticeGroupDto> notice=this._unitService.noticeService.getFilteredNotices(societyId, areaId, apartmentId, targetAudience);
        return ResponseEntity.ok(
                ApiResponse.success(notice, "Notice filtered successfully", null, HttpStatus.OK.value())
        );
    }

    @GetMapping("/{noticeId}")
    public ResponseEntity<ApiResponse<ViewNoticeGroupDto>> getNoticeById(@PathVariable String noticeId) {
        ViewNoticeGroupDto notice = this._unitService.noticeService.getActiveNoticeById(noticeId);
        return ResponseEntity.ok(
                ApiResponse.success(notice, "Notice filtered by notice id successfully", null, HttpStatus.OK.value())
        );
    }
}