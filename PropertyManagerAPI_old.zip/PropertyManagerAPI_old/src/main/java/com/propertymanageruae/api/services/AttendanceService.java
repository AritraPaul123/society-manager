package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.Attendance;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.attendance.AttendanceDto;
import com.propertymanageruae.api.repositories.AttendanceRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    public AttendanceDto checkIn(Long userId, String location, String photoUrl) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", String.valueOf(userId)));

        Attendance attendance = new Attendance();
        attendance.setUser(user);
        attendance.setCheckInTime(LocalDateTime.now());
        attendance.setStatus("PRESENT");
        attendance.setLocation(location);
        attendance.setPhotoUrl(photoUrl);

        Attendance savedAttendance = attendanceRepository.save(attendance);
        return mapToDto(savedAttendance);
    }

    public AttendanceDto checkOut(Long attendanceId) {
        Attendance attendance = attendanceRepository.findById(attendanceId)
                .orElseThrow(() -> new ResourceNotFoundException("Attendance", "id", String.valueOf(attendanceId)));

        attendance.setCheckOutTime(LocalDateTime.now());
        Attendance savedAttendance = attendanceRepository.save(attendance);
        return mapToDto(savedAttendance);
    }

    public List<AttendanceDto> getAttendanceHistory(Long userId) {
        List<Attendance> history = attendanceRepository.findByUserId(userId);
        return history.stream().map(this::mapToDto).collect(Collectors.toList());
    }
    
    public List<AttendanceDto> getAllAttendance() {
        List<Attendance> all = attendanceRepository.findAll();
        return all.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private AttendanceDto mapToDto(Attendance attendance) {
        AttendanceDto dto = modelMapper.map(attendance, AttendanceDto.class);
        dto.setUserId(attendance.getUser().getId());
        dto.setUserName(attendance.getUser().getName()); // Assuming User has getName(), or getEmail()
        return dto;
    }
}
