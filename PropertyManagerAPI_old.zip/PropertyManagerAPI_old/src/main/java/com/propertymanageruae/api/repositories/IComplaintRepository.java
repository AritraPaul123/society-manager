package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.entities.Complaint;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IComplaintRepository extends JpaRepository<Complaint, Long>, JpaSpecificationExecutor<Complaint> {
//    @Query("SELECT c FROM Complaint c WHERE " +
//            "(:status IS NULL OR c.status = :status) AND " +
//            "(:categoryId IS NULL OR c.category.id = :categoryId) AND " +
//            "(:priority IS NULL OR c.priority = :priority) AND " +
//            "(:complaintVisibility IS NULL OR c.complaintVisibility = :complaintVisibility) AND " +
//            "(:assigneeId IS NULL OR c.assignee.id = :assigneeId) AND " +
//            "(:locationId IS NULL OR c.location.id = :locationId) AND " +
//            "(:searchText IS NULL OR (c.title LIKE %:searchText% OR c.description LIKE %:searchText%))")
//    List<Complaint> findWithFilters(
//            @Param("status") String status,
//            @Param("categoryId") Long categoryId,
//            @Param("priority") String priority,
//            @Param("complaintVisibility") Boolean complaintVisibility,
//            @Param("assigneeId") Long assigneeId,
//            @Param("locationId") Long locationId,
//            @Param("searchText") String searchText,
//            Pageable pageable);
//    List<Complaint> findBySocietyIdAndIsDelete(long societyId, boolean isDelete);
    @Query(value = """
        SELECT MAX(CAST(SUBSTRING(ticket_id, LOCATE('-', ticket_id) + 1) AS UNSIGNED))
        FROM complaint
        WHERE society_id = :societyId
    """, nativeQuery = true)
    Integer findLastTicketNumberBySociety(@Param("societyId") Long societyId);

}