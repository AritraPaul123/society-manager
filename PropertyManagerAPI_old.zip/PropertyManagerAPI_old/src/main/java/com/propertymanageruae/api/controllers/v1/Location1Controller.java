package com.propertymanageruae.api.controllers.v1;

public class Location1Controller {
}