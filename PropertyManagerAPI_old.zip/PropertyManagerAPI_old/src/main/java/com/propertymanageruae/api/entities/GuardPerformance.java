package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "guard_performance")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GuardPerformance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "guard_id", nullable = false)
    private User guard;

    @Column(name = "date", nullable = false)
    private LocalDate date;

    @Column(name = "patrols_assigned")
    private Integer patrolsAssigned = 0;

    @Column(name = "patrols_completed")
    private Integer patrolsCompleted = 0;

    @Column(name = "patrols_missed")
    private Integer patrolsMissed = 0;

    @Column(name = "incidents_reported")
    private Integer incidentsReported = 0;

    @Column(name = "visitors_processed")
    private Integer visitorsProcessed = 0;

    @Column(name = "attendance_status", length = 50)
    private String attendanceStatus; // PRESENT, ABSENT, HALF_DAY, LATE

    @Column(name = "check_in_time")
    private LocalDateTime checkInTime;

    @Column(name = "check_out_time")
    private LocalDateTime checkOutTime;

    @Column(name = "total_duty_hours", precision = 5, scale = 2)
    private BigDecimal totalDutyHours;

    @Column(name = "performance_score", precision = 5, scale = 2)
    private BigDecimal performanceScore; // 0-100

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (date == null) {
            date = LocalDate.now();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    /**
     * Calculate performance score based on metrics
     * Formula: (patrols_completed / patrols_assigned * 40) + 
     *          (attendance_present * 30) + 
     *          (incidents_reported * 10) + 
     *          (visitors_processed_efficiency * 20)
     */
    public void calculatePerformanceScore() {
        double score = 0.0;

        // Patrol completion (40 points)
        if (patrolsAssigned != null && patrolsAssigned > 0) {
            score += (patrolsCompleted.doubleValue() / patrolsAssigned.doubleValue()) * 40;
        }

        // Attendance (30 points)
        if ("PRESENT".equals(attendanceStatus)) {
            score += 30;
        } else if ("HALF_DAY".equals(attendanceStatus)) {
            score += 15;
        } else if ("LATE".equals(attendanceStatus)) {
            score += 20;
        }

        // Incidents reported (10 points - capped)
        if (incidentsReported != null) {
            score += Math.min(incidentsReported * 2, 10);
        }

        // Visitors processed (20 points - efficiency)
        if (visitorsProcessed != null && visitorsProcessed > 0) {
            score += Math.min(visitorsProcessed.doubleValue() / 5 * 20, 20);
        }

        this.performanceScore = BigDecimal.valueOf(Math.min(score, 100.0));
    }
}
