package com.propertymanageruae.api.payloads.user;

import com.propertymanageruae.api.payloads.utils.SocietyRoleDto;
import lombok.Data;

import java.util.List;
@Data
public class ViewUserDto {
    private int id;
    private String name;
    private String email;
    private String contactNumber;
    private String profileUrl;
    private boolean status;
    private List<SocietyRoleDto> societyRoles;
}