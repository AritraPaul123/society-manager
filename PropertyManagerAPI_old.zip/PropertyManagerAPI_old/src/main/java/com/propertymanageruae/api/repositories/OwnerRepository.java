package com.propertymanageruae.api.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.propertymanageruae.api.entities.Owner;

public interface OwnerRepository extends JpaRepository<Owner, Long> {
    // owner fields were renamed to lessor*
    List<Owner> findByLessorEmail(String lessorEmail);
    List<Owner> findByLessorEmiratesId(String lessorEmiratesId);
}

