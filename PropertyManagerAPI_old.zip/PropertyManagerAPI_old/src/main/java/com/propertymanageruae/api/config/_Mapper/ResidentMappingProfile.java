package com.propertymanageruae.api.config._Mapper;

import com.propertymanageruae.api.entities.Resident;
import com.propertymanageruae.api.entities.Role;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.master.ResidentSocietyDetailDto;
import com.propertymanageruae.api.payloads.master.ViewApartmentOfResidentsDto;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.member.ViewMemberDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import com.propertymanageruae.api.payloads.user.ViewComplainerDto;
import com.propertymanageruae.api.payloads.utils.SocietyRoleDto;
import com.propertymanageruae.api.repositories.IRoleRepository;
import jakarta.annotation.PostConstruct;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class ResidentMappingProfile {

    private final ModelMapper modelMapper;
    private final IRoleRepository roleRepository;

    public ResidentMappingProfile(ModelMapper modelMapper, IRoleRepository roleRepository) {
        this.modelMapper = modelMapper;
        this.roleRepository = roleRepository;
    }



//    @PostConstruct
//    public void configureResidentMapping() {
//        TypeMap<Resident, ViewMemberDto> typeMap = modelMapper.createTypeMap(Resident.class, ViewMemberDto.class);
//        typeMap.addMappings(mapper -> {
//            mapper.map(Resident::getOwnerEmail, ViewMemberDto::setEmail);
//            mapper.map(Resident::getOwnerName, ViewMemberDto::setName);
//            mapper.map(Resident::getOwnerPhone, ViewMemberDto::setContactNumber);
//            mapper.map(src -> src.getUser().getMemberId(), ViewMemberDto::setMemberId);
//            mapper.map(src -> src.getUser().getId(), ViewMemberDto::setId);
//            mapper.map(Resident::getId, ViewMemberDto::setUserId);
//            mapper.map(Resident::getRoles, ViewMemberDto::setUpdateRoles);
//            mapper.map(Resident::isStatus, ViewMemberDto::setStatus);
//            mapper.using(ctx -> {
//                String rolesString = (String) ctx.getSource();  // Directly access the string roles here
//                Set<Role> roles = new HashSet<>();
//                if (rolesString != null && !rolesString.isEmpty()) {
//                    String[] rolesArray = rolesString.split(",");  // Split roles string by commas
//                    for (String roleTitle : rolesArray) {
//                        Role role = roleRepository.findByTitle(roleTitle.trim());
//                        if (role != null) {
//                            roles.add(role);
//                        }
//                    }
//                }
//                return roles;
//            }).map(Resident::getRoles, ViewMemberDto::setRoles);
//        });
//
//        TypeMap<Resident, ViewApartmentOfResidentsDto> residentSocietyMap = modelMapper.createTypeMap(Resident.class, ViewApartmentOfResidentsDto.class);
//        residentSocietyMap.addMappings(
//                mapper -> {
//                    mapper.map(r->r.getSociety().getId(),ViewApartmentOfResidentsDto::setSocietyId);
//                    mapper.map(r->r.getApartment().getId(),ViewApartmentOfResidentsDto::setApartmentId);
//                    mapper.map(r->r.getArea().getId(),ViewApartmentOfResidentsDto::setAreaId);
//                    mapper.map(r->r.getApartment().getBlock(),ViewApartmentOfResidentsDto::setBlock);
//                    mapper.map(r->r.getApartment().getFlat(),ViewApartmentOfResidentsDto::setFlat);
//                    mapper.map(r->r.getApartment().getFloor(),ViewApartmentOfResidentsDto::setFloor);
//                    mapper.map(r->r.getSociety().getSocietyName(),ViewApartmentOfResidentsDto::setSocietyName);
//                    mapper.map(Resident::getId,ViewApartmentOfResidentsDto::setId);
//                }
//        );
//    }

    @PostConstruct
    public void configureResidentMapping() {
        TypeMap<Resident, ViewMemberDto> typeMap = modelMapper.createTypeMap(Resident.class, ViewMemberDto.class);
        typeMap.addMappings(mapper -> {
            mapper.map(Resident::getOwnerEmail, ViewMemberDto::setEmail);
            mapper.map(Resident::getOwnerName, ViewMemberDto::setName);
            mapper.map(Resident::getOwnerPhone, ViewMemberDto::setContactNumber);
            mapper.map(src -> src.getUser().getMemberId(), ViewMemberDto::setMemberId);
            mapper.map(src -> src.getUser().getId(), ViewMemberDto::setId);
            mapper.map(Resident::getId, ViewMemberDto::setUserId);
            mapper.map(Resident::getRoles, ViewMemberDto::setUpdateRoles); // This remains if you want to store the comma-separated string
            mapper.map(Resident::isStatus, ViewMemberDto::setStatus);

            // 👇 Mapping for List<SocietyRoleDto>
            mapper.using(ctx -> {
                Resident resident = (Resident) ctx.getSource();
                User user = resident.getUser();

                if (user == null || user.getUserRoleMappings() == null) {
                    return new ArrayList<SocietyRoleDto>();
                }

                return user.getUserRoleMappings().stream().map(mapping -> {
                    SocietyRoleDto dto = new SocietyRoleDto();

                    // Map society
                    ViewSocietyDto societyDto = modelMapper.map(mapping.getSociety(), ViewSocietyDto.class);
                    dto.setSociety(societyDto);

                    // Map role
                    RoleDTO roleDto = modelMapper.map(mapping.getRole(), RoleDTO.class);
                    dto.setRole(roleDto);

                    return dto;
                }).collect(Collectors.toList());
            }).map(src -> src, ViewMemberDto::setSocietyRoles);
        });

        // Mapping for ViewApartmentOfResidentsDto
        TypeMap<Resident, ViewApartmentOfResidentsDto> residentSocietyMap =
                modelMapper.createTypeMap(Resident.class, ViewApartmentOfResidentsDto.class);

        residentSocietyMap.addMappings(mapper -> {
            mapper.map(r -> r.getSociety().getId(), ViewApartmentOfResidentsDto::setSocietyId);
            mapper.map(r -> r.getApartment().getId(), ViewApartmentOfResidentsDto::setApartmentId);
            mapper.map(r -> r.getArea().getId(), ViewApartmentOfResidentsDto::setAreaId);
            mapper.map(r -> r.getApartment().getBlock(), ViewApartmentOfResidentsDto::setBlock);
            mapper.map(r -> r.getApartment().getFlat(), ViewApartmentOfResidentsDto::setFlat);
            mapper.map(r -> r.getApartment().getFloor(), ViewApartmentOfResidentsDto::setFloor);
            mapper.map(r -> r.getSociety().getSocietyName(), ViewApartmentOfResidentsDto::setSocietyName);
            mapper.map(Resident::getId, ViewApartmentOfResidentsDto::setId);
        });

        TypeMap<Resident, ViewComplainerDto> complainerMap =
                modelMapper.createTypeMap(Resident.class, ViewComplainerDto.class);
        complainerMap.addMappings(mapper -> {
            mapper.map(r->r.getUser().getId(),ViewComplainerDto::setMemberId);
        });
    }



}