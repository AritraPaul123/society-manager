package com.propertymanageruae.api.services.inspection;

import com.propertymanageruae.api.payloads.inspection.InspectionSectionDTO;
import com.propertymanageruae.api.payloads.inspection.ViewInspectionSectionDTO;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

public interface IInspectionSectionService {
    String createSection(InspectionSectionDTO sectionDTO) throws SQLIntegrityConstraintViolationException;
    List<ViewInspectionSectionDTO> getSectionsByInspectionId(long inspectionId);
}