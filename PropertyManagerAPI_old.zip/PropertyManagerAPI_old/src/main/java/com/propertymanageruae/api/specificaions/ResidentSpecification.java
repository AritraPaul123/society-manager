package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.entities.Resident;
import com.propertymanageruae.api.entities.Role;
import com.propertymanageruae.api.entities.User;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public class ResidentSpecification {
    public static Specification<Resident> hasSocietyId(long societyId) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.equal(root.get("society").get("id"), societyId);
    }

    public static Specification<Resident> isNotDeleted(boolean isDelete) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.equal(root.get("isDelete"), isDelete);
    }

    public static Specification<Resident> hasNotMemberId(String memberId) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.notEqual(root.join("user").get("memberId"), memberId);
    }

    public static Specification<User> hasRoleNotIn(List<Long> excludedRoleIds) {
        return (root, query, criteriaBuilder) -> {
            Join<User, Role> roles = root.join("roles");
            return criteriaBuilder.not(roles.get("id").in(excludedRoleIds));
        };
    }

    public static Specification<Resident> hasRolesNotIn(List<Long> excludedRoleIds) {
        return (root, query, criteriaBuilder) -> {
            Join<Resident, User> userJoin = root.join("user", JoinType.LEFT); // Join with User
            Join<User, Role> userMap = userJoin.join("userRoleMappings", JoinType.LEFT); // Join with Roles
            return criteriaBuilder.not(userMap.get("role").get("id").in(excludedRoleIds));
        };
    }

    public static Specification<Resident> searchByText(String searchText) {
        return (root, query, criteriaBuilder) -> {
            String searchPattern = "%" + searchText.toLowerCase() + "%";
            return criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("ownerName")), searchPattern),
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("ownerEmail")), searchPattern),
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("ownerPhone")), searchPattern)
            );
        };
    }

    public static Specification<Resident> isNotDeleted() {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.isFalse(root.get("isDelete"));
    }

    public static Specification<Resident> findResidentsBySocietyAndAreaAndApartment(Long societyId, Long areaId, Long apartmentId) {
        return (Root<Resident> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            Predicate predicate = cb.conjunction();
            predicate = cb.and(predicate, cb.equal(root.get("society").get("id"), societyId));
            if (areaId != 1) {
                predicate = cb.and(predicate, cb.equal(root.get("area").get("id"), areaId));
            }
            if (apartmentId != 1) {
                predicate = cb.and(predicate, cb.equal(root.get("apartment").get("id"), apartmentId));
            }
            return predicate;
        };
    }

    public static Specification<Resident> filterResidentsForNotice(
            Long societyId, Long areaId, Long apartmentId, String targetAudience) {
        final String normalizedTargetAudience = targetAudience != null ? targetAudience.trim().toUpperCase() : "";
        return (Root<Resident> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {

            Predicate predicate = cb.conjunction(); // Initialize with `true` condition
            predicate = cb.and(predicate, cb.equal(root.get("society").get("id"), societyId));
            if (areaId != 1) {
                predicate = cb.and(predicate, cb.equal(root.get("area").get("id"), areaId));
            }
            if (apartmentId != 1) {
                predicate = cb.and(predicate, cb.equal(root.get("apartment").get("id"), apartmentId));
            }
            // Target audience filter
            if (!normalizedTargetAudience.isEmpty()) {
                Predicate ownerCondition = cb.conjunction();
                Predicate tenantCondition = cb.conjunction();
                if ("OWNERS".equals(normalizedTargetAudience) || "BOTH".equals(normalizedTargetAudience)) {
                    ownerCondition = cb.and(
                            cb.isNotNull(root.get("ownerEmail")),
                            cb.notEqual(cb.trim(root.get("ownerEmail")), "")
                    );
                }
                if ("TENANTS".equals(normalizedTargetAudience) || "BOTH".equals(normalizedTargetAudience)) {
                    tenantCondition = cb.and(
                            cb.isNotNull(root.get("tenantEmail")),
                            cb.notEqual(cb.trim(root.get("tenantEmail")), "")
                    );
                }

                predicate = cb.and(predicate, cb.or(ownerCondition, tenantCondition));
            }

            predicate = cb.and(predicate, cb.or(
                    cb.like(cb.lower(root.get("roles")), "%resident%"),
                    cb.equal(cb.trim(cb.coalesce(root.get("roles"), "")), "")
            ));

            return predicate;
        };
    }

    public static Specification<Resident> searchByText(String searchText, long societyId, long areaId, long apartmentId) {
        return (root, query, criteriaBuilder) -> {
            Predicate societyPredicate = criteriaBuilder.equal(root.get("society").get("id"), societyId);
            Predicate areaPredicate = criteriaBuilder.equal(root.get("area").get("id"), areaId);
            Predicate apartmentPredicate = criteriaBuilder.equal(root.get("apartment").get("id"), areaId);
            if (searchText == null || searchText.trim().isEmpty()) {
                criteriaBuilder.and(areaPredicate, societyPredicate, apartmentPredicate);
            }
            String likePattern = "%" + searchText.toLowerCase() + "%";
            Predicate ownerNamePredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("ownerName")), likePattern);
            Predicate ownerEmailPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("ownerEmail")), likePattern);
            Predicate tenentNamePredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("tenantName")), likePattern);
            Predicate tenentEmailPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("tenantEmail")), likePattern);
            Predicate searchPredicate = criteriaBuilder.or(ownerNamePredicate, ownerEmailPredicate, tenentNamePredicate, tenentEmailPredicate);
            return criteriaBuilder.and(areaPredicate, societyPredicate, searchPredicate);
        };
    }

}