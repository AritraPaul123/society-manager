
package com.propertymanageruae.api.services.token;


import com.propertymanageruae.api.entities.RefreshToken;
import com.propertymanageruae.api.payloads.user.JwtAuthRequest;

public interface IRefreshTokenService {
    RefreshToken createRefreshToken(String user);
    RefreshToken verifyRefreshToken(String refreshToken);
    void revokeRefreshTokens(JwtAuthRequest username);

}