package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.entities.CommentMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ICommentMasterRepository extends JpaRepository<CommentMaster, Long> {
    List<CommentMaster> findBySocietyIdAndIsDelete(long societyId, boolean isDelete);
    List<CommentMaster> findByComplaintIdAndIsDelete(long complaintId, boolean isDelete);

}