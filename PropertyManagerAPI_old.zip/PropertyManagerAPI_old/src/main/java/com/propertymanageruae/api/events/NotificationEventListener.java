package com.propertymanageruae.api.events;

import com.propertymanageruae.api.payloads.notification.NotificationDto;
import com.propertymanageruae.api.services.fcm.IFCMService; // your existing FCM service interface
import com.propertymanageruae.api.services.utils.RealTimeNotificationService; // your existing RT service (we will update)
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.event.TransactionPhase;

@Component
public class NotificationEventListener {

    private final RealTimeNotificationService rtService;
    private final IFCMService fcmService;

    public NotificationEventListener(RealTimeNotificationService rtService, IFCMService fcmService) {
        this.rtService = rtService;
        this.fcmService = fcmService;
    }

    // AFTER_COMMIT ensures DB persistence is successful
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void handleNotificationCreated(NotificationCreatedEvent event) {
        NotificationDto dto = event.getNotification();

        // 1) Send real-time via WebSocket (principalName used below: we'll use userId string)
        // Update RealTimeNotificationService to use convertAndSendToUser
        try {
            rtService.sendToUser(String.valueOf(dto.userId), dto);
        } catch (Exception ex) {
            // log
        }

        // 2) Send push via FCM (web + mobile)
        try {
            fcmService.sendNotificationToUserId(dto.userId, dto.title, dto.message); // implement this method in your FCM service
        } catch (Exception ex) {
            // log
        }
    }
}