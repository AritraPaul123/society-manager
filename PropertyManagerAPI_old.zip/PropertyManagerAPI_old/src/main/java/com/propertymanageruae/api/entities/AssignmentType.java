package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "assignmentType")
public class AssignmentType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "type", nullable = false)
    private String type;
    @OneToMany(mappedBy = "assignmentType", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<AssignmentSlot> assignmentSlots = new ArrayList<>();
    @Column(name = "description",length = 500)
    private String description;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}