package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.Notice;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class NoticeSpecification {
    public static Specification<Notice> hasSocietyId(long societyId) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.equal(root.get("society").get("id"), societyId);
    }

    public static Specification<Notice> isNotDeleted(boolean isDeleted) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.equal(root.get("isDeleted"), isDeleted);
    }

    public static Specification<Notice> searchByText(String searchText) {
        return (root, query, criteriaBuilder) -> {
            if (searchText == null || searchText.trim().isEmpty()) {
                return criteriaBuilder.conjunction();
            }
            String searchPattern = "%" + searchText.toLowerCase() + "%";
            return criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("title")), searchPattern),
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("description")), searchPattern)
            );
        };
    }

    public static Specification<Notice> filterByTimeline(String timeline) {
        return (root, query, criteriaBuilder) -> {
            LocalDateTime now = LocalDateTime.now();
            criteriaBuilder.conjunction();
            return switch (timeline) {
                case AppConstants.NoticeTimeline.UPCOMING ->
                    // Upcoming: postedAt is in the future
                        criteriaBuilder.greaterThan(root.get("postedAt"), now);
                case AppConstants.NoticeTimeline.CURRENT ->
                    // Current: postedAt is in the past (or now), and (either expiredAt is NULL OR greater than now)
                        criteriaBuilder.and(
                                criteriaBuilder.lessThanOrEqualTo(root.get("postedAt"), now),
                                criteriaBuilder.or(
                                        criteriaBuilder.isNull(root.get("expiredAt")),
                                        criteriaBuilder.greaterThanOrEqualTo(root.get("expiredAt"), now)
                                )
                        );
                case AppConstants.NoticeTimeline.EXPIRED ->
                    // Expired: expiredAt is not NULL and less than now
                        criteriaBuilder.and(
                                criteriaBuilder.isNotNull(root.get("expiredAt")),
                                criteriaBuilder.lessThan(root.get("expiredAt"), now)
                        );
                default -> throw new IllegalArgumentException("Invalid timeline: " + timeline);
            };
        };
    }

    public static Specification<Notice> filterByTimelineZoneWise(String timeline) {
        return (root, query, criteriaBuilder) -> {
            ZonedDateTime nowUtc = ZonedDateTime.now(ZoneId.of("UTC")); // ✅ Ensure UTC time
            LocalDateTime now = nowUtc.toLocalDateTime();

            criteriaBuilder.conjunction();
            return switch (timeline) {
                case AppConstants.NoticeTimeline.UPCOMING -> criteriaBuilder.greaterThan(root.get("postedAt"), now);
                case AppConstants.NoticeTimeline.CURRENT -> criteriaBuilder.and(
                        criteriaBuilder.lessThanOrEqualTo(root.get("postedAt"), now),
                        criteriaBuilder.or(
                                criteriaBuilder.isNull(root.get("expiredAt")),
                                criteriaBuilder.greaterThanOrEqualTo(root.get("expiredAt"), now)
                        )
                );
                case AppConstants.NoticeTimeline.EXPIRED -> criteriaBuilder.and(
                        criteriaBuilder.isNotNull(root.get("expiredAt")),
                        criteriaBuilder.lessThan(root.get("expiredAt"), now)
                );
                default -> throw new IllegalArgumentException("Invalid timeline: " + timeline);
            };
        };
    }

    public static Specification<Notice> filterNotices(Long societyId, Long areaId, Long apartmentId,String targetAudience) {
        return (root, query, criteriaBuilder) -> {
            ZonedDateTime nowUtc = ZonedDateTime.now(ZoneId.of("UTC")); // ✅ Ensure UTC time
            LocalDateTime now = nowUtc.toLocalDateTime().withNano(0);
            List<Predicate> predicates = new ArrayList<>();
            // Exclude deleted and expired notices
            predicates.add(criteriaBuilder.isFalse(root.get("isDeleted")));
            predicates.add(criteriaBuilder.isFalse(root.get("expired")));
            predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("postedAt"), criteriaBuilder.literal(now)));
            predicates.add(criteriaBuilder.or(
                    criteriaBuilder.isNull(root.get("expiredAt")),
                    criteriaBuilder.greaterThan(root.get("expiredAt"), criteriaBuilder.literal(now))
            ));
            // Filter by target audience if provided
            if (targetAudience != null && !targetAudience.isEmpty()) {
                predicates.add(root.get("targetAudience").in(targetAudience, AppConstants.TargetAudience.BOTH));
            }

            // Condition 1: General notices for the society
            Predicate condition1 = criteriaBuilder.and(
                    criteriaBuilder.equal(root.get("society").get("id"), societyId),
                    criteriaBuilder.equal(root.get("area").get("id"), 1),
                    criteriaBuilder.equal(root.get("apartment").get("id"), 1)
            );
            // Condition 2: Notices for a specific area within the society
            Predicate condition2 = criteriaBuilder.and(
                    criteriaBuilder.equal(root.get("society").get("id"), societyId),
                    criteriaBuilder.equal(root.get("area").get("id"), areaId),
                    criteriaBuilder.equal(root.get("apartment").get("id"), 1)
            );
            // Condition 3: Notices for a specific apartment within the society
            Predicate condition3 = criteriaBuilder.and(
                    criteriaBuilder.equal(root.get("society").get("id"), societyId),
                    criteriaBuilder.equal(root.get("area").get("id"), 1),
                    criteriaBuilder.equal(root.get("apartment").get("id"), apartmentId)
            );
            // Combine all conditions using OR
            predicates.add(criteriaBuilder.or(condition1, condition2, condition3));
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

}