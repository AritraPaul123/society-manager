package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "apartment")
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Apartment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "block")
    private String block;
    @Column(name = "floor")
    private String floor;
    @Column(name = "flat")
    private String flat;
    @Column(name = "intercom")
    private String intercom;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "areaId", nullable = false)
    @JsonBackReference
    @ToString.Exclude
    private Area area;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "societyId", nullable = false)
    @JsonBackReference
    @ToString.Exclude
    private Society society;
    @OneToMany(mappedBy = "apartment", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JsonManagedReference
    @ToString.Exclude
    private List<Resident> resident;

    @OneToMany(mappedBy = "apartment", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JsonManagedReference
    @ToString.Exclude
    private List<Notice> notice;

    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}