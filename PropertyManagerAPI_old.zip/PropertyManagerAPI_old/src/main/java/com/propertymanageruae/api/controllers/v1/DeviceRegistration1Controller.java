package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.token.FCMTokenResponse;
import com.propertymanageruae.api.payloads.token.FcmTokenRequest;
import com.propertymanageruae.api.payloads.token.FcmTokenUpdateRequest;
import com.propertymanageruae.api.payloads.token.FcmUnregisterRequest;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v${api.version}/devices")
@SecurityRequirement(name = "auth")
@Tag(name = "Device Registration", description = "Device Registration API")
public class DeviceRegistration1Controller {
    @Value("${api.version}")
    private String apiVersion;

    @Autowired
    private UnitService _uniService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<FCMTokenResponse>> registerFcmToken(@RequestBody FcmTokenRequest request) {
        try{
            if (request.getUserId() == null || request.getFcmToken() == null || request.getDeviceId() == null || request.getDeviceType() == null) {
                return ResponseEntity
                        .status(HttpStatus.BAD_REQUEST)
                        .body(ApiResponse.success(null, "All fields are required", null, HttpStatus.BAD_REQUEST.value()));
            }
            FCMTokenResponse fcmTokenResponse= _uniService.fcmService.saveFcmToken(request);
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(ApiResponse.success(fcmTokenResponse, "FCM Token registered successfully", null, HttpStatus.OK.value()));

        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.success(null, "Error processing request: " + e.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @PutMapping("/update-token")
    public ResponseEntity<ApiResponse<FCMTokenResponse>> updateFcmToken(@RequestBody FcmTokenUpdateRequest request) {
        try {
            if (request.getUserId() == null || request.getFcmToken() == null || request.getDeviceId() == null) {
                return ResponseEntity.badRequest().body(ApiResponse.success(null,"All fields are required", null, HttpStatus.BAD_REQUEST.value()));
            }

            FCMTokenResponse response = _uniService.fcmService.updateFcmToken(request);
            return ResponseEntity.ok(ApiResponse.success(response, "FCM token updated successfully", null, 200));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(ApiResponse.success(null,"Error updating token: " + e.getMessage(), null, 500));
        }
    }

    @DeleteMapping("/unregister")
    public ResponseEntity<ApiResponse<Object>> unregisterFcmToken(@RequestBody FcmUnregisterRequest request) {
        try {
            if (request.getUserId() == null || request.getDeviceId() == null) {
                return ResponseEntity.badRequest().body(ApiResponse.success(null,"User ID and Device ID are required", null, HttpStatus.BAD_REQUEST.value()));
            }

            _uniService.fcmService.unregisterFcmToken(request);
            return ResponseEntity.ok(ApiResponse.success(null, "Device unregistered successfully", null, 200));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(ApiResponse.success(null,"Error unregistering device: " + e.getMessage(), null, 500));
        }
    }


}