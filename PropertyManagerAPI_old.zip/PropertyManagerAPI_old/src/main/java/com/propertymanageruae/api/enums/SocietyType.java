package com.propertymanageruae.api.enums;


public enum SocietyType {
    PUBLISH,
    UNPUBLISH
}