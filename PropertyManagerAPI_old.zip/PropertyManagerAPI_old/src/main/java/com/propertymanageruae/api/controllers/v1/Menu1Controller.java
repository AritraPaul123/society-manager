package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.entities.Menu;
import com.propertymanageruae.api.payloads.menu.EditMenuDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.menu.IMenuService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v${api.version}/menu")
@SecurityRequirement(name = "auth")
@Tag(name = "Menu", description = "Menu management API")
@RequiredArgsConstructor
public class Menu1Controller {
    @Value("${api.version}")
    private String apiVersion;

    private final IMenuService menuService;

    @GetMapping
    public ResponseEntity<ApiResponse<List<Menu>>> getAllMenus() {
        try {
            List<Menu> menus = menuService.getMenus();
            return ResponseEntity.ok(ApiResponse.success(menus, "Fetched menus", null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.ok(ApiResponse.error(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @PostMapping("/edit/{id}")
    public ResponseEntity<ApiResponse<List<Menu>>> updateMenu(@PathVariable Long id, @RequestBody EditMenuDto menuDto) {
        try {
            List<Menu> menus = menuService.updateMenu(id, menuDto);
            return ResponseEntity.ok(ApiResponse.success(menus, "Menu updated successfully", null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.ok(ApiResponse.error(ex.getMessage(), null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @PostMapping("/delete/{id}")
    public ResponseEntity<ApiResponse<List<Menu>>> deleteMenu(@PathVariable Long id) {
        try {
            List<Menu> menus = menuService.deleteMenu(id);
            return ResponseEntity.ok(ApiResponse.success(menus, "Menu deleted successfully", null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.ok(ApiResponse.error(ex.getMessage(), null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @PostMapping("/parent")
    public ResponseEntity<ApiResponse<List<Menu>>> addParentMenu(@RequestBody EditMenuDto menuDto) {
        try {
            List<Menu> menus = menuService.addParentMenu(menuDto);
            return ResponseEntity.ok(ApiResponse.success(menus, "Menu added successfully", null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.ok(ApiResponse.error(ex.getMessage(), null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @PostMapping("/{parentId}/child")
    public ResponseEntity<ApiResponse<List<Menu>>> addChildMenu(@PathVariable Long parentId, @RequestBody EditMenuDto menuDto) {
        try {
            List<Menu> menus = menuService.addChildMenu(parentId, menuDto);
            return ResponseEntity.ok(ApiResponse.success(menus, "Child menu added successfully", null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.ok(ApiResponse.error(ex.getMessage(), null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @PostMapping("/{menuId}/order/up")
    public ResponseEntity<ApiResponse<List<Menu>>> moveMenuOrderUp(@PathVariable Long menuId) {
        try {
            List<Menu> menus = menuService.moveMenuOrderUp(menuId);
            return ResponseEntity.ok(ApiResponse.success(menus, "Menu order changed up successfully", null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.ok(ApiResponse.error(ex.getMessage(), null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }

    @PostMapping("/{menuId}/order/down")
    public ResponseEntity<ApiResponse<List<Menu>>> moveMenuOrderDown(@PathVariable Long menuId) {
        try {
            List<Menu> menus = menuService.moveMenuOrderDown(menuId);
            return ResponseEntity.ok(ApiResponse.success(menus, "Menu order changed down successfully", null, HttpStatus.OK.value()));
        } catch (Exception ex) {
            return ResponseEntity.ok(ApiResponse.error(ex.getMessage(), null, null, HttpStatus.INTERNAL_SERVER_ERROR.value()));
        }
    }
}