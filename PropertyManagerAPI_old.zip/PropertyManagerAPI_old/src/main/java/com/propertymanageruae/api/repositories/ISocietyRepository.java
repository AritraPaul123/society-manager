package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.enums.SocietyType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ISocietyRepository extends JpaRepository<Society,Long>, JpaSpecificationExecutor<Society> {
    Optional<Society> findBySocietyEmail(String societyEmail);
    List<Society> findBySocietyType(SocietyType societyType);
    boolean existsBySocietyCode(String societyCode);
    boolean existsBySocietyId(String societyId);
    List<Society> findByIsDeleteFalse();
    Page<Society> findByIsDeleteFalse(Pageable pageable);
    List<Society> findByIsDeleteFalseAndSocietyType(SocietyType societyType);
    Optional<Society> findByIdAndIsDeleteFalseAndSocietyType(Long id, SocietyType societyType);
    @Query("SELECT s FROM Society s WHERE s.isDelete = false " +
            "AND (LOWER(s.societyName) LIKE LOWER(CONCAT('%', :searchText, '%')) " +
            "OR LOWER(s.societyEmail) LIKE LOWER(CONCAT('%', :searchText, '%')) " +
            "OR LOWER(s.societyCode) LIKE LOWER(CONCAT('%', :searchText, '%')))")
    Page<Society> searchSociety(
            @Param("searchText") String searchText,
            Pageable pageable
    );

}