package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "area")
@Builder
public class Area {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "area")
    private String area;
    @Column(name = "type")
    private String type;
    @Column(name = "cluster")
    private String cluster;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "societyId", nullable = false)
    @JsonBackReference
    private Society society;
    @OneToMany(mappedBy = "area", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JsonManagedReference
    private List<Apartment> apartment;
    @OneToMany(mappedBy = "area", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JsonManagedReference
    private List<Resident> resident;

    @OneToMany(mappedBy = "area", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JsonManagedReference
    private List<Notice> notice;

    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}