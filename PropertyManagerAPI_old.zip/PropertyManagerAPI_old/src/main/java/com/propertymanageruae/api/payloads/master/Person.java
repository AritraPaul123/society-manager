package com.propertymanageruae.api.payloads.master;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Person {
    private long id;
    private String name;
    private String email;
    private String profileUrl;
    private String authorRole;
    @Builder.Default
    private boolean isSystemMessage = false;
}