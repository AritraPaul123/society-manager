package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.anotation.CurrentUser;
import com.propertymanageruae.api.entities.Notification;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v${api.version}/notifications")
@Tag(name = "Notifications")
public class Notification1Controller {
    private final UnitService unitService;
    @Value("${api.version}")
    private String apiVersion;


    public Notification1Controller(UnitService unitService) {
        this.unitService = unitService;
    }

    @GetMapping
    public ResponseEntity<List<Notification>> getMyNotifications(@CurrentUser User user) {
        List<Notification> list = this.unitService.notificationService.getMyNotifications(user.getId());
        return ResponseEntity.ok(list);
    }

    @PutMapping("/mark-all-read")
    public ResponseEntity<Void> markAllRead(@CurrentUser User user) {
        this.unitService.notificationService.markAllRead(user.getId());
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<?> markRead(
            @PathVariable Long id,
            @CurrentUser User user) {
        this.unitService.notificationService.markRead(id, user.getId());
        return ResponseEntity.ok(new ApiResponse(true,"Notification marked as read",null,null,200));
    }

}