package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.payloads.master.ResidentSocietyDetailDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IResidentRepository  extends JpaRepository<Resident,Long>, JpaSpecificationExecutor<Resident> {
    Optional<Resident> findByApartmentAndSocietyAndArea(Apartment apartment, Society society, Area area);
    Optional<Resident> findByOwnerEmailAndSocietyIdAndIsDelete(String ownerEmail, Long societyId, boolean isDelete);
    List<Resident> findByUserMemberId(String memberId);
    @Query("SELECT r FROM Resident r JOIN r.society s WHERE s.id = :societyId AND r.apartment.id != 1 AND r.area.id!=1")
    Page<Resident> findResidentBySocietyId(@Param("societyId") Long societyId, Pageable pageable);
    @Query("SELECT r FROM Resident r LEFT JOIN r.apartment a WHERE " +
            "LOWER(r.ownerName) LIKE LOWER(CONCAT('%', :searchText, '%')) OR " +
            "LOWER(r.ownerEmail) LIKE LOWER(CONCAT('%', :searchText, '%')) OR "+
            "LOWER(a.flat) LIKE LOWER(CONCAT('%', :searchText, '%')) AND "+
            "r.apartment.id != 1 AND r.area.id!=1"
    )
    Page<Resident> findBySearchText(@Param("searchText") String searchText, Pageable pageable);
    Optional<Resident> findByOwnerEmail(String email);
    @Query("SELECT new com.propertymanageruae.api.payloads.master.ResidentSocietyDetailDto(r.id, a.block, a.flat, a.floor, s.societyName, r.society.id, r.apartment.id) " +
            "FROM Resident r " +
            "JOIN r.apartment a " +
            "JOIN r.society s " +
            "WHERE r.ownerEmail = :ownerEmail " +
            "AND r.isDelete = false " +
            "AND a.isDelete = false " +
            "AND s.isDelete = false")
    List<ResidentSocietyDetailDto> getSocietyListForAll(@Param("ownerEmail") String ownerEmail);

    @Query("SELECT new com.propertymanageruae.api.payloads.master.ResidentSocietyDetailDto(r.id, a.block, a.flat, a.floor, s.societyName, r.society.id, r.apartment.id) " +
            "FROM Resident r " +
            "JOIN r.apartment a " +
            "JOIN r.society s " +
            "WHERE r.isDelete = false " +
            "AND a.isDelete = false " +
            "AND s.isDelete = false " +
            "AND LOWER(s.societyName) NOT LIKE LOWER(:excludedSocietyName) " +
            "AND LOWER(a.block) NOT LIKE LOWER(:excludedBlockName) " +
            "AND LOWER(a.flat) NOT LIKE LOWER(:excludedFlatName)")
    List<ResidentSocietyDetailDto> getSocietyListForMaster(@Param("excludedSocietyName") String excludedSocietyName,
                                                              @Param("excludedBlockName") String excludedBlockName,
                                                              @Param("excludedFlatName") String excludedFlatName);

    @Query("SELECT new com.propertymanageruae.api.payloads.master.ResidentSocietyDetailDto(a.id, a.block, a.flat, a.floor, s.societyName, r.society.id, a.id) " +
            "FROM Resident r " +
            "LEFT JOIN r.society s " +
            "LEFT JOIN Apartment a ON a.society.id = s.id " +
            "WHERE r.ownerEmail = :ownerEmail " +
            "OR r.tenantEmail = :ownerEmail " +
            "AND r.isDelete = false " +
            "AND a.isDelete = false " +
            "AND s.isDelete = false " +
            "AND LOWER(s.societyName) NOT LIKE LOWER(:excludedSocietyName) " +
            "AND LOWER(a.block) NOT LIKE LOWER(:excludedBlockName) " +
            "AND LOWER(a.flat) NOT LIKE LOWER(:excludedFlatName)")
    List<ResidentSocietyDetailDto> getSocietyListForResident_old(@Param("ownerEmail") String ownerEmail,
                                                                     @Param("excludedSocietyName") String excludedSocietyName,
                                                                     @Param("excludedBlockName") String excludedBlockName,
                                                                     @Param("excludedFlatName") String excludedFlatName);
    @Query("SELECT r FROM Resident r " +
            "INNER JOIN r.society s " +
            "INNER JOIN r.apartment a " +
            "INNER JOIN r.area ar " +
            "WHERE (r.ownerEmail = :email OR r.tenantEmail = :email) " +
            "AND r.isDelete = false " +
            "AND a.isDelete = false " +
            "AND s.isDelete = false " +
            "AND LOWER(s.societyName) NOT LIKE LOWER(:excludedSocietyName) " +
            "AND LOWER(a.block) NOT LIKE LOWER(:excludedBlockName) " +
            "AND LOWER(a.flat) NOT LIKE LOWER(:excludedFlatName)")
    List<Resident> getSocietyListForResident(
            @Param("email") String email,
            @Param("excludedSocietyName") String excludedSocietyName,
            @Param("excludedBlockName") String excludedBlockName,
            @Param("excludedFlatName") String excludedFlatName);

    @Query("SELECT r FROM Resident r " +
            "LEFT JOIN r.society s " +
            "LEFT JOIN r.apartment a " +
            "LEFT JOIN r.area ar " +
            "WHERE (r.ownerEmail = :email OR r.tenantEmail = :email) " +
            "AND r.isDelete = false " +
            "AND a.isDelete = false " +
            "AND s.isDelete = false " +
            "AND LOWER(s.societyName) NOT LIKE LOWER(:excludedSocietyName) " +
            "AND LOWER(a.block) NOT LIKE LOWER(:excludedBlockName) " +
            "AND LOWER(a.flat) NOT LIKE LOWER(:excludedFlatName)")
    List<Resident> getSocietyListForAdmin(
            @Param("email") String email,
            @Param("excludedSocietyName") String excludedSocietyName,
            @Param("excludedBlockName") String excludedBlockName,
            @Param("excludedFlatName") String excludedFlatName);


    List<String> findRolesByOwnerEmail(String ownerEmail);


    boolean existsByTenantEmailAndAreaAndApartmentAndSociety(
            String tenantEmail,
            Area area,
            Apartment apartment,
            Society society
    );
    boolean existsByOwnerEmailAndAreaAndApartmentAndSociety(
            String ownerEmail,
            Area area,
            Apartment apartment,
            Society society
    );
    List<Resident> findBySocietyId(long societyId);
    List<Resident> findBySocietyIdAndAreaId(long societyId,long areaId);
    List<Resident> findBySocietyIdAndApartmentId(long societyId,long apartmentId);

    @Query("SELECT r FROM Resident r WHERE r.society.id = :societyId " +
            "AND (:areaId = 1 OR r.area.id = :areaId) " +
            "AND (:apartmentId = 1 OR r.apartment.id = :apartmentId)")
    List<Resident> findResidentsBySocietyAndAreaAndApartment(@Param("societyId") long societyId,
                                 @Param("areaId") long areaId,
                                 @Param("apartmentId") long apartmentId);

    @Query("SELECT CASE " +
            "   WHEN UPPER(:targetAudience) = 'OWNERS' THEN r.ownerEmail " +
            "   WHEN UPPER(:targetAudience) = 'TENANTS' THEN r.tenantEmail " +
            "   WHEN UPPER(:targetAudience) = 'BOTH' THEN r.ownerEmail " +
            "END " +
            "FROM Resident r " +
            "WHERE r.society.id = :societyId " +
            "AND (:areaId = 1 OR r.area.id = :areaId) " +
            "AND (:apartmentId = 1 OR r.apartment.id = :apartmentId) " +
            "AND ((UPPER(:targetAudience) = 'OWNERS' AND r.ownerEmail IS NOT NULL AND TRIM(r.ownerEmail) <> '') " +
            "   OR (UPPER(:targetAudience) = 'TENANTS' AND r.tenantEmail IS NOT NULL AND TRIM(r.tenantEmail) <> '') " +
            "   OR (UPPER(:targetAudience) = 'BOTH' AND ((r.ownerEmail IS NOT NULL AND TRIM(r.ownerEmail) <> '') " +
            "       OR (r.tenantEmail IS NOT NULL AND TRIM(r.tenantEmail) <> ''))))"+
            "AND (LOWER(r.roles) LIKE '%resident%' OR COALESCE(TRIM(r.roles), '') = '')"
    )
    List<String> findResidentEmailsBySocietyAndAreaAndApartmentAndTargetAudience(@Param("societyId") long societyId,
                                    @Param("areaId") long areaId,
                                    @Param("apartmentId") long apartmentId,
                                    @Param("targetAudience") String targetAudience);

    @Query(value = "SELECT DISTINCT email FROM ( " +
            "   SELECT r.owner_email AS email " +
            "   FROM residents r " +
            "   WHERE r.society_id = :societyId " +
            "   AND (:areaId = 1 OR r.area_id = :areaId) " +
            "   AND (:apartmentId = 1 OR r.apartment_id = :apartmentId) " +
            "   AND ((UPPER(:targetAudience) = 'OWNERS' AND r.owner_email IS NOT NULL AND TRIM(r.owner_email) <> '') " +
            "       OR (UPPER(:targetAudience) = 'BOTH' AND r.owner_email IS NOT NULL AND TRIM(r.owner_email) <> ''))) " +
            "   AND (LOWER(r.roles) LIKE '%resident%' OR COALESCE(TRIM(r.roles), '') = '') " +
            "   UNION " +
            "   SELECT r.tenant_email AS email " +
            "   FROM residents r " +
            "   WHERE r.society_id = :societyId " +
            "   AND (:areaId = 1 OR r.area_id = :areaId) " +
            "   AND (:apartmentId = 1 OR r.apartment_id = :apartmentId) " +
            "   AND ((UPPER(:targetAudience) = 'TENANTS' AND r.tenant_email IS NOT NULL AND TRIM(r.tenant_email) <> '') " +
            "       OR (UPPER(:targetAudience) = 'BOTH' AND r.tenant_email IS NOT NULL AND TRIM(r.tenant_email) <> ''))) " +
            "   AND (LOWER(r.roles) LIKE '%resident%' OR COALESCE(TRIM(r.roles), '') = '') " +
            ") AS emails",
            nativeQuery = true)
    List<String> findResidentEmailsBySocietyAndAreaAndApartmentAndTargetAudienceUnion(
            @Param("societyId") long societyId,
            @Param("areaId") long areaId,
            @Param("apartmentId") long apartmentId,
            @Param("targetAudience") String targetAudience
    );

    @Query("SELECT r.ownerEmail FROM Resident r " +
            "WHERE r.society.id = :societyId " +
            "AND (:areaId = 1 OR r.area.id = :areaId) " +
            "AND (:apartmentId = 1 OR r.apartment.id = :apartmentId) " +
            "AND UPPER(:targetAudience) IN ('OWNERS', 'BOTH') " +
            "AND r.ownerEmail IS NOT NULL AND TRIM(r.ownerEmail) <> ''" +
            "AND (LOWER(r.roles) LIKE '%resident%' OR COALESCE(TRIM(r.roles), '') = '')"
    )
    List<String> findOwnerEmailsForNoticeSend(
            @Param("societyId") long societyId,
            @Param("areaId") long areaId,
            @Param("apartmentId") long apartmentId,
            @Param("targetAudience") String targetAudience
    );

    @Query("SELECT r.tenantEmail FROM Resident r " +
            "WHERE r.society.id = :societyId " +
            "AND (:areaId = 1 OR r.area.id = :areaId) " +
            "AND (:apartmentId = 1 OR r.apartment.id = :apartmentId) " +
            "AND UPPER(:targetAudience) IN ('TENANTS', 'BOTH') " +
            "AND r.tenantEmail IS NOT NULL AND TRIM(r.tenantEmail) <> ''" +
            "AND (LOWER(r.roles) LIKE '%resident%' OR COALESCE(TRIM(r.roles), '') = '')"
    )
    List<String> findTenantEmailsForNoticeSend(
            @Param("societyId") long societyId,
            @Param("areaId") long areaId,
            @Param("apartmentId") long apartmentId,
            @Param("targetAudience") String targetAudience
    );
    List<Resident> findByAreaAndSocietyAndApartment(Area area, Society society,Apartment apartment);
    List<Resident> findByApartment(Apartment apartment);

    boolean existsByOwnerEmailAndApartmentAndAreaAndSociety(
            String email, Apartment apartment, Area area, Society society);

    boolean existsByTenantEmailAndApartmentAndAreaAndSociety(
            String email, Apartment apartment, Area area, Society society);

}