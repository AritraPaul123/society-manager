//package com.propertymanageruae.api.controllers.v1;
//
//import io.swagger.v3.oas.annotations.security.SecurityRequirement;
//import io.swagger.v3.oas.annotations.tags.Tag;
//import jakarta.servlet.http.HttpServletResponse;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.util.LinkedMultiValueMap;
//import org.springframework.util.MultiValueMap;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
//import org.springframework.web.util.UriComponentsBuilder;
//
//import java.io.IOException;
//import java.util.Map;
//
//@RestController
//@Tag(name = "OAuth", description = "Google OAuth 2.0 Integration")
//public class GoogleOAuthController {
//
//    @Value("${google.client-id}")
//    private String clientId;
//
//    @Value("${google.client-secret}")
//    private String clientSecret;
//
//    @Value("${google.redirect-uri}")
//    private String redirectUri; // e.g. http://localhost:5001/oauth2/callback
//
//    private final RestTemplate rest = new RestTemplate();
//
//    /**
//     *
//     *
//     * https://accounts.google.com/o/oauth2/v2/auth?
//     *  scope=https://mail.google.com/&
//     *  access_type=offline&
//     *  include_granted_scopes=true&
//     *  response_type=code&
//     *  redirect_uri=http://localhost:5001/oauth2/callback&
//     *  client_id=463649430597-i0h95i5m27s296jf2hoa1nq8ceb4c8gr.apps.googleusercontent.com
//     */
//    // Optional helper to open the consent screen
//    @GetMapping("/start-oauth")
//    public void startOauth(HttpServletResponse resp) throws IOException {
//        String url = UriComponentsBuilder.fromHttpUrl("https://accounts.google.com/o/oauth2/v2/auth")
//                .queryParam("scope", "https://mail.google.com/")
//                .queryParam("access_type", "offline")
//                .queryParam("include_granted_scopes", "true")
//                .queryParam("response_type", "code")
//                .queryParam("redirect_uri", redirectUri)
//                .queryParam("client_id", clientId)
//                .queryParam("prompt", "consent")
//                .build().toUriString();
//        resp.sendRedirect(url);
//    }
//
//    // Callback that receives ?code=...
//    @GetMapping("/oauth2/callback")
//    public ResponseEntity<?> oauthCallback(@RequestParam(name="code", required=false) String code,
//                                           @RequestParam(name="error", required=false) String error) {
//        if (error != null) {
//            return ResponseEntity.badRequest().body("OAuth error: " + error);
//        }
//        if (code == null) {
//            return ResponseEntity.badRequest().body("Missing code");
//        }
//
//        // Exchange code for tokens
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//
//        MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
//        body.add("code", code);
//        body.add("client_id", clientId);
//        body.add("client_secret", clientSecret);
//        body.add("redirect_uri", redirectUri);
//        body.add("grant_type", "authorization_code");
//
//        HttpEntity<MultiValueMap<String,String>> request = new HttpEntity<>(body, headers);
//        Map<String,Object> resp = rest.postForObject("https://oauth2.googleapis.com/token", request, Map.class);
//
//        // resp will contain access_token, expires_in, refresh_token (if requested)
//        // IMPORTANT: Save refresh_token securely (env var / DB / secrets manager) — DO NOT commit to source control
//        return ResponseEntity.ok(resp);
//    }
//
//    public String getAccessTokenFromRefreshToken(String refreshToken) {
//        RestTemplate rest = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//
//        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
//        body.add("client_id", clientId);
//        body.add("client_secret", clientSecret);
//        body.add("refresh_token", refreshToken);
//        body.add("grant_type", "refresh_token");
//
//        HttpEntity<MultiValueMap<String,String>> req = new HttpEntity<>(body, headers);
//        Map<String,Object> resp = rest.postForObject("https://oauth2.googleapis.com/token", req, Map.class);
//
//        return (String) resp.get("access_token");
//    }
//
//}