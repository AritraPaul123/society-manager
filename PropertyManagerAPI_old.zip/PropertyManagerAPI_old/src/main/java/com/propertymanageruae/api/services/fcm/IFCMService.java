package com.propertymanageruae.api.services.fcm;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.token.FCMTokenResponse;
import com.propertymanageruae.api.payloads.token.FcmTokenRequest;
import com.propertymanageruae.api.payloads.token.FcmTokenUpdateRequest;
import com.propertymanageruae.api.payloads.token.FcmUnregisterRequest;
import org.springframework.stereotype.Service;

import java.util.List;


public interface IFCMService {
   FCMTokenResponse saveFcmToken(FcmTokenRequest request) throws IllegalArgumentException;
   FCMTokenResponse updateFcmToken(FcmTokenUpdateRequest request);
   void unregisterFcmToken(FcmUnregisterRequest request);
   void sendNotificationToUserId(Long userId, String title, String body) throws FirebaseMessagingException;
   void sendNotificationToUsers(List<User> users, String title, String body)
           throws FirebaseMessagingException;
}