package com.propertymanageruae.api.services.ExternalService;

import com.propertymanageruae.api.payloads.ExternalDTO.MailDto;
import com.propertymanageruae.api.payloads.ExternalDTO.WelcomeEmailDto;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public interface IGmailOAuthService {
    /**
     * Send email with MailDto request
     * @param request MailDto containing email details
     * @return CompletableFuture<Boolean> indicating success/failure
     */
    CompletableFuture<Boolean> sendEmail(MailDto request);

    /**
     * Send welcome email to new users
     * @param welcomeEmail WelcomeEmailDto containing user details
     * @return CompletableFuture<Boolean> indicating success/failure
     */
    CompletableFuture<Boolean> sendWelcomeEmail(WelcomeEmailDto welcomeEmail);

    /**
     * Send bulk emails with attachments in batches
     * @param recipients List of email recipients
     * @param name Email subject/name
     * @param description Email body/description
     * @param files List of files to attach
     */
    void sendBulkEmail(List<String> recipients, String name, String description, List<MultipartFile> files);

    /**
     * Simple method to send OAuth email
     * @param to Recipient email address
     * @param subject Email subject
     * @param bodyText Email body in HTML format
     * @throws Exception if sending fails
     */
    void sendMailOAuth(String to, String subject, String bodyText) throws Exception;
}