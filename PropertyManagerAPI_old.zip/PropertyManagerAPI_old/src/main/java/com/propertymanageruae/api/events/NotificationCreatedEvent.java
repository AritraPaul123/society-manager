package com.propertymanageruae.api.events;
import com.propertymanageruae.api.payloads.notification.NotificationDto;

public class NotificationCreatedEvent {
    private final NotificationDto notification;

    public NotificationCreatedEvent(NotificationDto notification) {
        this.notification = notification;
    }

    public NotificationDto getNotification() {
        return notification;
    }
}