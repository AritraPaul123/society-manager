package com.propertymanageruae.api.specificaions;
import com.propertymanageruae.api.entities.HomeInspection;

import org.springframework.data.jpa.domain.Specification;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class HomeInspectionSpecification {

    public static Specification<HomeInspection> hasSocietyId(long societyId) {
        return (root, query, cb) -> cb.equal(root.get("societyId"), societyId);
    }


    public static Specification<HomeInspection> hasStatus(int status) {
        return (root, query, cb) -> cb.equal(root.get("status"), status);
    }

    public static Specification<HomeInspection> searchByText(String searchText) {
        return (root, query, criteriaBuilder) -> {
            if (searchText == null || searchText.trim().isEmpty()) {
                return criteriaBuilder.conjunction();
            }
            String searchPattern = "%" + searchText.toLowerCase() + "%";
            return criteriaBuilder.or(
                    criteriaBuilder.like(criteriaBuilder.lower(root.get("flat")), searchPattern)
            );
        };
    }

    public static Specification<HomeInspection> inDateRange(String dateRange) {
        return (root, query, cb) -> {
            if (dateRange == null || dateRange.isBlank()) return cb.conjunction();

            String[] dates = dateRange.split(",");
            if (dates.length != 2) return cb.conjunction();

            LocalDate start = LocalDate.parse(dates[0].trim());
            LocalDate end = LocalDate.parse(dates[1].trim());

            // Convert to LocalDateTime
            LocalDateTime startDateTime = start.atStartOfDay();
            LocalDateTime endDateTime = end.atTime(23, 59, 59);

            return cb.between(root.get("createdAt"), startDateTime, endDateTime);
        };
    }



}
