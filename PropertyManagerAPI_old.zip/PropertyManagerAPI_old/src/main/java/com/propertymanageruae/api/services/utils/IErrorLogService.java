package com.propertymanageruae.api.services.utils;

public interface IErrorLogService {
    /**
     * Save an exception and return the generated error code (UUID).
     */
    String saveException(Throwable ex, String requestUri);
    /**
     * Cleanup logs older than given timestamp
     */
    void deleteLogsOlderThan(java.sql.Timestamp ts);
}