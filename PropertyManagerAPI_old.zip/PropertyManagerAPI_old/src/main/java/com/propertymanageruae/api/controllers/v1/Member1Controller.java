package com.propertymanageruae.api.controllers.v1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.propertymanageruae.api.helper.UnitHelper;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.location.LocationDTO;
import com.propertymanageruae.api.payloads.member.AddMemberDto;
import com.propertymanageruae.api.payloads.member.MemberRevokeDto;
import com.propertymanageruae.api.payloads.member.UpdateMemberDto;
import com.propertymanageruae.api.payloads.member.ViewMemberDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v${api.version}/member")
@SecurityRequirement(name = "auth")
@Tag(name = "Members")
public class Member1Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Value("${app.member.password}")
    private String password;
    @Autowired
    private UnitService _unitService;
    @Autowired
    private UnitHelper _unitHelper;

    @Operation(summary = "Add new Member")
    @PostMapping("/add-member")
    public ResponseEntity<ApiResponse<String>> addMember(@Valid @RequestBody AddMemberDto addMemberDto) throws SQLIntegrityConstraintViolationException {
        addMemberDto.setPassword(password);
        String msg = this._unitService.memberService.addMember(addMemberDto);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, "Member added successfully", null, HttpStatus.CREATED.value()));
        }
    }

    @Operation(summary = "Add new Member with Profile")
    @PostMapping(value = "/add-member-with-profile",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<String>> addMemberWithProfile(@RequestPart("user") AddMemberDto addMemberDto,@RequestPart(value = "profileImage", required = false) MultipartFile profileImage) throws SQLIntegrityConstraintViolationException {
        addMemberDto.setPassword(password);
        String msg = this._unitService.memberService.addMemberWithProfile(addMemberDto,profileImage);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, "Member added successfully", null, HttpStatus.CREATED.value()));
        }
    }

    @Operation(description = "Get endpoint for members", summary = "This is summary for member get endpoint")
    @GetMapping("/all-member/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewMemberDto>>> getMembers(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(value = "searchText", required = false) String searchText,
            @PathVariable("societyId") long societyId
    ) throws JsonProcessingException {
        PaginationDto<ViewMemberDto> memberDTOs = this._unitService.memberService.getMembers(pageNumber, pageSize, sortBy, sortDir, searchText, societyId);
        List<ViewMemberDto> memberDto = memberDTOs.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", memberDTOs.getPageSize());
        metadata.put("PageNumber", memberDTOs.getPageNumber());
        metadata.put("TotalPages", memberDTOs.getTotalPages());
        metadata.put("TotalElements", memberDTOs.getTotalElements());
        metadata.put("IsFirstPage", memberDTOs.isFirstPage());
        metadata.put("IsLastPage", memberDTOs.isLastPage());

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(memberDto, "Members retrieved successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Get a Member by ID")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ViewMemberDto>> getMember(@PathVariable("id") int id) {
        ViewMemberDto memberDTO = this._unitService.memberService.getMember(id);
        return ResponseEntity.ok(
                ApiResponse.success(memberDTO, "Member retrieved successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Update existing Member")
    @PutMapping("/edit-member/{id}")
    public ResponseEntity<ApiResponse<String>> editMember(@Valid @RequestBody UpdateMemberDto updateMemberDto, @PathVariable("id") int id) throws SQLIntegrityConstraintViolationException {
        updateMemberDto.setPassword(password);
        String msg = this._unitService.memberService.updateMember(updateMemberDto, id);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.success(null, "Member updated successfully", null, HttpStatus.OK.value()));
        }
    }

    @Operation(summary = "Update existing Member with Profile")
    @PutMapping(value = "/edit-member-with-profile/{id}",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<String>> editMemberWithProfile(@RequestPart("user") UpdateMemberDto updateMemberDto, @PathVariable("id") int id,@RequestPart(value = "profileImage", required = false) MultipartFile profileImage) throws SQLIntegrityConstraintViolationException, IOException {
        updateMemberDto.setPassword(password);
        String msg = this._unitService.memberService.updateMemberWithProfile(updateMemberDto, id,profileImage);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.success(null, "Member updated successfully", null, HttpStatus.OK.value()));
        }
    }

    @Operation(summary = "Delete existing Member")
    @PutMapping("/delete-member/{id}/{societyId}")
    public ResponseEntity<ApiResponse<Void>> deleteMember(@PathVariable("id") int id,@PathVariable("societyId") int societyId) throws Exception {
        this._unitService.memberService.softDeleteMember(id,societyId);
        return ResponseEntity.ok(
                ApiResponse.success(null, "Member deleted successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Member")
    @GetMapping("/member-list/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewMemberDto>>> getAllMembers(@RequestParam(value = "roleId", required = false) Long roleId, @PathVariable("societyId") long societyId) {
        List<ViewMemberDto> viewMemberDtoList = this._unitService.memberService.getAllUser(roleId, societyId);
        return ResponseEntity.ok(
                ApiResponse.success(viewMemberDtoList, "All member fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Location")
    @GetMapping("/locations")
    public ResponseEntity<ApiResponse<List<LocationDTO>>> getAllLocation() {
        List<LocationDTO> locationDTOS = this._unitService.memberService.getAllLocation();
        return ResponseEntity.ok(
                ApiResponse.success(locationDTOS, "All location fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Role")
    @GetMapping("/roles")
    public ResponseEntity<ApiResponse<List<RoleDTO>>> getAllUserRole() {
        List<RoleDTO> roles = this._unitService.memberService.getAllUserRole();
        return ResponseEntity.ok(
                ApiResponse.success(roles, "All roles fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Fetched All Role By SocietyId")
    @GetMapping("/roles/{societyId}")
    public ResponseEntity<ApiResponse<List<RoleDTO>>> getAllUserRoleBySocietyId(@PathVariable long societyId) {
        List<RoleDTO> roles = this._unitService.memberService.getAllUserRole(societyId);
        return ResponseEntity.ok(
                ApiResponse.success(roles, "All roles fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Update Member Status")
    @PatchMapping("/{memberId}/revoke")
    public ResponseEntity<ApiResponse<String>> updateComplaintStatus(
            @PathVariable Long memberId,
            @Valid @RequestBody MemberRevokeDto statusUpdateDTO) {
        String complaintDto = this._unitService.memberService.revokeMember(memberId, statusUpdateDTO);
        String msg = !statusUpdateDTO.isRevoked() ? "Revoked Access successfully!" : "Grant Access Successfully!";
        if (complaintDto != null) {
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, msg, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(ApiResponse.success(null, "Member status Not Updated", null, HttpStatus.BAD_REQUEST.value()));
        }
    }

    @Operation(description = "Get endpoint for resident as member", summary = "This is summary for resident as member get endpoint")
    @GetMapping("/all-member-as-resident/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewMemberDto>>> getMembersAsResident(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(value = "searchText", required = false) String searchText,
            @PathVariable("societyId") long societyId
    ) throws JsonProcessingException {
        PaginationDto<ViewMemberDto> memberDTOs = this._unitService.memberService.getMembersFromResident(pageNumber, pageSize, sortBy, sortDir, searchText, societyId);
        List<ViewMemberDto> memberDto = memberDTOs.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", memberDTOs.getPageSize());
        metadata.put("PageNumber", memberDTOs.getPageNumber());
        metadata.put("TotalPages", memberDTOs.getTotalPages());
        metadata.put("TotalElements", memberDTOs.getTotalElements());
        metadata.put("IsFirstPage", memberDTOs.isFirstPage());
        metadata.put("IsLastPage", memberDTOs.isLastPage());
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(memberDto, "Members retrieved successfully", null, HttpStatus.OK.value())
        );
    }
}