package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.attendance.AttendanceDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.AttendanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/api/v${api.version}/attendance")
@SecurityRequirement(name = "auth")
@Tag(name = "Attendance")
public class Attendance1Controller {

    @Value("${api.version}")
    private String apiVersion;

    @Autowired
    private AttendanceService attendanceService;

    @Operation(summary = "Check In Staff")
    @PostMapping("/check-in")
    public ResponseEntity<ApiResponse<AttendanceDto>> checkIn(
            @RequestParam Long userId,
            @RequestParam String location,
            @RequestParam(required = false) String photoUrl) {
        
        AttendanceDto attendanceDto = attendanceService.checkIn(userId, location, photoUrl);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(attendanceDto, "Check-in successful", null, HttpStatus.CREATED.value()));
    }

    @Operation(summary = "Check Out Staff")
    @PostMapping("/check-out/{attendanceId}")
    public ResponseEntity<ApiResponse<AttendanceDto>> checkOut(@PathVariable Long attendanceId) {
        AttendanceDto attendanceDto = attendanceService.checkOut(attendanceId);
        return ResponseEntity.ok(ApiResponse.success(attendanceDto, "Check-out successful", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Get User Attendance History")
    @GetMapping("/user/{userId}")
    public ResponseEntity<ApiResponse<List<AttendanceDto>>> getUserHistory(@PathVariable Long userId) {
        List<AttendanceDto> history = attendanceService.getAttendanceHistory(userId);
        return ResponseEntity.ok(ApiResponse.success(history, "Attendance history fetched", null, HttpStatus.OK.value()));
    }
    
    @Operation(summary = "Get All Attendance")
    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<AttendanceDto>>> getAllAttendance() {
        List<AttendanceDto> all = attendanceService.getAllAttendance();
        return ResponseEntity.ok(ApiResponse.success(all, "All attendance records fetched", null, HttpStatus.OK.value()));
    }
}
