package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.helper.UnitHelper;
import com.propertymanageruae.api.payloads.inspection.*;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v${api.version}/inspection")
@SecurityRequirement(name = "auth")
@Tag(name = "home-Inspection")
public class HomeInspection1Controller {

    @Value("${api.version}")
    private String apiVersion;
    private final UnitHelper _unitHelper;
    private final UnitService _unitService;

    @Operation(summary = "Create home inspection for (Mobile only)")
    @PostMapping("/create-inspection")
    public ResponseEntity<ApiResponse<String>> createInspection(@Valid @RequestBody HomeInspectionDTO inspectionDTO) throws SQLIntegrityConstraintViolationException {
        String msg = _unitService.homeInspectionService.createInspection(inspectionDTO);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, AppConstants.Message.SAVED, null, HttpStatus.CREATED.value()));
        }

    }
    @Operation(summary = "Edit home inspection for (Mobile only)")
    @PutMapping("/edit-inspection/{id}")
    public ResponseEntity<ApiResponse<ViewHomeInspectionDTO>> editInspection(
            @Valid @RequestBody HomeInspectionDTO homeInspectionDTO,
            @PathVariable("id") long id) throws SQLIntegrityConstraintViolationException {

        ViewHomeInspectionDTO updatedDTO = _unitService.homeInspectionService.editInspection(homeInspectionDTO, id);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponse.success(updatedDTO, AppConstants.Message.UPDATED, null, HttpStatus.OK.value()));

    }

    @Operation(summary = "Final-submit data for home inspection (Mobile only)")
    @PutMapping("/final-submit/{inspectionId}")
    public ResponseEntity<ApiResponse<ViewHomeInspectionDTO>> finalSubmit(@Valid @RequestBody InspectionFinalRequest request, @PathVariable("inspectionId") long inspectionId) throws SQLIntegrityConstraintViolationException {
        ViewHomeInspectionDTO finalDTO = _unitService.homeInspectionService.finalSubmit(request, inspectionId);
        return ResponseEntity.status(HttpStatus.OK).body(ApiResponse.success(finalDTO, AppConstants.Message.SUCCESS, null, HttpStatus.OK.value()));

    }

    @GetMapping("/all-inspections/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewHomeInspectionDTO>>> getInspectionsBySociety(
            @PathVariable Long societyId,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "dateRange", required = false) String dateRange
    ) throws SQLIntegrityConstraintViolationException {
        List<ViewHomeInspectionDTO> list = _unitService.homeInspectionService.getAllInspections(societyId,searchText,dateRange);
        return ResponseEntity.ok(ApiResponse.success(list, "Data fetch successfully", null, HttpStatus.OK.value()));

    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<List<ViewInspectionSectionDTO>>> getInspectionById(@PathVariable long id) throws SQLIntegrityConstraintViolationException {
        List<ViewInspectionSectionDTO> inspectionSection = _unitService.iInspectionSectionService.getSectionsByInspectionId(id);
        return ResponseEntity.ok(ApiResponse.success(inspectionSection, "Data fetch successfully", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Create inspection Section for (Mobile only)")
    @PostMapping("/create-section")
    public ResponseEntity<ApiResponse<String>> createSection(@Valid @RequestBody InspectionSectionDTO sectionDTO) throws SQLIntegrityConstraintViolationException {
        String msg = _unitService.iInspectionSectionService.createSection(sectionDTO);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, AppConstants.Message.SAVED, null, HttpStatus.CREATED.value()));
        }

    }



    @Operation(summary = "Add new image for inspection section (Mobile only)")
    @PostMapping(value = "/upload-image/{inspectionId}/{sectionId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<String>> uploadImages(@Valid @PathVariable("inspectionId") long inspectionId, @PathVariable("sectionId") long sectionId,@RequestPart("amount") String amount, @RequestPart("description") String description, @RequestPart(value = "file", required = false) MultipartFile file) throws IOException {
            SectionImageDTO dto = SectionImageDTO.builder()
                .amount(amount)
                .sectionId(sectionId)
                .inspectionId(inspectionId)
                .description(description)
                .build();
        String msg = _unitService.homeInspectionService.uploadSectionImage(dto, file);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, AppConstants.Message.FILE_UPLOADED, null, HttpStatus.CREATED.value()));
        }
    }

    @GetMapping(value = "/file/{imageName}", produces = MediaType.IMAGE_JPEG_VALUE)
    public void downloadImage(@PathVariable("imageName") String imageName, HttpServletResponse httpServletResponse) throws IOException {
        InputStream resource = this._unitHelper.s3FileHandler.getResource(imageName);
        httpServletResponse.setContentType(MediaType.IMAGE_JPEG_VALUE);
        StreamUtils.copy(resource, httpServletResponse.getOutputStream());
    }
    @GetMapping("/inspection-pdf/{inspectionId}")
    public ResponseEntity<byte[]> generateInspectionPDF(@PathVariable("inspectionId") long inspectionId) throws Exception {
        byte[] pdfBytes = _unitService.homeInspectionService.generateInspectionPDF(inspectionId);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDispositionFormData("attachment", "inspection_" + inspectionId + ".pdf");
        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
    }






}
