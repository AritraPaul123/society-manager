package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.AssignmentType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IAssignmentTypeRepository extends JpaRepository<AssignmentType, Long> {
}