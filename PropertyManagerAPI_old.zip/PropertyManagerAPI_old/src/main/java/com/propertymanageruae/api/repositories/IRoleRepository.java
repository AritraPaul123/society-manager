package com.propertymanageruae.api.repositories;


import com.propertymanageruae.api.entities.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IRoleRepository extends JpaRepository<Role, Long> {
    List<Role> findByIdNot(Long id);

    List<Role> findByIdNotIn(List<Long> ids);

    Long findIdByTitle(String title);

    Role findByTitle(String title);

}