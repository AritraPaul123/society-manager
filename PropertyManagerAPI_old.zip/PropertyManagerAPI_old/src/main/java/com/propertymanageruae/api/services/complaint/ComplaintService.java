package com.propertymanageruae.api.services.complaint;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.enums.NotificationType;
import com.propertymanageruae.api.exceptions.InvalidOperationException;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.FileHandler;
import com.propertymanageruae.api.helper.S3FileHandler;
import com.propertymanageruae.api.payloads.complaint.AddComplaintDTO;
import com.propertymanageruae.api.payloads.complaint.ComplaintFilterDto;
import com.propertymanageruae.api.payloads.complaint.ComplaintStatusUpdateDto;
import com.propertymanageruae.api.payloads.complaint.ViewComplaintDto;
import com.propertymanageruae.api.payloads.user.ViewUserDto;
import com.propertymanageruae.api.payloads.utils.FileDTO;
import com.propertymanageruae.api.repositories.*;
import com.propertymanageruae.api.services.notification.INotificationService;
import com.propertymanageruae.api.services.user.CustomUserDetailService;
import com.propertymanageruae.api.specificaions.ComplaintSpecification;
import com.propertymanageruae.api.specificaions.UserSpecification;
import jakarta.transaction.Transactional;
import org.hibernate.service.spi.ServiceException;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ComplaintService implements IComplaintService {
    private static final Logger logger = LoggerFactory.getLogger(ComplaintService.class);
    private static final long MAX_FILE_SIZE = 200 * 1024; // 200KB
    private static final List<String> ALLOWED_FILE_TYPES = List.of("image/jpeg", "image/png");

    @Autowired
    private IComplaintRepository complaintRepository;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private ICategoryRepository categoryRepository;
    @Autowired
    private ISubCategoryRepository subCategoryRepository;
    @Autowired
    private ILocationRepository locationRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private IFileEntityRepository fileEntityRepository;
    @Value("${server.port}")
    private String serverPort;
    @Autowired
    private IFileRepository fileRepository;
    @Autowired
    private FileHandler fileHandler;
    @Autowired
    private S3FileHandler s3FileHandler;
    @Autowired
    private CustomUserDetailService customUserDetailService;
    @Autowired
    private ISocietyRepository societyRepository;
    @Autowired
    private IResidentRepository residentRepository;
    @Autowired
    private IAreaRepository areaRepository;
    @Autowired
    private IApartmentRepository apartmentRepository;

    @Autowired
    private INotificationService _notificationService;


    @Transactional
    @Override
    public ViewComplaintDto addComplaint(AddComplaintDTO complaintDTO, List<MultipartFile> files) throws IOException {
        long loggedInUserId = this.customUserDetailService.LoggedInUser().getId();
        long complainerId = 0L;
        if (complaintDTO.getComplainerId() == 0L) {
            complainerId = loggedInUserId;
        } else {
            complainerId = complaintDTO.getComplainerId();
        }
        Society society = this.societyRepository.findById(complaintDTO.getSocietyId()).orElseThrow(() -> new ResourceNotFoundException("Society No found"));
        Category category = categoryRepository.findById(complaintDTO.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", complaintDTO.getCategoryId() + ""));
        User stuff = null;
        if (complaintDTO.getStuffId() != null) {
            stuff = userRepository.findById(complaintDTO.getStuffId())
                    .orElseThrow(() -> new ResourceNotFoundException("Stuff", "id", complaintDTO.getStuffId() + ""));
        }
        User complainer = userRepository.findById(complainerId)
                .orElseThrow(() -> new ResourceNotFoundException("Complainer", "id", loggedInUserId + ""));
        Location location = locationRepository.findById(complaintDTO.getLocationId())
                .orElseThrow(() -> new ResourceNotFoundException("Location", "id", complaintDTO.getLocationId() + ""));
        SubCategory subCategory = null;
        if (complaintDTO.getSubCategoryId() != null) {
            subCategory = subCategoryRepository.findById(complaintDTO.getSubCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("SubCategory", "id", complaintDTO.getSubCategoryId() + ""));

            if (subCategory.getCategory().getId() != category.getId()) {
                throw new ServiceException("This Sub Category is not belongs to selected sub category");
            }
        }
        Complaint complaint = this.modelMapper.map(complaintDTO, Complaint.class);
        complaint.setSociety(society);
        complaint.setCategory(category);
        complaint.setComplainer(complainer);
        if (complaintDTO.getAreaId() != 0) complaint.setAreaId(complaintDTO.getAreaId());
        if (complaintDTO.getApartmentId() != 0) complaint.setApartmentId(complaintDTO.getApartmentId());
        if (stuff != null) {
            complaint.setAssignedUser(stuff);
        }

        long apId = complaintDTO.getApartmentId();
        if (apId != 0) {
            Apartment apartment = this.apartmentRepository.findById(apId).orElse(null);
            assert apartment != null;
            location.setLocationData(apartment.getFlat());
            complaint.setLocation(location);
        } else {
            complaint.setLocation(location);
        }

        complaint.setSubCategory(subCategory);
        List<FileEntity> fileEntityList = fileUpload(files, complaint);
        complaint.setComplaintImages(fileEntityList);
        Integer lastNumber = complaintRepository.findLastTicketNumberBySociety(society.getId());

        int nextNumber = (lastNumber == null) ? 1 : lastNumber + 1;

        // Generate ticket like #MW-1
        String ticketId = "#" + society.getSocietyCode() + "-" + nextNumber;
        complaint.setTicketId(ticketId);
        Complaint savedComplaint = complaintRepository.save(complaint);
        return this.modelMapper.map(savedComplaint, ViewComplaintDto.class);
    }

    @Transactional
    @Override
    public ViewComplaintDto updateComplaintStatus(Long complaintId, ComplaintStatusUpdateDto statusUpdateDTO) throws FirebaseMessagingException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserEmail = authentication.getName();
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint", "id", complaintId.toString()));
        //region
//        if (!complaint.getComplainer().getEmail().equals(currentUserEmail)) {
//            throw new AuthException("You are not authorized to update the status of this complaint.");
//        }
        //endregion
        if ("closed".equalsIgnoreCase(complaint.getTicketStatus()) || "resolved".equalsIgnoreCase(complaint.getTicketStatus())) {
            throw new InvalidOperationException("Cannot update the  of a closed or resolved complaint.");
        }

        String oldStatus = complaint.getTicketStatus();

        if (statusUpdateDTO.getTicketStatus() != null) {
            complaint.setTicketStatus(statusUpdateDTO.getTicketStatus());
            if ("RESOLVED".equalsIgnoreCase(statusUpdateDTO.getTicketStatus())) {
                complaint.setResolvedTime(LocalDateTime.now());
            } else if ("CLOSED".equalsIgnoreCase(statusUpdateDTO.getTicketStatus())) {
                complaint.setClosedTime(LocalDateTime.now());
            }
        }


        if (statusUpdateDTO.getStuffId() != null && statusUpdateDTO.getStuffId() != 0) {
            User stuff = null;
            stuff = this.userRepository.findById(statusUpdateDTO.getStuffId())
                    .orElseThrow(() -> new ResourceNotFoundException("Stuff", "id", statusUpdateDTO.getStuffId() + ""));
            if (stuff != null) {
                complaint.setAssignedUser(stuff);
            }
        }
        if (statusUpdateDTO.getCategoryId() != null && statusUpdateDTO.getCategoryId() != 0) {
            Category cat = null;
            cat = this.categoryRepository.findById(statusUpdateDTO.getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", statusUpdateDTO.getCategoryId() + ""));
            if (cat != null) {
                complaint.setCategory(cat);
            }
        }
        if ((statusUpdateDTO.getAreaId() != null && statusUpdateDTO.getAreaId() != 0) &&
                (statusUpdateDTO.getApartmentId() != null && statusUpdateDTO.getApartmentId() != 0)) {
            Area area = null;
            area = this.areaRepository.findById(statusUpdateDTO.getAreaId())
                    .orElseThrow(() -> new ResourceNotFoundException("Area", "id", statusUpdateDTO.getAreaId() + ""));
            Apartment apartment = null;
            apartment = this.apartmentRepository.findById(statusUpdateDTO.getApartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Apartment", "id", statusUpdateDTO.getApartmentId() + ""));
            if (area != null && apartment != null) {
                complaint.setAreaId(area.getId());
                complaint.setApartmentId(apartment.getId());
            }
        }
        if (statusUpdateDTO.getLocationId() != null && statusUpdateDTO.getLocationId() != 0) {
            Location loc = null;
            loc = this.locationRepository.findById(statusUpdateDTO.getLocationId())
                    .orElseThrow(() -> new ResourceNotFoundException("Location", "id", statusUpdateDTO.getLocationId() + ""));
            if (loc != null) {
                complaint.setLocation(loc);
            }
        }
        if (statusUpdateDTO.getPriority() != null) {
            complaint.setPriority(statusUpdateDTO.getPriority());
        }
        if (statusUpdateDTO.getComplaintVisibility() != null) {
            complaint.setComplaintVisibility(statusUpdateDTO.getComplaintVisibility());
        }
        Complaint com = complaintRepository.save(complaint);

        // After complaint saved and you want to notify
        Specification<User> spec = Specification
                .where(UserSpecification.hasSocietyOrMaster(com.getSociety().getId(),1L))
                .and(UserSpecification.hasRoleIds(List.of(1L, 2L, 3L)))
                .and(UserSpecification.isUserActive())
                .and(UserSpecification.isMappingActive());

        List<Long> userIds = userRepository.findAll(spec)
                .stream()
                .map(User::getId)
                .collect(Collectors.toList());

        // ADD COMPLAINER USER ID
        if (com.getComplainer() != null && !com.getComplainer().isDelete()) {
            Long complainerId = com.getComplainer().getId();
            if (!userIds.contains(complainerId)) {
                userIds.add(complainerId);
            }
        }

        if (statusUpdateDTO.getTicketStatus() != null) {
            _notificationService.createAndPublishToUsers(
                    userIds,
                    "Complaint Status Updated",
                    String.format("Your complaint #%d has been marked as %s", com.getId(), com.getTicketStatus()),
                    NotificationType.COMPLAINT_STATUS_CHANGED
            );
        }
        if (statusUpdateDTO.getStuffId() != null && statusUpdateDTO.getStuffId() != 0) {
            _notificationService.createAndPublish(
                    com.getAssignedUser().getId(),
                    "Complaint Assignment",
                    String.format("Complaint #%d has been assigned to you", com.getId()),
                    NotificationType.COMPLAINT_ASSIGNED
            );
        }
        return this.modelMapper.map(com, ViewComplaintDto.class);
    }

    @Transactional
    @Override
    public void deleteComplaint(long id) throws IOException {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint", "id", Long.toString(id)));
        List<FileEntity> associatedFiles = complaint.getComplaintImages();
        if (associatedFiles != null && !associatedFiles.isEmpty()) {
            for (FileEntity file : associatedFiles) {
//                fileHandler.deleteFile(file.getFilePath(), file.getFileName());
                s3FileHandler.deleteFile(file.getFileName());
                fileEntityRepository.delete(file);
            }
        }
        complaintRepository.delete(complaint);
    }

    @Async
    private List<FileEntity> fileUpload(List<MultipartFile> files, Complaint complaint) throws IOException {
        String fileDownloadUri = "";
        List<FileEntity> fileEntityList = new ArrayList<>();
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (!file.isEmpty()) {
                    s3FileHandler.validateFile(file);
                    String uniqueFileName = s3FileHandler.storeFile(file);
//                    Path filePath = s3FileHandler.getFilePath(uniqueFileName);
                    URL filePath = s3FileHandler.getFilePath(uniqueFileName);
                    if (!uniqueFileName.isEmpty()) {
                        if (Objects.requireNonNull(file.getContentType()).equalsIgnoreCase(MediaType.APPLICATION_PDF_VALUE)) {
                            fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                                    .path("/api/v1/complaints/pdf/")
                                    .path(uniqueFileName)
                                    .toUriString();
                        } else {
                            fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                                    .path("/api/v1/complaints/image/")
                                    .path(uniqueFileName)
                                    .toUriString();
                        }
                    }
                    FileEntity fileEntity = FileEntity.builder()
                            .fileName(uniqueFileName)
                            .awsUrl(filePath.toString())
                            .filePath(filePath.toString())
                            .fileUrl(fileDownloadUri)
                            .fileSize(file.getSize())
                            .fileType(file.getContentType())
                            .fileCategory("COMPLAINT")
                            .complaint(complaint)
                            .build();
                    fileEntityList.add(fileEntity);
                }
            }

        }
        return fileEntityList;
    }

    @Override
    public List<ViewComplaintDto> getAllComplaints(ComplaintFilterDto filter, int offset, int limit, String sortBy, String sortDir, long societyId) {
        try {
            Sort sort = Sort.by(Sort.Direction.fromString(sortDir), sortBy);
            Specification<Complaint> baseSpecification = Specification
                    .where((root, query, builder) -> builder.and(
                            builder.equal(root.get("society").get("id"), societyId),
                            builder.isFalse(root.get("isDelete"))
                    ));
            Specification<Complaint> finalSpecification = baseSpecification.and(ComplaintSpecification.withFilters(filter));
            List<Complaint> complaints = complaintRepository.findAll(finalSpecification, sort);
            return complaints.stream()
                    .map(complaint -> {
                        ViewUserDto assigner = this.modelMapper.map(complaint.getAssignedUser(), ViewUserDto.class);
                        ViewUserDto complainer = this.modelMapper.map(complaint.getComplainer(), ViewUserDto.class);
                        ViewComplaintDto com = modelMapper.map(complaint, ViewComplaintDto.class);
                        com.setComplainer(complainer);
                        com.setAssignedUser(assigner);
                        return com;
                    })
                    .toList();
        } catch (Exception ex) {
            throw new ServiceException("An error occurred while fetching complaints", ex);
        }
    }

    @Override
    public ViewComplaintDto getComplaintById(long id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint", "id", id + ""));
        ViewUserDto assigner = this.modelMapper.map(complaint.getAssignedUser(), ViewUserDto.class);
        ViewUserDto complainer = this.modelMapper.map(complaint.getComplainer(), ViewUserDto.class);
        ViewComplaintDto com = modelMapper.map(complaint, ViewComplaintDto.class);
        com.setComplainer(complainer);
        com.setAssignedUser(assigner);
        return com;
    }

    public List<FileDTO> getAllFiles() {
        List<FileEntity> files = fileRepository.findAll();
        return files.stream().map(file -> {
            FileDTO dto = modelMapper.map(file, FileDTO.class);
            String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/")
                    .path(file.getFileName())
                    .toUriString();
            dto.setFileUrl(fileUrl);
            return dto;
        }).collect(Collectors.toList());
    }


    @Override
    public List<ViewComplaintDto> getAllComplaintsBySocietyAndApartment(ComplaintFilterDto filter, int offset, int limit, String sortBy, String sortDir, long societyId, long apartmentId) {
        try {
            Sort sort = Sort.by(Sort.Direction.fromString(sortDir), sortBy);
            Specification<Complaint> baseSpecification = Specification
                    .where((root, query, builder) -> builder.and(
                            builder.equal(root.get("society").get("id"), societyId),
                            builder.equal(root.get("apartmentId"), apartmentId),
                            builder.isFalse(root.get("isDelete"))
                    ));
            Specification<Complaint> finalSpecification = baseSpecification.and(ComplaintSpecification.withFilters(filter));
            List<Complaint> complaints = complaintRepository.findAll(finalSpecification, sort);
            List<ViewComplaintDto> viewComplaintDtos = complaints.stream()
                    .map(complaint -> modelMapper.map(complaint, ViewComplaintDto.class))
                    .toList();
//            return viewComplaintDtos.stream().map(complaint -> {
//                List<ViewCommentsDto> com=complaint.getComments().stream().map(commentMaster -> {
//                    if (commentMaster.getUserType().equalsIgnoreCase("User")) {
//                        User u = this.userRepository
//                                .findById(commentMaster.getCommentBy())
//                                .orElseThrow(() -> new ResourceNotFoundException("User Not Found"));
//                        Person p = Person.builder().name(u.getName()).id(u.getId()).email(u.getEmail()).build();
//                        commentMaster.setPerson(p);
//                    } else if (commentMaster.getUserType().equalsIgnoreCase("Resident")) {
//                        Resident r = this.residentRepository
//                                .findById(commentMaster.getCommentBy())
//                                .orElseThrow(() -> new ResourceNotFoundException("Resident Not Found"));
//                        Person p = Person.builder().name(r.getOwnerName()).id(r.getId()).email(r.getOwnerEmail()).build();
//                        commentMaster.setPerson(p);
//                    }
//                    return commentMaster;
//                }).toList();
//                complaint.setComments(com);
//                return complaint;
//            }).toList();
            return viewComplaintDtos;
        } catch (Exception ex) {
            throw new ServiceException("An error occurred while fetching complaints", ex);
        }
    }

}