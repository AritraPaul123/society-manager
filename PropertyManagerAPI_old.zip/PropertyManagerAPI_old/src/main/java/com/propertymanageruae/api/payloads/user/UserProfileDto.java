package com.propertymanageruae.api.payloads.user;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserProfileDto {
    private String name;
    private String phone;
    private String avatar;
    private String email;
    private int age;
    private String location;
    private String occupation;
    private String interests;
    private String bio;
    private String residentType;
    private String role;
    @Builder.Default
    private List<PropertyDto> properties = new ArrayList<>();
    private String appVersion;
}