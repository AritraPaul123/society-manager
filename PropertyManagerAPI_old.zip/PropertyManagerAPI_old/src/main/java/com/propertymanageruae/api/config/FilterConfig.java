package com.propertymanageruae.api.config;

import com.propertymanageruae.api.Filter.SwaggerBasicAuthFilter;
import com.propertymanageruae.api.Filter.TimeZoneFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {

    @Bean
    public FilterRegistrationBean<SwaggerBasicAuthFilter> swaggerFilterRegistration(SwaggerBasicAuthFilter filter) {
        FilterRegistrationBean<SwaggerBasicAuthFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(filter);
        registration.addUrlPatterns("/swagger/*", "/v3/api-docs", "/v3/api-docs/*", "/swagger-ui/*");
        registration.setOrder(1); // ensure this runs early
        return registration;
    }

    //    @Bean
//    public FilterRegistrationBean<TokenDecryptFilter> tokenDecryptFilter(TokenDecryptFilter filter) {
//        FilterRegistrationBean<TokenDecryptFilter> registration = new FilterRegistrationBean<>();
//        registration.setFilter(filter);
//        registration.addUrlPatterns("/*");
//        registration.setOrder(2); // Run after basic auth if needed
//        return registration;
//    }
//    @Bean
//    public FilterRegistrationBean<TimeZoneFilter> timeZoneFilterRegistration(TimeZoneFilter filter) {
//        FilterRegistrationBean<TimeZoneFilter> registration = new FilterRegistrationBean<>();
//        registration.setFilter(filter);
//        registration.addUrlPatterns("/*"); // applies to all APIs
//        registration.setOrder(2);
//        return registration;
//    }

}