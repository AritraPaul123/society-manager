package com.propertymanageruae.api.services;

import com.propertymanageruae.api.services.ExternalService.IGmailOAuthService;
import com.propertymanageruae.api.services.ExternalService.IMailService;
import com.propertymanageruae.api.services.Notice.INoticeService;
import com.propertymanageruae.api.services.OTP.IOtpService;
import com.propertymanageruae.api.services.Society.ISocietyService;
import com.propertymanageruae.api.services.assignment.IAssignmentService;
import com.propertymanageruae.api.services.category.ICategoryService;
import com.propertymanageruae.api.services.complaint.IComplaintService;
import com.propertymanageruae.api.services.fcm.IFCMService;
import com.propertymanageruae.api.services.inspection.IHomeInspectionService;
import com.propertymanageruae.api.services.inspection.IInspectionSectionService;
import com.propertymanageruae.api.services.logger.ILoggerService;
import com.propertymanageruae.api.services.master.IMasterService;
import com.propertymanageruae.api.services.member.IMemberService;
import com.propertymanageruae.api.services.notification.INotificationService;
import com.propertymanageruae.api.services.token.IRefreshTokenService;
import com.propertymanageruae.api.services.user.ICustomUserDetailService;
import com.propertymanageruae.api.services.user.IUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UnitService {
    public final IAssignmentService assignmentService;
    public final IUserService userService;
    public final IRefreshTokenService refreshTokenService;
    public final IComplaintService complaintService;
    public final ICategoryService categoryService;
    public final ICustomUserDetailService customUserDetailService;
    public final IMemberService memberService;
    public final IMasterService masterService;
    public final IMailService mailService;
    public final IOtpService otpService;
    public final ILoggerService loggerService;
    public final INoticeService noticeService;
    public final INotificationService notificationService;
    public final IFCMService fcmService;
    public final IGmailOAuthService gmailOAuthService;
    public final IHomeInspectionService homeInspectionService;
    public final IInspectionSectionService iInspectionSectionService;
    public final ISocietyService societyService;
}