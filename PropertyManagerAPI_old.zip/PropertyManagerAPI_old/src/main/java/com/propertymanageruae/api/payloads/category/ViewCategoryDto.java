package com.propertymanageruae.api.payloads.category;

import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.payloads.user.UserDTO;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class ViewCategoryDto {
    private long id;
    @NotEmpty(message = "Category is required")
    private String category;
    private List<SubCategoryDTO> subCategoryList;
    private UserDTO createdBy;
}