package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = {"complaintsAsAssignee", "complaintsAsComplainer", "category", "assignmentRule", "userRoleMappings"})
@Entity
@Table(name = "users")
public class User implements UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String email;
    @Column(nullable = false)
    private String password;

    @Column(name = "resident_type")
    private String residentType;

    @Column(unique = false)
    private String contactNumber;
    //    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
//    @JoinTable(
//            name = "users_roles",
//            joinColumns = @JoinColumn(name = "user_id"),
//            inverseJoinColumns = @JoinColumn(name = "role_id"))
//    private Set<Role> roles = new HashSet<>();
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JsonIgnore
    private List<UserRoleMapping> userRoleMappings = new ArrayList<>();
    public List<UserRoleMapping> getUserRoleMappings() {
        if (userRoleMappings == null) {
            userRoleMappings = new ArrayList<>();
        }
        return userRoleMappings;
    }
    @OneToMany(mappedBy = "assignedUser", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("assignee-complaints")
    private List<Complaint> complaintsAsAssignee;
    @OneToMany(mappedBy = "complainer", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("complainer-complaints")
    private List<Complaint> complaintsAsComplainer;
    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference("user-category")
    private List<Category> category;
    @OneToMany(mappedBy = "user", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @JsonIgnore
    private List<AssignmentRule> assignmentRule = new ArrayList<>();

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "society_id", nullable = false)
//    @JsonBackReference
//    private Society society;

    @Column(name = "status", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean status;
    @Column(name = "profileUrl", nullable = true)
    private String profileUrl;
    @Column(name = "age", columnDefinition = "INT DEFAULT 0")
    private int age;
    @Column(name="location", nullable = true)
    private String location;
    @Column(name = "occupation", nullable = true)
    private String occupation;
    @Column(name = "interests", nullable = true, length = 255)
    private String interests;
    @Column(name = "bio", nullable = true, length = 500)
    private String bio;
    @Column(unique = true, name = "memberId")
    private String memberId;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy", columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy;
    @Column(name = "modifyBy", columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy", columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;
    @OneToOne(mappedBy = "user")
    @JsonIgnore
    private RefreshToken refreshToken;
    @Column(nullable = true)
    private LocalDateTime deletedAt;

    @Column(name = "face_id_enrolled")
    private Boolean faceIdEnrolled = false;

    @Column(name = "face_id_data", columnDefinition = "TEXT")
    private String faceIdData;

    @Column(name = "passcode")
    private String passcode;

    @Column(name = "biometric_required")
    private Boolean biometricRequired = false;

    @Column(name = "last_biometric_update")
    private LocalDateTime lastBiometricUpdate;

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.userRoleMappings.stream()
                .map(m -> new SimpleGrantedAuthority(
                        m.getRole().getName().startsWith("ROLE_")
                                ? m.getRole().getName()
                                : "ROLE_" + m.getRole().getName().toUpperCase()
                ))
                .collect(Collectors.toSet());
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }


    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}