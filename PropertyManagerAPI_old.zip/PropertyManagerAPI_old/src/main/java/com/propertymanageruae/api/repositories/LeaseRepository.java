package com.propertymanageruae.api.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.propertymanageruae.api.entities.Lease;

@Repository
public interface LeaseRepository extends JpaRepository<Lease, Long> {




    // // Fetch leases for a specific renter
    // List<Lease> findByRenterId(Long renterId);
    List<Lease> findByTenant_Id(Long tenantId);


    // Fetch leases for a specific property
    List<Lease> findByPropertyId(Long propertyId);

    List<Lease> findByPropertyIdIn(List<Long> propertyIds);
}
