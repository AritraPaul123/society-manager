package com.propertymanageruae.api.payloads.member;

import com.propertymanageruae.api.entities.Role;
import com.propertymanageruae.api.payloads.utils.SocietyRoleDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewMemberDto {
    private long id;
    private long userId;
    private String name;
    private String email;
    private String contactNumber;
    private boolean status;
    private String memberId;
    private String updateRoles;
//    private Set<Role> roles = new HashSet<>();
    private List<SocietyRoleDto> societyRoles;
}