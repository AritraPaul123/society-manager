package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.ErrorLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import java.util.List;

@Repository
public interface IErrorLogRepository extends JpaRepository<ErrorLog, Long> {
    List<ErrorLog> findByCreatedAtBefore(java.sql.Timestamp ts);
    void deleteByCreatedAtBefore(java.sql.Timestamp ts);
}