package com.propertymanageruae.api.payloads.notice;

import com.propertymanageruae.api.payloads.master.ViewApartmentDto;
import com.propertymanageruae.api.payloads.master.ViewAreaDto;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewNoticeGroupDto {
    private long id;
    private String title;
    private String description;
    private String notificationType;
    private String targetAudience;
    private String notifyTo;
    private String noticeId;
    private boolean isEmailNotification;
    private boolean isScheduleNotification;
    private ViewSocietyDto society;
    private Set<ViewNoticeFileDto> noticeFiles = new HashSet<>();
    private boolean isDeleted;
    private ViewUserDto postedBy;
    private Set<ViewAreaDto> areas = new HashSet<>();
    private Set<ViewApartmentDto> apartments = new HashSet<>();
    private long createdBy;
    private long modifiedBy;
    private long deletedBy;
    private LocalDateTime postedAt;
    private LocalDateTime updatedAt;
    private LocalDateTime expiredAt;
}