package com.propertymanageruae.api.payloads.master;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ManageResidentDto {
    @NotEmpty(message = "Residents list must not be empty")
    private List<@Valid CommonResidentDto> residents;
}