package com.propertymanageruae.api.repositories;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.propertymanageruae.api.entities.Property;

public interface PropertyRepository extends JpaRepository<Property, Long> {

    @Query("SELECT DISTINCT p.buildingName FROM Property p WHERE p.buildingName IS NOT NULL")
    List<String> findDistinctBuildingNames();

    @Query("SELECT DISTINCT p.unitName FROM Property p WHERE p.buildingName = :buildingName AND p.unitName IS NOT NULL")
    List<String> findUnitsByBuildingName(String buildingName);

    // Optional<Property> findByBuildingNameAndUnitName(String buildingName, String
    // unitName);
    List<Property> findByBuildingNameAndUnitName(String buildingName, String unitName);

}