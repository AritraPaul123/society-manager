package com.propertymanageruae.api.services.fcm;

import com.google.firebase.messaging.*;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.entities.UserDevice;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.notification.RealTimeNotificationDto;
import com.propertymanageruae.api.payloads.token.FCMTokenResponse;
import com.propertymanageruae.api.payloads.token.FcmTokenRequest;
import com.propertymanageruae.api.payloads.token.FcmTokenUpdateRequest;
import com.propertymanageruae.api.payloads.token.FcmUnregisterRequest;
import com.propertymanageruae.api.repositories.IUserDeviceRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import com.propertymanageruae.api.services.notification.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class FCMService implements IFCMService {
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private IUserDeviceRepository userDeviceRepository;
    private static final Logger logger = LoggerFactory.getLogger(FCMService.class);

    //    @Override
//    public FC MTokenResponse saveFcmToken(FcmTokenRequest request) {
//        try {
//            if (request.getUserId() == null || request.getFcmToken() == null || request.getDeviceId() == null || request.getDeviceType() == null) {
//                throw new IllegalArgumentException("All fields are required");
//            }
//            User user = userRepository.findById(request.getUserId()).orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + request.getUserId()));
//            Optional<UserDevice> existing = userDeviceRepository.findByFcmToken(request.getFcmToken());
//            UserDevice device = existing.orElse(new UserDevice());
//            device.setUser(user);
//            device.setFcmToken(request.getFcmToken());
//            device.setDeviceId(request.getDeviceId());
//            device.setDeviceType(request.getDeviceType());
//            device.setActive(true);
//            userDeviceRepository.save(device);
//            return FCMTokenResponse.builder()
//                    .userId(user.getId())
//                    .fcmToken(device.getFcmToken())
//                    .build();
//        } catch (IllegalArgumentException e) {
//            throw new IllegalArgumentException("Invalid request: " + e.getMessage());
//        }
//        catch (Exception e) {
//            throw new RuntimeException("Failed to save FCM token: " + e.getMessage(), e);
//        }
//    }
    // FCMService.java
    @Override
    public FCMTokenResponse saveFcmToken(FcmTokenRequest request) {
        try {
            // 🧩 Validate input
            if (request.getUserId() == null ||
                    request.getFcmToken() == null ||
                    request.getDeviceId() == null ||
                    request.getDeviceType() == null) {
                throw new IllegalArgumentException("All fields are required");
            }

            // 🧩 Fetch user
            User user = userRepository.findById(request.getUserId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "User not found with id: " + request.getUserId()));

            // 🧩 Find existing devices for the same deviceId
            List<UserDevice> existingDevices = userDeviceRepository.findByDeviceId(request.getDeviceId());

            UserDevice device;

            if (existingDevices != null && !existingDevices.isEmpty()) {
                // If there are multiple, take the first or handle duplicates
                device = existingDevices.get(0);

                // Optional: clean up any duplicates (safe production practice)
                if (existingDevices.size() > 1) {
                    for (int i = 1; i < existingDevices.size(); i++) {
                        userDeviceRepository.delete(existingDevices.get(i));
                    }
                }
            } else {
                device = new UserDevice();
            }

            // 🧩 Update details
            device.setUser(user);
            device.setFcmToken(request.getFcmToken());
            device.setDeviceId(request.getDeviceId());
            device.setDeviceType(request.getDeviceType());
            device.setActive(true);

            userDeviceRepository.save(device);

            // ✅ Return response
            return FCMTokenResponse.builder()
                    .userId(user.getId())
                    .fcmToken(device.getFcmToken())
                    .build();

        } catch (Exception e) {
            throw new RuntimeException("Failed to save FCM token: " + e.getMessage(), e);
        }
    }

    @Override
    public FCMTokenResponse updateFcmToken(FcmTokenUpdateRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + request.getUserId()));

        UserDevice device = userDeviceRepository.findByUserIdAndDeviceId(user.getId(), request.getDeviceId())
                .orElseThrow(() -> new ResourceNotFoundException("Device not found for user"));

        device.setFcmToken(request.getFcmToken());
        device.setActive(true);
        userDeviceRepository.save(device);

        return FCMTokenResponse.builder()
                .userId(user.getId())
                .fcmToken(device.getFcmToken())
                .build();
    }

    @Override
    public void unregisterFcmToken(FcmUnregisterRequest request) {
        userDeviceRepository.findByUserIdAndDeviceId(request.getUserId(), request.getDeviceId())
                .ifPresent(device -> {
                    device.setActive(false);
                    userDeviceRepository.save(device);
                });
    }


    @Override
    @Async
    public void sendNotificationToUserId(Long userId, String title, String body) throws FirebaseMessagingException {
        // Send push notification via FCM
        List<String> fcmTokens = userDeviceRepository.findActiveTokensByUserId(userId);
        if (fcmTokens == null || fcmTokens.isEmpty()) {
            logger.info("No active FCM tokens found for user: {}", userId);
            return;
        }
        sendInBatches(fcmTokens, title, body, null, "UserID: " + userId);
    }

    @Override
    @Async
    public void sendNotificationToUsers(List<User> users, String title, String body)
            throws FirebaseMessagingException {
        if (users == null || users.isEmpty()) {
            logger.info("User list is empty. No notifications sent.");
            return;
        }

        List<String> allTokens = new ArrayList<>();

        for (User user : users) {
            // Collect FCM tokens
            List<String> userTokens = userDeviceRepository.findActiveTokensByUserId(user.getId());
            if (userTokens != null && !userTokens.isEmpty()) {
                allTokens.addAll(userTokens);
            } else {
                logger.info("No active FCM tokens found for userId: {}", user.getId());
            }
        }

        if (allTokens.isEmpty()) {
            logger.info("No active FCM tokens found for any of the provided users.");
            return;
        }

        sendInBatches(allTokens, title, body, null, "Multiple Users");
    }

    private void sendInBatches(List<String> tokens, String title, String body,
                               Map<String, String> data, String contextInfo)
            throws FirebaseMessagingException {

        int batchSize = 500;
        for (int i = 0; i < tokens.size(); i += batchSize) {
            List<String> batchTokens = tokens.subList(i, Math.min(i + batchSize, tokens.size()));

            MulticastMessage.Builder messageBuilder = MulticastMessage.builder()
                    .addAllTokens(batchTokens)
                    .setNotification(Notification.builder()
                            .setTitle(title)
                            .setBody(body)
                            .build());

            if (data != null && !data.isEmpty()) {
                messageBuilder.putAllData(data);
            }

            MulticastMessage message = messageBuilder.build();
            BatchResponse response = FirebaseMessaging.getInstance().sendEachForMulticast(message);

            logger.info("Notification batch sent ({}) → Success: {}, Failure: {}",
                    contextInfo, response.getSuccessCount(), response.getFailureCount());

            List<SendResponse> responses = response.getResponses();
            for (int j = 0; j < responses.size(); j++) {
                SendResponse sendResponse = responses.get(j);
                if (!sendResponse.isSuccessful()) {
                    String failedToken = batchTokens.get(j);
                    markTokenAsInactive(failedToken);
                    logger.warn("Failed to send notification ({}): Token: {} | Reason: {}",
                            contextInfo, failedToken, sendResponse.getException().getMessage());
                }
            }
        }
    }

    private void markTokenAsInactive(String token) {
        userDeviceRepository.findByFcmToken(token).ifPresent(device -> {
            device.setActive(false);
            userDeviceRepository.save(device);
            logger.info("Marked FCM token as inactive: {}", token);
        });
    }

}