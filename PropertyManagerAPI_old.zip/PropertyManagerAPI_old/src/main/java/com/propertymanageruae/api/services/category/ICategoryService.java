package com.propertymanageruae.api.services.category;

import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.category.CategoryDTO;
import com.propertymanageruae.api.payloads.category.ViewCategoryDto;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

public interface ICategoryService {
    String addCategory(CategoryDTO categoryDTO) throws SQLIntegrityConstraintViolationException;

    String editCategory(CategoryDTO categoryDTO, long id) throws SQLIntegrityConstraintViolationException;

    void deleteCategory(long id) throws SQLIntegrityConstraintViolationException;

    PaginationDto<ViewCategoryDto> getCategories(int pageNumber, int pageSize,String sortBy,String sortDir,String searchText,long societyId);

    ViewCategoryDto getCategory(long id);

    void softDeleteCategory(long id) throws SQLIntegrityConstraintViolationException;

    List<ViewCategoryDto> getCategoryList(long societyId);
}