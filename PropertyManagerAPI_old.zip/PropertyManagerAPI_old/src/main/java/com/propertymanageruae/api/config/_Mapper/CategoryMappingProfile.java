package com.propertymanageruae.api.config._Mapper;

import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.payloads.category.ViewCategoryDto;
import jakarta.annotation.PostConstruct;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Component
public class CategoryMappingProfile {
    private final ModelMapper modelMapper;

    public CategoryMappingProfile(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    @PostConstruct
    public void configureCategoryMapping() {
        Converter<Collection, List> collectionToListConverter = context ->
                context.getSource() == null ? new ArrayList<>() : new ArrayList<>(context.getSource());
        modelMapper.addMappings(new PropertyMap<Category, ViewCategoryDto>() {
            @Override
            protected void configure() {
                using(collectionToListConverter)
                        .map(source.getSubCategoryList())
                        .setSubCategoryList(null);
            }
        });
    }
}