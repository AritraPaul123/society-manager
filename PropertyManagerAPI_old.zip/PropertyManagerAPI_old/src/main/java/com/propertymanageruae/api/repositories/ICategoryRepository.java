package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ICategoryRepository extends JpaRepository<Category, Long> {
    @Override
    Optional<Category> findById(Long id);
    Page<Category> findBySocietyId(long societyId, Pageable pageable);
    Page<Category> findBySocietyIdAndIsDelete(long societyId, boolean isDelete, Pageable pageable);
    List<Category> findBySocietyIdAndIsDelete(long societyId, boolean isDelete);
    @Query("SELECT c FROM Category c WHERE " +
            "LOWER(c.category) LIKE LOWER(CONCAT('%', :searchText, '%'))")
    Page<Category> findBySearchText(@Param("searchText") String searchText, Pageable pageable);
    @Query("SELECT c FROM Category c WHERE c.society.id = :societyId AND " +
            "LOWER(c.category) LIKE LOWER(CONCAT('%', :searchText, '%'))")
    Page<Category> findBySocietyIdAndSearchText_OLD(@Param("societyId") long societyId,
                                                @Param("searchText") String searchText,
                                                Pageable pageable);
    @Query("SELECT c FROM Category c WHERE c.society.id = :societyId AND " +
            "LOWER(c.category) LIKE LOWER(CONCAT('%', :searchText, '%')) AND " +
            "c.isDelete = false")
    Page<Category> findBySocietyIdAndSearchText(@Param("societyId") long societyId,
                                                @Param("searchText") String searchText,
                                                Pageable pageable);


}