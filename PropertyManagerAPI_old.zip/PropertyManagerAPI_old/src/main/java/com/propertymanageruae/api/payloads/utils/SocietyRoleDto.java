package com.propertymanageruae.api.payloads.utils;

import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class SocietyRoleDto {
    private ViewSocietyDto society;
    private RoleDTO role;
}