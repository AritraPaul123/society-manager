package com.propertymanageruae.api.entities;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "payment_transactions")
public class PaymentTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    // link to installment (nullable for manual payments that are not linked)
    @ManyToOne
    @JoinColumn(name = "installment_id")
    @JsonIgnoreProperties({ "transactions", "payment" })
    private PaymentInstallment installment;

    // link to parent payment (always set)
    @ManyToOne
    @JoinColumn(name = "payment_id")
    @JsonIgnoreProperties({ "paymentInstallments", "manualTransactions" })
    private Payment payment;

    @Column(precision = 12, scale = 2)
    private BigDecimal amountPaid;

    @Column(name = "payment_mode")
    private String paymentMode;

    private String transRef;

    // private String bankName;

    // @Column(name = "purpose", length = 500)
    // private String purpose;

    @Column(name = "transaction_date")
    private LocalDateTime transactionDate = LocalDateTime.now();

    // NEW fields from the React form
    @Column(name = "issuer_bank")
    private String issuerBank;

    @Column(name = "issuer_account_number")
    private String issuerAccountNumber;

    @Column(name = "deposited_bank")
    private String depositedBank;

    @Column(name = "depositor_account_number")
    private String depositorAccountNumber;

    @Column(name = "payment_type")
    private String type;

    private String remarks;

   @Column(length = 20)
    private String status = "pending";
}



