package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.helper.UnitHelper;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v${api.version}/aws-s3")
@SecurityRequirement(name = "auth")
@Tag(name = "AWS-S3")
public class S31Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Autowired
    private UnitService _unitService;
    @Autowired
    private UnitHelper _unithelper;

    @GetMapping("/files/download")
    public ResponseEntity<byte[]> downloadFile(@RequestParam String fileName) {
        try {
            byte[] fileContent = _unithelper.s3FileHandler.downloadFile(fileName);
            HttpHeaders headers = new HttpHeaders();
            headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
            headers.set(HttpHeaders.CONTENT_TYPE, "application/octet-stream");
            return new ResponseEntity<>(fileContent, headers, HttpStatus.OK);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(("Error downloading file: " + e.getMessage()).getBytes());
        }
    }
}