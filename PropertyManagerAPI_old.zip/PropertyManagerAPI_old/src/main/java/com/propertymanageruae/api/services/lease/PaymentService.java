package com.propertymanageruae.api.services.lease;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.repositories.*;
import java.math.RoundingMode;


import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentInstallmentRepository installmentRepository;
    private final PaymentTransactionRepository transactionRepository;
    private final LeaseRepository leaseRepository;

    // private int getLeaseYears(Lease lease) {
    //     if (lease.getStartDate() == null || lease.getEndDate() == null)
    //         return 1;
    //     return lease.getEndDate().getYear() - lease.getStartDate().getYear();
    // }
    private int getLeaseYears(Lease lease) {
    if (lease.getStartDate() == null || lease.getEndDate() == null)
        return 1;

    Period period = Period.between(lease.getStartDate(), lease.getEndDate());
    int years = period.getYears();

    // If there are months/days, count it as an extra year (optional)
    if (period.getMonths() > 0 || period.getDays() > 0) {
        years += 1;
    }

    return years;
}


    @Transactional
    public Payment createPaymentForLease(Payment payment, Lease lease) {

        payment.setLease(lease);

        if (payment.getAnnualRent() == null)
            throw new IllegalArgumentException("annualRent is required");

        if (payment.getStartDate() == null)
            payment.setStartDate(LocalDate.now());

        if (payment.getInstallments() == null || payment.getInstallments() < 1)
            payment.setInstallments(1);

        if (payment.getNoOfMonthsPeriod() == null || payment.getNoOfMonthsPeriod() <= 0)
            payment.setNoOfMonthsPeriod(12);

        if (payment.getTotalPaymentReceived() == null)
            payment.setTotalPaymentReceived(BigDecimal.ZERO);

        int years = getLeaseYears(lease);

        BigDecimal totalRent = payment.getAnnualRent().multiply(BigDecimal.valueOf(years));

        BigDecimal extraCharges = (payment.getSecurityDeposit() == null ? BigDecimal.ZERO : payment.getSecurityDeposit())
                .add(payment.getVatTax() == null ? BigDecimal.ZERO : payment.getVatTax())
                .add(payment.getBrokerFee() == null ? BigDecimal.ZERO : payment.getBrokerFee());

        BigDecimal totalDue = totalRent.add(extraCharges);

        payment.setRemainingBalance(totalDue);

        Payment saved = paymentRepository.save(payment);

        generateInstallments(saved);

        return paymentRepository.findById(saved.getId()).orElse(saved);
    }

    // private void generateInstallments(Payment payment) {

    //     Lease lease = payment.getLease();
    //     int years = lease.getEndDate().getYear() - lease.getStartDate().getYear();

    //     int installmentsPerYear = payment.getInstallments();
    //     int totalInstallments = installmentsPerYear * years;

    //     if (totalInstallments < 1)
    //         totalInstallments = 1;

    //     BigDecimal annual = payment.getAnnualRent();
    //     BigDecimal yearlyInstallmentAmount = annual.divide(BigDecimal.valueOf(installmentsPerYear));

    //     LocalDate startDate = payment.getStartDate();

    //     for (int year = 0; year < years; year++) {
    //         for (int ins = 1; ins <= installmentsPerYear; ins++) {

    //             PaymentInstallment installment = new PaymentInstallment();
    //             installment.setPayment(payment);

    //             int globalNo = (year * installmentsPerYear) + ins;
    //             installment.setInstallmentNo(globalNo);

    //             installment.setInstallmentAmount(yearlyInstallmentAmount);

    //             int monthsGap = 12 / installmentsPerYear;

    //             installment.setInstallmentDate(startDate.plusMonths((long) monthsGap * (globalNo - 1)));

    //             installment.setStatus("pending");
    //             installment.setAmountPaid(BigDecimal.ZERO);

    //             installmentRepository.save(installment);
    //             payment.getPaymentInstallments().add(installment);
    //         }
    //     }

    //     paymentRepository.save(payment);
    // }
    private void generateInstallments(Payment payment) {

    Lease lease = payment.getLease();

    LocalDate leaseStart = lease.getStartDate();
    LocalDate leaseEnd = lease.getEndDate();

    int installmentsPerYear = payment.getInstallments();

    // Accurate year calculation including partial years
    Period period = Period.between(leaseStart, leaseEnd);
    int years = period.getYears();
    if (period.getMonths() > 0 || period.getDays() > 0) years++;

    if (years < 1) years = 1;

    // Total installments = years * installments-per-year
    int totalInstallments = years * installmentsPerYear;

    BigDecimal yearlyInstallAmount = payment.getAnnualRent()
            .divide(BigDecimal.valueOf(installmentsPerYear), RoundingMode.HALF_UP);

    LocalDate installmentStart = leaseStart;

    int monthsGap = 12 / installmentsPerYear;

    int installmentNo = 1;

    for (int year = 0; year < years; year++) {

        for (int ins = 0; ins < installmentsPerYear; ins++) {

            // Calculate installment date
            LocalDate installmentDate =
                    installmentStart.plusMonths((long) year * 12 + (long) ins * monthsGap);

            // Prevent going beyond lease end
            if (installmentDate.isAfter(leaseEnd)) {
                installmentDate = leaseEnd;
            }

            PaymentInstallment inst = new PaymentInstallment();
            inst.setPayment(payment);
            inst.setInstallmentNo(installmentNo++);
            inst.setInstallmentAmount(yearlyInstallAmount);
            inst.setInstallmentDate(installmentDate);
            inst.setStatus("pending");
            inst.setAmountPaid(BigDecimal.ZERO);

            installmentRepository.save(inst);
            payment.getPaymentInstallments().add(inst);
        }
    }

    paymentRepository.save(payment);
}


    // -----------------------------------------------------------------------------------
    // MANUAL PAYMENT LOGIC (STATUS AWARE)
    // -----------------------------------------------------------------------------------

    @Transactional
    public Payment manualPayment(Long leaseId, PaymentTransaction txn) {

        Lease lease = leaseRepository.findById(leaseId)
                .orElseThrow(() -> new RuntimeException("Lease not found: " + leaseId));

        Payment payment = lease.getPayments().stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No payments found for lease " + leaseId));

        txn.setPayment(payment);
        txn.setTransactionDate(LocalDateTime.now());

        boolean isPaid = "paid".equalsIgnoreCase(txn.getStatus());

        // ------------ LINKED TO INSTALLMENT ------------
        if (txn.getInstallment() != null && txn.getInstallment().getInstallmentId() != null) {

            Long insId = txn.getInstallment().getInstallmentId();
            PaymentInstallment inst = installmentRepository.findById(insId)
                    .orElseThrow(() -> new RuntimeException("Installment not found: " + insId));

            if (!inst.getPayment().getId().equals(payment.getId()))
                throw new RuntimeException("Installment does not belong to payment " + payment.getId());

            txn.setInstallment(inst);
            transactionRepository.save(txn);

            if (isPaid) {
                BigDecimal prev = inst.getAmountPaid() == null ? BigDecimal.ZERO : inst.getAmountPaid();
                BigDecimal inc = txn.getAmountPaid() == null ? BigDecimal.ZERO : txn.getAmountPaid();

                inst.setAmountPaid(prev.add(inc));

                if (inst.getAmountPaid().compareTo(inst.getInstallmentAmount()) >= 0) {
                    inst.setStatus("paid");
                    inst.setPaymentDate(LocalDate.now());
                } else {
                    inst.setStatus("partial");
                }
            } else {
                inst.setStatus("pending");
            }

            copyTransactionMetadataToInstallment(txn, inst);

            installmentRepository.save(inst);
            inst.getTransactions().add(txn);

        } else {
            // ------------ UNLINKED MANUAL TRANSACTION ------------
            txn.setInstallment(null);
            transactionRepository.save(txn);
            payment.getManualTransactions().add(txn);
        }

        recalculatePaymentTotals(payment);
        return paymentRepository.save(payment);
    }

    private void copyTransactionMetadataToInstallment(PaymentTransaction txn, PaymentInstallment inst) {
        if (txn.getPaymentMode() != null) inst.setPaymentMode(txn.getPaymentMode());
        if (txn.getTransRef() != null) inst.setTransRef(txn.getTransRef());
        if (txn.getIssuerBank() != null) inst.setIssuerBank(txn.getIssuerBank());
        if (txn.getIssuerAccountNumber() != null) inst.setIssuerAccountNumber(txn.getIssuerAccountNumber());
        if (txn.getDepositedBank() != null) inst.setDepositedBank(txn.getDepositedBank());
        if (txn.getDepositorAccountNumber() != null) inst.setDepositorAccountNumber(txn.getDepositorAccountNumber());
        if (txn.getType() != null) inst.setType(txn.getType());
        if (txn.getRemarks() != null) inst.setRemarks(txn.getRemarks());
    }

    // -----------------------------------------------------------------------------------
    // DELETE MANUAL TRANSACTION
    // -----------------------------------------------------------------------------------

    @Transactional
    public void deleteManualTransaction(Long leaseId, Long paymentId, Long transactionId) {

        PaymentTransaction txn = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new RuntimeException("Transaction not found: " + transactionId));

        if (!txn.getPayment().getId().equals(paymentId))
            throw new RuntimeException("Transaction does not belong to payment " + paymentId);

        if (!txn.getPayment().getLease().getId().equals(leaseId))
            throw new RuntimeException("Transaction does not belong to lease " + leaseId);

        if (txn.getInstallment() != null && "paid".equalsIgnoreCase(txn.getStatus())) {
            PaymentInstallment inst = txn.getInstallment();
            BigDecimal prev = inst.getAmountPaid() != null ? inst.getAmountPaid() : BigDecimal.ZERO;
            BigDecimal sub = txn.getAmountPaid() != null ? txn.getAmountPaid() : BigDecimal.ZERO;
            inst.setAmountPaid(prev.subtract(sub).max(BigDecimal.ZERO));

            if (inst.getAmountPaid().compareTo(BigDecimal.ZERO) == 0) {
                inst.setStatus("pending");
                inst.setPaymentDate(null);
            } else if (inst.getAmountPaid().compareTo(inst.getInstallmentAmount()) >= 0) {
                inst.setStatus("paid");
            } else {
                inst.setStatus("partial");
            }
            installmentRepository.save(inst);
        } else {
            Payment parent = txn.getPayment();
            parent.getManualTransactions().removeIf(t -> t.getTransactionId().equals(txn.getTransactionId()));
            paymentRepository.save(parent);
        }

        transactionRepository.deleteById(transactionId);

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found: " + paymentId));
        recalculatePaymentTotals(payment);
    }

    // -----------------------------------------------------------------------------------
    // RECALCULATE PAYMENT TOTALS (ONLY PAID TRANSACTIONS)
    // -----------------------------------------------------------------------------------

    public void recalculatePaymentTotals(Payment payment) {

        BigDecimal installmentPaid = payment.getPaymentInstallments().stream()
                .map(i -> i.getAmountPaid() != null ? i.getAmountPaid() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal manualPaid = payment.getManualTransactions().stream()
                .filter(t -> "paid".equalsIgnoreCase(t.getStatus()))
                .map(t -> t.getAmountPaid() != null ? t.getAmountPaid() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalPaid = installmentPaid.add(manualPaid);
        payment.setTotalPaymentReceived(totalPaid);

        int years = getLeaseYears(payment.getLease());
        BigDecimal totalDue = payment.getAnnualRent().multiply(BigDecimal.valueOf(years))
                .add(payment.getVatTax() != null ? payment.getVatTax() : BigDecimal.ZERO)
                .add(payment.getBrokerFee() != null ? payment.getBrokerFee() : BigDecimal.ZERO)
                .add(payment.getSecurityDeposit() != null ? payment.getSecurityDeposit() : BigDecimal.ZERO);

        payment.setRemainingBalance(totalDue.subtract(totalPaid).max(BigDecimal.ZERO));
    }

    // -----------------------------------------------------------------------------------
    // UPDATE INSTALLMENT STATUS (STATUS & AMOUNT PAID)
    // -----------------------------------------------------------------------------------

    // @Transactional
    // public PaymentInstallment updateInstallmentStatus(Long leaseId, Long paymentId, Long installmentId,
    //         String status,
    //         BigDecimal amountPaid,
    //         String paymentMode,
    //         String transRef,
    //         String issuerBank,
    //         String issuerAccountNumber,
    //         String depositedBank,
    //         String depositorAccountNumber,
    //         String type,
    //         String remarks) {

    //     PaymentInstallment inst = installmentRepository.findById(installmentId)
    //             .orElseThrow(() -> new RuntimeException("Installment not found: " + installmentId));

    //     if (!inst.getPayment().getId().equals(paymentId))
    //         throw new RuntimeException("Installment not under payment " + paymentId);

    //     if (!inst.getPayment().getLease().getId().equals(leaseId))
    //         throw new RuntimeException("Installment not under lease " + leaseId);

    //     boolean isPaid = "paid".equalsIgnoreCase(status);

    //     if (status != null) inst.setStatus(status);
    //     if (amountPaid != null && isPaid) inst.setAmountPaid(amountPaid);

    //     if (paymentMode != null) inst.setPaymentMode(paymentMode);
    //     if (transRef != null) inst.setTransRef(transRef);
    //     if (issuerBank != null) inst.setIssuerBank(issuerBank);
    //     if (issuerAccountNumber != null) inst.setIssuerAccountNumber(issuerAccountNumber);
    //     if (depositedBank != null) inst.setDepositedBank(depositedBank);
    //     if (depositorAccountNumber != null) inst.setDepositorAccountNumber(depositorAccountNumber);
    //     if (type != null) inst.setType(type);
    //     if (remarks != null) inst.setRemarks(remarks);

    //     if (isPaid) inst.setPaymentDate(LocalDate.now());
    //     else inst.setPaymentDate(null);

    //     installmentRepository.save(inst);
    //     recalculatePaymentTotals(inst.getPayment());

    //     return inst;
    // }
    @Transactional
public PaymentInstallment updateInstallmentStatus(Long leaseId, Long paymentId, Long installmentId,
        String status,
        BigDecimal amountPaid,
        String paymentMode,
        String transRef,
        String issuerBank,
        String issuerAccountNumber,
        String depositedBank,
        String depositorAccountNumber,
        String type,
        String remarks) {

    PaymentInstallment inst = installmentRepository.findById(installmentId)
            .orElseThrow(() -> new RuntimeException("Installment not found: " + installmentId));

    if (!inst.getPayment().getId().equals(paymentId))
        throw new RuntimeException("Installment not under payment " + paymentId);

    if (!inst.getPayment().getLease().getId().equals(leaseId))
        throw new RuntimeException("Installment not under lease " + leaseId);

    boolean isPaid = "paid".equalsIgnoreCase(status);

    if (status != null) inst.setStatus(status);

    // If status is paid and caller didn't pass amountPaid, use the installmentAmount as the paid amount.
    if (isPaid) {
        if (amountPaid != null) {
            inst.setAmountPaid(amountPaid);
        } else {
            BigDecimal due = inst.getInstallmentAmount() != null ? inst.getInstallmentAmount() : BigDecimal.ZERO;
            inst.setAmountPaid(due);
        }
    } else {
        // If not paid, and amountPaid provided, we still allow updating; otherwise leave as is
        if (amountPaid != null) inst.setAmountPaid(amountPaid);
    }

    if (paymentMode != null) inst.setPaymentMode(paymentMode);
    if (transRef != null) inst.setTransRef(transRef);
    if (issuerBank != null) inst.setIssuerBank(issuerBank);
    if (issuerAccountNumber != null) inst.setIssuerAccountNumber(issuerAccountNumber);
    if (depositedBank != null) inst.setDepositedBank(depositedBank);
    if (depositorAccountNumber != null) inst.setDepositorAccountNumber(depositorAccountNumber);
    if (type != null) inst.setType(type);
    if (remarks != null) inst.setRemarks(remarks);

    if (isPaid) inst.setPaymentDate(LocalDate.now());
    else inst.setPaymentDate(null);

    installmentRepository.save(inst);
    recalculatePaymentTotals(inst.getPayment());

    return inst;
}


    @Transactional
public PaymentTransaction updateManualTransaction(Long leaseId, Long paymentId, Long transactionId, PaymentTransaction txnUpdate) {

    PaymentTransaction txn = transactionRepository.findById(transactionId)
            .orElseThrow(() -> new RuntimeException("Transaction not found: " + transactionId));

    if (!txn.getPayment().getId().equals(paymentId))
        throw new RuntimeException("Transaction does not belong to payment " + paymentId);

    if (!txn.getPayment().getLease().getId().equals(leaseId))
        throw new RuntimeException("Transaction does not belong to lease " + leaseId);

    boolean wasPaid = "paid".equalsIgnoreCase(txn.getStatus());
    boolean nowPaid = "paid".equalsIgnoreCase(txnUpdate.getStatus());

    // Update fields
    if (txnUpdate.getAmountPaid() != null) txn.setAmountPaid(txnUpdate.getAmountPaid());
    if (txnUpdate.getPaymentMode() != null) txn.setPaymentMode(txnUpdate.getPaymentMode());
    if (txnUpdate.getTransRef() != null) txn.setTransRef(txnUpdate.getTransRef());
    if (txnUpdate.getIssuerBank() != null) txn.setIssuerBank(txnUpdate.getIssuerBank());
    if (txnUpdate.getIssuerAccountNumber() != null) txn.setIssuerAccountNumber(txnUpdate.getIssuerAccountNumber());
    if (txnUpdate.getDepositedBank() != null) txn.setDepositedBank(txnUpdate.getDepositedBank());
    if (txnUpdate.getDepositorAccountNumber() != null) txn.setDepositorAccountNumber(txnUpdate.getDepositorAccountNumber());
    if (txnUpdate.getType() != null) txn.setType(txnUpdate.getType());
    if (txnUpdate.getRemarks() != null) txn.setRemarks(txnUpdate.getRemarks());
    if (txnUpdate.getStatus() != null) txn.setStatus(txnUpdate.getStatus());

    // Handle amountPaid effect based on status
    if (txn.getInstallment() != null) {
        PaymentInstallment inst = txn.getInstallment();

        if (wasPaid && !nowPaid) {
            // Deduct from installment amountPaid
            BigDecimal prev = inst.getAmountPaid() != null ? inst.getAmountPaid() : BigDecimal.ZERO;
            BigDecimal sub = txn.getAmountPaid() != null ? txn.getAmountPaid() : BigDecimal.ZERO;
            inst.setAmountPaid(prev.subtract(sub).max(BigDecimal.ZERO));
        } else if (!wasPaid && nowPaid) {
            // Add to installment amountPaid
            BigDecimal prev = inst.getAmountPaid() != null ? inst.getAmountPaid() : BigDecimal.ZERO;
            BigDecimal add = txn.getAmountPaid() != null ? txn.getAmountPaid() : BigDecimal.ZERO;
            inst.setAmountPaid(prev.add(add));
        }

        // Update installment status and paymentDate
        if (inst.getAmountPaid().compareTo(inst.getInstallmentAmount()) >= 0) {
            inst.setStatus("paid");
            inst.setPaymentDate(LocalDate.now());
        } else if (inst.getAmountPaid().compareTo(BigDecimal.ZERO) > 0) {
            inst.setStatus("partial");
            inst.setPaymentDate(null);
        } else {
            inst.setStatus("pending");
            inst.setPaymentDate(null);
        }

        installmentRepository.save(inst);
    }

    transactionRepository.save(txn);

    // Recalculate parent payment totals
    recalculatePaymentTotals(txn.getPayment());

    return txn;
}

@Transactional
public Payment updatePaymentWithRecalculation(Long leaseId, Long paymentId, Payment updated) {

    Lease lease = leaseRepository.findById(leaseId)
            .orElseThrow(() -> new RuntimeException("Lease not found"));

    Payment payment = paymentRepository.findById(paymentId)
            .orElseThrow(() -> new RuntimeException("Payment not found"));

    if (!payment.getLease().getId().equals(leaseId))
        throw new RuntimeException("Payment does not belong to lease");

    // UPDATE BASIC FIELDS
    payment.setAnnualRent(updated.getAnnualRent());
    payment.setInstallments(updated.getInstallments());
    payment.setNoOfMonthsPeriod(updated.getNoOfMonthsPeriod());
    payment.setVatTax(updated.getVatTax());
    payment.setBrokerFee(updated.getBrokerFee());
    payment.setSecurityDeposit(updated.getSecurityDeposit());
    payment.setContractValue(updated.getContractValue());
    payment.setGraceperiod(updated.getGraceperiod());
    // payment.setStartDate(updated.getStartDate());3

    // ❗ DELETE OLD INSTALLMENTS
    installmentRepository.deleteAll(payment.getPaymentInstallments());
    payment.getPaymentInstallments().clear();

    // ❗ DELETE OLD TRANSACTION LINKS (transactions remain, but unlink installment)
    for (PaymentTransaction txn : payment.getManualTransactions()) {
        txn.setInstallment(null);
    }

    // ❗ RECALCULATE remaining balance before regenerate
    recalculatePaymentTotals(payment);

    paymentRepository.save(payment);

    // ❗ REGENERATE INSTALLMENTS
    generateInstallments(payment);

    // ❗ RECALCULATE AGAIN after generating
    recalculatePaymentTotals(payment);

    return paymentRepository.save(payment);
}


}





