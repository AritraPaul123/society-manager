package com.propertymanageruae.api.payloads.menu;

import lombok.Data;

@Data
public class EditMenuDto {
    private String name;
    private String icon;
    private String path;
    private String description;
    private boolean isActive;
}