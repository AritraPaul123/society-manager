package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.HomeInspection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import java.util.List;

@Repository
public interface IHomeInspectionRepository extends JpaRepository<HomeInspection, Long>, JpaSpecificationExecutor<HomeInspection> {
    @Query("SELECT h.uniqueId FROM HomeInspection h ORDER BY h.id DESC LIMIT 1")
    String findLastUniqueId();

}

