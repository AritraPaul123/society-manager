package com.propertymanageruae.api.payloads.inspection;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InspectionFinalRequest {

    private String witness;
    private String remarks;
}
