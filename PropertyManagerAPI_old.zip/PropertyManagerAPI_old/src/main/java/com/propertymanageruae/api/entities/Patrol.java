package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "patrols")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Patrol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "guard_id", nullable = false)
    private User guard;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    @Column(name = "status")
    private String status; // IN_PROGRESS, COMPLETED, ABORTED, PAUSED

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "route_id")
    private PatrolRoute route;

    @Column(name = "is_offline")
    private Boolean isOffline = false;

    @Column(name = "sync_status")
    private String syncStatus = "SYNCED"; // SYNCED, PENDING

    @Column(name = "pause_time")
    private LocalDateTime pauseTime;

    @Column(name = "resume_time")
    private LocalDateTime resumeTime;

    @Column(name = "paused_count")
    private Integer pausedCount = 0;

    @OneToMany(mappedBy = "patrol", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PatrolLog> logs = new ArrayList<>();
    
    @PrePersist
    protected void onCreate() {
        if(startTime == null) startTime = LocalDateTime.now();
    }
}
