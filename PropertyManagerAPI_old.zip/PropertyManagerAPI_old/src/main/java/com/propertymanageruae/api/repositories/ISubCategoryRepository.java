package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.SubCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ISubCategoryRepository extends JpaRepository<SubCategory, Long> {
    void deleteByCategoryId(long categoryId);
}