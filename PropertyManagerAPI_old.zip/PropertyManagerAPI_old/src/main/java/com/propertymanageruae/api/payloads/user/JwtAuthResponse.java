package com.propertymanageruae.api.payloads.user;


import com.propertymanageruae.api.payloads.master.ViewResidentDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JwtAuthResponse {
    private String token;
    private ViewUserDto user;
    private String refreshToken;
}