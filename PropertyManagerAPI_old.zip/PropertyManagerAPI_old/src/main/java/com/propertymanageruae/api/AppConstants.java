package com.propertymanageruae.api;

public class AppConstants {

    private AppConstants() {} // Prevent instantiation

    public static class RoleConstant {
        public static final long MASTER_ACCESS_USER = 1;
        public static final long SUPERADMIN_USER = 2;
        public static final long ADMIN_USER = 3;
        public static final long STAFF_USER = 4;
        public static final long GROUNDSTAFF_USER = 5;
        public static final long RESIDENTIAL_USER = 6;
    }

    public static class SecurityRoles {
        public static final String ROLE_MASTER = "MASTER_ACCESS";
        public static final String ROLE_SUPERADMIN = "SUPERADMIN";
        public static final String ROLE_ADMIN = "ADMIN";
        public static final String ROLE_STAFF = "STAFF";
        public static final String ROLE_GROUNDSTAFF = "GROUNDSTAFF";
        public static final String ROLE_RESIDENTIAL = "RESIDENTIAL";
    }


    public static class RoleTitle {
        public static final String resident = "Residential";
        public static final String master = "Master Access";
        public static final String admin = "Admin";
        public static final String superAdmin = "Super Admin";
        public static final String staff = "Staff";
        public static final String groundStaff = "Ground Stuff";
    }

    public static class SocietyApartmentArea {
        public static final String FIRST_SOCIETY = "default Society";
        public static final String FIRST_FLAT_BLOCK = "All";
        public static final String FIRST_AREA = "All Area";
    }

    public static class ResidentType {
        public static final String OWNER = "owner";
        public static final String TENANT = "tenant";
    }

    public static class EmailTemplates {
        public static final String DEPOSIT_AMOUNT_TEMPLATE =
                "<p>Hello [NAME],</p>" +
                        "<p><b>Deposit Completed!</b></p>" +
                        "<p>Your INR deposit has been completed and Your account has been recharged with INR [AMOUNT]. You can check your INR balance by logging into your account and heading over to the Profile section.</p>";
        public static final String OTP_SEND_TEMPLATE =
                "<p>Hello [NAME],</p>" +
                        "<p><b>Your OTP for login is: [OTP]</b></p>" +
                        "<p>Please use this OTP to complete your login process. The OTP is valid for 5 minutes.</p>" +
                        "<p>If you did not request this OTP, please ignore this email.</p>";
    }

    public static class NoticeTimeline {
        public static final String UPCOMING = "upcoming";
        public static final String CURRENT = "current";
        public static final String EXPIRED = "expired";
    }

    public static class TargetAudience {
        public static final String OWNERS = "owners";
        public static final String TENANTS = "tenants";
        public static final String BOTH = "both";
    }
    public static class Platform {
        public static final String WEB = "web";
        public static final String MOBILE = "mobile";
    }

    public static class PdfFormat {
        public static final int PAGE_A4_PORTRAIT=1;
        public static final  int PAGE_A4_LANDSCAPE=2;
    }

    public static class Message {
        // 🔹 Common
        public static final String SUCCESS = "Operation completed successfully.";
        public static final String FAILED = "Operation failed. Please try again.";
        public static final String INVALID_REQUEST = "Invalid request parameters.";
        public static final String UNAUTHORIZED = "You are not authorized to perform this action.";
        public static final String ACCESS_DENIED = "Access denied.";
        public static final String INTERNAL_ERROR = "An unexpected error occurred.";

        // 🔹 Save
        public static final String SAVED = "Record saved successfully.";
        public static final String NOT_SAVED = "Record not saved.";
        public static final String ALREADY_EXISTS = "Record already exists.";

        // 🔹 Update
        public static final String UPDATED = "Record updated successfully.";
        public static final String NOT_UPDATED = "Record not updated.";
        public static final String NO_CHANGES = "No changes were made.";

        // 🔹 Delete
        public static final String DELETED = "Record deleted successfully.";
        public static final String NOT_DELETED = "Record not deleted.";
        public static final String CANNOT_DELETE = "Record cannot be deleted.";

        // 🔹 Status
        public static final String ACTIVE = "Record activated successfully.";
        public static final String INACTIVE = "Record deactivated successfully.";
        public static final String ALREADY_ACTIVE = "Record is already active.";
        public static final String ALREADY_INACTIVE = "Record is already inactive.";

        // 🔹 Existence
        public static final String EXISTS = "Record already exists.";
        public static final String NOT_EXISTS = "Record not found.";
        public static final String ID_NOT_FOUND = "Record ID not found.";

        // 🔹 Approval / Rejection / Draft
        public static final String APPROVED = "Record approved successfully.";
        public static final String REJECTED = "Record rejected.";
        public static final String PENDING = "Record is pending for approval.";
        public static final String ALREADY_APPROVED = "Record already approved.";
        public static final String ALREADY_REJECTED = "Record already rejected.";

        public static final String DRAFT_CREATED = "Draft saved successfully.";
        public static final String DRAFT_UPDATED = "Draft updated successfully.";
        public static final String DRAFT_DELETED = "Draft deleted successfully.";
        public static final String DRAFT_NOT_FOUND = "Draft not found.";

        // 🔹 File Upload / Download
        public static final String FILE_UPLOADED = "File uploaded successfully.";
        public static final String FILE_NOT_UPLOADED = "File upload failed.";
        public static final String INVALID_FILE_TYPE = "Invalid file type.";
        public static final String FILE_DELETED = "File deleted successfully.";
        public static final String FILE_NOT_FOUND = "File not found.";

    }
}