package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "route_qr_points")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RouteQRPoint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "route_id", nullable = false)
    private PatrolRoute route;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "qr_point_id", nullable = false)
    private QRPoint qrPoint;

    @Column(name = "sequence_order", nullable = false)
    private Integer sequenceOrder;

    @Column(name = "is_mandatory")
    private Boolean isMandatory = true;

    @PrePersist
    protected void onCreate() {
        if (isMandatory == null) {
            isMandatory = true;
        }
    }
}
