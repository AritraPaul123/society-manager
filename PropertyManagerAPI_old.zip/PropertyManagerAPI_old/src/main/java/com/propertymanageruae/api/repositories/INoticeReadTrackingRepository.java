package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Area;
import com.propertymanageruae.api.entities.NoticeReadTracking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface INoticeReadTrackingRepository extends JpaRepository<NoticeReadTracking, Long>, JpaSpecificationExecutor<NoticeReadTracking> {
    Optional<NoticeReadTracking> findByNoticeIdAndResidentId(long noticeId, long residentId);
    @Query("SELECT COUNT(n) FROM NoticeReadTracking n WHERE n.notice.id = :noticeId AND n.isRead = true")
    long countReadByNoticeId(@Param("noticeId") long noticeId);
}