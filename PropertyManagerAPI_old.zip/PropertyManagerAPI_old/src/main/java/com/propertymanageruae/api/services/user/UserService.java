package com.propertymanageruae.api.services.user;

import com.propertymanageruae.api.AppConstants;
import com.propertymanageruae.api.entities.Role;
import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.entities.UserRoleMapping;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.helper.AppHelper;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import com.propertymanageruae.api.payloads.user.PropertyDto;
import com.propertymanageruae.api.payloads.user.UserDTO;
import com.propertymanageruae.api.payloads.user.UserProfileDto;
import com.propertymanageruae.api.payloads.utils.SocietyRoleDto;
import com.propertymanageruae.api.repositories.IRoleRepository;
import com.propertymanageruae.api.repositories.ISocietyRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import com.propertymanageruae.api.repositories.IUserRoleMappingRepository;
import com.propertymanageruae.api.services.master.IMasterService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UserService implements IUserService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    private IUserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private IRoleRepository roleRepository;
    @Autowired
    private ISocietyRepository societyRepository;
    @Autowired
    private IUserRoleMappingRepository _userRoleMappingRepository;
    @Autowired
    private IMasterService _masterService;

    @Value("${app.version}")
    private String appVersion;

    @Override
    public List<User> getUsers() {
        return this.userRepository.findAll();
    }

    @Override
    public UserDTO register(UserDTO userDto) throws SQLIntegrityConstraintViolationException {
        User user = this.modelMapper.map(userDto, User.class);
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        Optional<Role> fetchRole = this.roleRepository.findById(AppConstants.RoleConstant.MASTER_ACCESS_USER);
        Role role = null;
        if (fetchRole.isPresent()) {
            role = fetchRole.get();
        } else {
            throw new ResourceNotFoundException("Not Found", "role", AppConstants.RoleConstant.MASTER_ACCESS_USER + "");
        }
//        user.getRoles().add(role);
        if (this.userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new SQLIntegrityConstraintViolationException("Email already exits!");
        }
        try {
            Society society = this.societyRepository.findById(userDto.getSocietyId()).orElseThrow(() -> new ResourceNotFoundException("Society Not Found"));
//            user.setSociety(society);
            user.setMemberId(AppHelper.generateUniqueId());
            User newUser = this.userRepository.save(user);

            // ✅ Create UserRoleMapping instead of adding to user.getRoles()
            boolean roleExists = this._userRoleMappingRepository.existsByUserAndRoleAndSociety(user, role, society);
            if (!roleExists) {
                UserRoleMapping mapping = UserRoleMapping.builder()
                        .user(user)
                        .role(role)
                        .society(society)
                        .createdAt(Timestamp.valueOf(LocalDateTime.now()))
                        .build();
                this._userRoleMappingRepository.save(mapping);
            }

//            return this.modelMapper.map(newUser, UserDTO.class);

            UserDTO dto = this.modelMapper.map(newUser, UserDTO.class);
            List<UserRoleMapping> mappings = this._userRoleMappingRepository.findByUser(user);
            List<SocietyRoleDto> societyRoles = mappings.stream().map(mapping -> {
                SocietyRoleDto srd = new SocietyRoleDto();
                srd.setSociety(modelMapper.map(mapping.getSociety(), ViewSocietyDto.class));
                srd.setRole(modelMapper.map(mapping.getRole(), RoleDTO.class));
                return srd;
            }).collect(Collectors.toList());
            dto.setSocietyRoles(societyRoles);
            return dto;

        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException(e.getMessage());
        }
    }


    public String getUser(UserDTO userDto) {
        User user = this.modelMapper.map(userDto, User.class);
        User foundUser = this.userRepository.findByEmail(user.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("user not found", "email", user.getEmail()));
        return "User Found";
    }


    @Override
    public User getUserByMail(String mail) {
        return this.userRepository.findByEmail(mail).orElseThrow(() -> new ResourceNotFoundException("user: ", mail, "not found"));
    }

    @Override
    public UserDTO getUserById(Long id) {
        Optional<User> user = this.userRepository
                .findById(id);
        if (user.isPresent()) {
            return this.modelMapper.map(user, UserDTO.class);
        } else {
            throw new ResourceNotFoundException("user", "id", Long.toString(id));
        }
    }

    @Override
    public UserProfileDto getUserProfile(Long id) {
        try {
            User user = this.userRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found", "id", id.toString()));
            String role = "";
            if(user.getUserRoleMappings().stream().anyMatch(urm -> urm.getRole().getId() == AppConstants.RoleConstant.RESIDENTIAL_USER)){
                role= "resident";
            }else if(user.getUserRoleMappings().stream().anyMatch(urm -> urm.getRole().getId() == AppConstants.RoleConstant.ADMIN_USER)){
                role= "admin";
            }
            UserProfileDto userProfile = UserProfileDto.builder().
                    name(user.getName())
                    .phone(user.getContactNumber())
                    .avatar(user.getProfileUrl())
                    .appVersion(appVersion)
                    .email(user.getEmail())
                    .age(user.getAge())
                    .bio(user.getBio())
                    .location(user.getLocation())
                    .occupation(user.getOccupation())
                    .interests(user.getInterests())
                    .residentType(user.getResidentType())
                    .role(role)
                    .build();
            // Fetch properties if needed
            if(user.getUserRoleMappings().stream().anyMatch(urm -> urm.getRole().getId() == AppConstants.RoleConstant.RESIDENTIAL_USER))
                _masterService
                        .getApartmentListOfResident(user.getEmail())
                    .forEach(property -> {
                        PropertyDto propertyDto = new PropertyDto();
                        propertyDto.setId(property.getId());
                        propertyDto.setName(String.format("%s-%s", property.getBlock(), property.getFlat()));
                        propertyDto.setSocietyName(property.getSocietyName());
                        propertyDto.setStatus(String.format("Residing as %s",property.getResidentType()));
                        propertyDto.setPasscode("1234");
                        userProfile.getProperties().add(propertyDto);
                    });
            return userProfile;
        } catch (Exception e) {
            log.error("Error fetching user profile: {}", e.getMessage());
            return null;
        }
    }
}