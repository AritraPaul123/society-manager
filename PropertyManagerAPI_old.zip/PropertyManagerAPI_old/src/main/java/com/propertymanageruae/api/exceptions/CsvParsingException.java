package com.propertymanageruae.api.exceptions;


public class CsvParsingException extends RuntimeException {
    public CsvParsingException(String message, Throwable cause) {
        super(message, cause);
    }
    public CsvParsingException(String message) {
        super(message);
    }
}