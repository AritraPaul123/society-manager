package com.propertymanageruae.api.payloads.complaint;

import com.propertymanageruae.api.payloads.utils.FileDTO;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class AddComplaintDTO {
    private Long locationId;
    private String priority;
    @NotNull(message = "Category is required")
    private Long categoryId;
    private Long subCategoryId;
    @NotNull(message = "Assignee is required")
    private Long stuffId;
    @Builder.Default
    private Long complainerId = 0L;
    @NotEmpty(message = "Complaint Visibility is required")
    private String complaintVisibility;
    @NotEmpty(message = "Complaint description is required")
    private String complaintDescription;
    private String ticketStatus;
    private long societyId;
    private long areaId;
    private long apartmentId;


}