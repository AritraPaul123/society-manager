package com.propertymanageruae.api.payloads.utils;

import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
public class BulkEmailResponse {
    private List<String> successEmails = new ArrayList<>();
    private List<String> failedEmails = new ArrayList<>();
}