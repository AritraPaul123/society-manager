package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Visitor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VisitorRepository extends JpaRepository<Visitor, Long> {
    List<Visitor> findByStatus(String status);
    List<Visitor> findByApartmentId(Long apartmentId);
    java.util.Optional<Visitor> findByEmiratesId(String emiratesId);
    java.util.Optional<Visitor> findFirstByEmiratesIdOrderByCheckInTimeDesc(String emiratesId);
}
