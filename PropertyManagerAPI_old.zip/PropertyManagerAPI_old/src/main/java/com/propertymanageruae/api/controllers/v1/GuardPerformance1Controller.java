package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.analytics.GuardPerformanceDto;
import com.propertymanageruae.api.services.GuardPerformanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/guard-performance")
public class GuardPerformance1Controller {

    @Autowired
    private GuardPerformanceService performanceService;

    @GetMapping("/{guardId}")
    public ResponseEntity<GuardPerformanceDto> getPerformance(
            @PathVariable Long guardId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(performanceService.getPerformance(guardId, date));
    }

    @GetMapping("/{guardId}/history")
    public ResponseEntity<List<GuardPerformanceDto>> getGuardHistory(@PathVariable Long guardId) {
        return ResponseEntity.ok(performanceService.getGuardHistory(guardId));
    }
}
