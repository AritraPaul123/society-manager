package com.propertymanageruae.api.payloads.notice;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AddNoticeDto {
    private String subject;
    private String description;
    private String notificationType;
    private String recipients;
    private String notify;
    @JsonProperty("isEmailNotification")
    private boolean isEmailNotification;
    @JsonProperty("isScheduleNotification")
    private boolean isScheduleNotification ;
    private List<Long> apartments;
    private List<Long> blocks;
    private long societyId;
    private long postedBy;
    private long createdBy;
    private LocalDateTime postedAt;
    private LocalDateTime updatedAt;
    private LocalDateTime expiredAt;
}