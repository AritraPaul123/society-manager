package com.propertymanageruae.api.services.lease;

import java.util.*;
import java.math.BigDecimal;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.propertymanageruae.api.entities.*;
import com.propertymanageruae.api.repositories.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LeaseService {

    private final LeaseRepository leaseRepository;
    private final PropertyRepository propertyRepository;
    private final TenantRepository tenantRepository;
    private final OwnerRepository ownerRepository;
    private final PaymentRepository paymentRepository;
    private final PaymentService paymentService;
   
  

    // ✅ New Repository for Lease Terms
    private final LeaseTermRepository leaseTermRepository;

    /* ----------------------------- CRUD ----------------------------- */

    public List<Lease> getAll() {
        return leaseRepository.findAll();
    }

    public Lease getById(Long id) {
        return leaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lease not found with ID: " + id));
    }

   


    @Transactional
    public Lease create(Lease lease) {

    // --- Property Handling ---
    Property property;
    if (lease.getProperty() != null && lease.getProperty().getId() != null) {
        property = propertyRepository.findById(lease.getProperty().getId())
                .orElseThrow(() -> new RuntimeException("Property not found"));
    } else {
        property = propertyRepository.save(lease.getProperty());
    }
    lease.setProperty(property);

    // --- Tenant Handling ---
    if (lease.getTenant() != null) {
        if (lease.getTenant().getId() != null) {
            lease.setTenant(tenantRepository.findById(lease.getTenant().getId())
                    .orElseThrow(() -> new RuntimeException("Tenant not found")));
        } else {
            lease.setTenant(tenantRepository.save(lease.getTenant()));
        }
    }

    // --- Owner Handling ---
    if (property.getOwners() != null && !property.getOwners().isEmpty()) {
        Set<Owner> owners = new HashSet<>();
        for (Owner owner : property.getOwners()) {
            Owner savedOwner = null;

            List<Owner> byEmail = owner.getLessorEmail() != null
                    ? ownerRepository.findByLessorEmail(owner.getLessorEmail())
                    : new ArrayList<>();

            List<Owner> byEmiratesId = owner.getLessorEmiratesId() != null
                    ? ownerRepository.findByLessorEmiratesId(owner.getLessorEmiratesId())
                    : new ArrayList<>();

            if (!byEmail.isEmpty()) {
                savedOwner = byEmail.get(0);
            } else if (!byEmiratesId.isEmpty()) {
                savedOwner = byEmiratesId.get(0);
            } else if (owner.getId() != null) {
                savedOwner = ownerRepository.findById(owner.getId()).orElse(null);
            }

            if (savedOwner == null) savedOwner = ownerRepository.save(owner);
            if (savedOwner.getProperties() == null)
                savedOwner.setProperties(new HashSet<>());
            savedOwner.getProperties().add(property);
            owners.add(savedOwner);
        }

        property.setOwners(owners);
        propertyRepository.save(property);
    }

    // --- Temporarily detach lists ---
    List<Payment> originalPayments = lease.getPayments();
    List<LeaseTerm> originalTerms = lease.getTermsAndConditions();

    lease.setPayments(null);
    lease.setTermsAndConditions(null);

    // ✅ STEP 1 — Save lease first and flush to ensure ID is generated
    Lease savedLease = leaseRepository.saveAndFlush(lease);

    // ✅ STEP 2 — Attach Terms and save again
    if (originalTerms != null && !originalTerms.isEmpty()) {
        for (LeaseTerm term : originalTerms) {
            term.setLease(savedLease); // set parent reference
        }
        savedLease.setTermsAndConditions(originalTerms);
        savedLease = leaseRepository.saveAndFlush(savedLease);
    }

    // ✅ STEP 3 — Handle Payments after Lease is saved
    if (originalPayments != null && !originalPayments.isEmpty()) {
        List<Payment> savedPayments = new ArrayList<>();
        for (Payment payment : originalPayments) {
            Payment saved = paymentService.createPaymentForLease(payment, savedLease);
            savedPayments.add(saved);
        }
        savedLease.setPayments(savedPayments);
        savedLease = leaseRepository.saveAndFlush(savedLease);
    }

    return savedLease;
}


@Transactional
public Lease update(Long id, Lease updatedLease) {
    Lease existingLease = leaseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Lease not found"));

    // ---------------- Update Lease fields ----------------
    existingLease.setStartDate(updatedLease.getStartDate());
    existingLease.setEndDate(updatedLease.getEndDate());
    existingLease.setStatus(updatedLease.getStatus());

    // ---------------- Update Property (WITHOUT owners) ----------------
    Property property = existingLease.getProperty();
    Property updatedProperty = updatedLease.getProperty();
    if (property != null && updatedProperty != null) {
        property.setPropertyType(updatedProperty.getPropertyType());
        property.setAddress(updatedProperty.getAddress());
        property.setBuildingName(updatedProperty.getBuildingName());
        property.setUnitName(updatedProperty.getUnitName());
        property.setUnitArea(updatedProperty.getUnitArea());
        // ❗ Owners now updated using separate endpoint → DO NOT TOUCH OWNER LIST HERE
    }

    // ---------------- Update Tenant ----------------
    Tenant tenant = existingLease.getTenant();
    Tenant updatedTenant = updatedLease.getTenant();
    if (tenant != null && updatedTenant != null) {
        tenant.setName(updatedTenant.getName());
        tenant.setEmail(updatedTenant.getEmail());
        tenant.setMobileNo(updatedTenant.getMobileNo());
        tenant.setTenantEmiratesId(updatedTenant.getTenantEmiratesId());
        tenant.setLicenseAuthority(updatedTenant.getLicenseAuthority());
        tenant.setLicenseNo(updatedTenant.getLicenseNo());
    }

    // ---------------- Payments Removed Completely ----------------
    // Payments are now updated using /leases/{id}/payments/... endpoints
    // ❌ Do not clear payments
    // ❌ Do not add payments
    // ❌ Do not modify installments or transactions

    // ---------------- Update Terms ----------------
    if (updatedLease.getTermsAndConditions() != null) {
        // delete old terms
        leaseTermRepository.deleteAll(
                leaseTermRepository.findByLeaseId(existingLease.getId())
        );

        // set lease for new terms
        for (LeaseTerm term : updatedLease.getTermsAndConditions()) {
            term.setLease(existingLease);
        }

        leaseTermRepository.saveAll(updatedLease.getTermsAndConditions());
    }

    return leaseRepository.save(existingLease);
}




@Transactional
public Lease updateOwnersForLease(Long leaseId, List<Owner> owners) {
    // 1️⃣ Fetch the lease
    Lease lease = leaseRepository.findById(leaseId)
            .orElseThrow(() -> new RuntimeException("Lease not found with ID: " + leaseId));

    Property property = lease.getProperty();
    if (property == null) {
        throw new RuntimeException("Lease has no property assigned");
    }

    // 2️⃣ Clear current owners (optional, depends on your business rules)
    property.getOwners().clear();

    // 3️⃣ Update or create owners
    for (Owner incoming : owners) {
        Owner owner;

        if (incoming.getId() != null) {
            // Update existing owner
            owner = ownerRepository.findById(incoming.getId())
                    .orElseThrow(() -> new RuntimeException("Owner not found: " + incoming.getId()));
            // Update fields if provided
            if (incoming.getOwnerName() != null) owner.setOwnerName(incoming.getOwnerName());
            if (incoming.getLessorName() != null) owner.setLessorName(incoming.getLessorName());
            if (incoming.getLessorEmail() != null) owner.setLessorEmail(incoming.getLessorEmail());
            if (incoming.getLessorMobileNo() != null) owner.setLessorMobileNo(incoming.getLessorMobileNo());
            if (incoming.getLessorEmiratesId() != null) owner.setLessorEmiratesId(incoming.getLessorEmiratesId());
            if (incoming.getLessorAuthority() != null) owner.setLessorAuthority(incoming.getLessorAuthority());
            if (incoming.getLicenseNo() != null) owner.setLicenseNo(incoming.getLicenseNo());
        } else {
            // New owner
            owner = ownerRepository.save(incoming);
        }

        // Map owner to property
        if (owner.getProperties() == null) owner.setProperties(new HashSet<>());
        owner.getProperties().add(property);

        property.getOwners().add(owner);
    }

    // 4️⃣ Save property and lease
    propertyRepository.save(property);
    return leaseRepository.save(lease);
}


    @Transactional
    public void delete(Long id) {
        Lease lease = leaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lease not found with ID: " + id));

        // Delete payments
        if (lease.getPayments() != null)
            lease.getPayments().forEach(paymentRepository::delete);

        // ✅ Delete lease terms
        leaseTermRepository.deleteAll(leaseTermRepository.findByLeaseId(lease.getId()));

        // Delete tenant if no other leases
        if (lease.getTenant() != null) {
            var tenant = lease.getTenant();
            List<Lease> tenantLeases = leaseRepository.findByTenant_Id(tenant.getId());
            if (tenantLeases.size() == 1) {
                tenantRepository.delete(tenant);
            }
        }

        // Delete property and owners if isolated
        if (lease.getProperty() != null) {
            Property property = lease.getProperty();
            if (property.getLeases() != null)
                property.getLeases().remove(lease);
            if (property.getOwners() != null) {
                for (Owner owner : new HashSet<>(property.getOwners())) {
                    owner.getProperties().remove(property);
                    if (owner.getProperties().isEmpty()) ownerRepository.delete(owner);
                }
            }
            propertyRepository.delete(property);
        }

        leaseRepository.delete(lease);
    }

    /* ---------------------- Building → Units → Leases ---------------------- */

    public List<String> getBuildingNames() {
        return propertyRepository.findDistinctBuildingNames();
    }

    public List<String> getUnitNamesByBuilding(String buildingName) {
        return propertyRepository.findUnitsByBuildingName(buildingName);
    }

  

    public List<Lease> getLeasesByBuildingAndUnit(String buildingName, String unitName) {

    List<Property> properties = propertyRepository
            .findByBuildingNameAndUnitName(buildingName, unitName);

    if (properties.isEmpty()) {
        throw new RuntimeException("Property not found for " + buildingName + " - " + unitName);
    }

    List<Long> ids = properties.stream()
            .map(Property::getId)
            .toList();

    return leaseRepository.findByPropertyIdIn(ids);
}


    /* ---------------------- Payment Status Update ---------------------- */



@Transactional
public PaymentInstallment updateInstallmentStatusWithPaymentDetails(Long leaseId, Long paymentId, Long installmentId,
                                                                    Map<String, Object> updates) {

    String status = (String) updates.get("status");
    String paymentMode = (String) updates.get("paymentMode");
    String transRef = (String) updates.get("transRef");
    
    String issuerBank = (String) updates.get("issuerBank");
    String issuerAccountNumber = (String) updates.get("issuerAccountNumber");
    String depositedBank = (String) updates.get("depositedBank");
    String depositorAccountNumber = (String) updates.get("depositorAccountNumber");
    String type = (String) updates.get("type");
    String remarks = (String) updates.get("remarks");

    BigDecimal amountPaid = updates.get("amountPaid") != null
            ? new BigDecimal(updates.get("amountPaid").toString())
            : null;

    return paymentService.updateInstallmentStatus(leaseId, paymentId, installmentId,
                                                  status, amountPaid, paymentMode, transRef, 
                                                  issuerBank, issuerAccountNumber, depositedBank, depositorAccountNumber,
                                                  type, remarks);
}


}

