package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"location", "subCategory", "category", "assignedUser", "complainer", "society", "complaintImages", "comments"})
@Builder
@Entity
@Table(name = "complaint")
public class Complaint {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id", nullable = false)
    private Location location;
    @Column(name = "priority")
    private String priority;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "societyId", nullable = false)
    @JsonBackReference
    private Society society;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subcategory_id")
    private SubCategory subCategory;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assignee_id", nullable = false)
    @JsonBackReference("assignee-complaints")
    private User assignedUser;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "complainer_id", nullable = false)
    @JsonBackReference("complainer-complaints")
    private User complainer;
    @Column(name = "complaintVisibility")
    private String complaintVisibility;
    @Column(name = "complaintDescription")
    private String complaintDescription;
    @OneToMany(mappedBy = "complaint", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FileEntity> complaintImages;
    @Column(name = "ticketStatus")
    private String ticketStatus;
    @Column(name = "lastUpdated")
    private LocalDateTime lastUpdated;
    @Column(name = "resolvedTime")
    private LocalDateTime resolvedTime;
    @Column(name = "closedTime")
    private LocalDateTime closedTime;
    @Column(name = "preferredTime")
    private LocalDateTime preferredTime;
    @OneToMany(mappedBy = "complaint", cascade = CascadeType.REMOVE)
    @JsonManagedReference
    private List<CommentMaster> comments;
    @Column(name = "apartmentId", nullable = false, columnDefinition = "BIGINT DEFAULT 0")
    private long apartmentId = 0;
    @Column(name = "areaId", nullable = false, columnDefinition = "BIGINT DEFAULT 0")
    private long areaId = 0;
    @Column(name = "isDelete", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDelete;
    @Column(name = "createdBy",columnDefinition = "BIGINT DEFAULT 0")
    private long modifyBy;
    @Column(name = "deleteBy",columnDefinition = "BIGINT DEFAULT 0")
    private long deleteBy;
    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;
    @Column(name = "ticket_id", nullable = false)
    private String ticketId;

//    @PrePersist
//    protected void onCreate() {
//        this.createdAt = new Timestamp(System.currentTimeMillis());
//    }

    @PreUpdate
    protected void onUpdate() {
        this.lastUpdated = LocalDateTime.now();
    }

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}