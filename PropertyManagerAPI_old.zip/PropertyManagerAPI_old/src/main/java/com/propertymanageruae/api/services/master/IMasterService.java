package com.propertymanageruae.api.services.master;

import com.google.protobuf.ServiceException;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.master.*;
import com.propertymanageruae.api.payloads.user.ViewComplainerDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;


public interface IMasterService {
    String addSociety(AddSocietyDto addSocietyDto);

    UploadDto uploadFile(long societyId, long typeId, MultipartFile file) throws IOException;

    List<ViewSocietyDto> getSocaityList();

    List<ViewAreaDto> getAreaList(long societyId, String searchText);

    List<ViewApartmentDto> getApartmentList(long societyId, long areaId, String searchText);

    PaginationDto<ViewResidentDto> getResidents(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, long societyId);

    PaginationDto<GetApartmentDto> getApartments(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, long societyId);

    //    public void exportDataToExcel(String sheetName, List<String> headers, List<Map<String, Object>> rows, HttpServletResponse response);
    String sendComments(SendCommentsDto sendCommentsDto) throws SQLIntegrityConstraintViolationException;

    String sendCommentsWithImage(SendCommentsDto sendCommentsDto, List<MultipartFile> imageFile) throws IOException, SQLIntegrityConstraintViolationException;

    List<ViewCommentsDto> getCommentList(long societyId);

    List<ResidentSocietyDetailDto> getResidentDetailsByOwnerEmail_old(String ownerEmail);

    String manageResidentSocietyAndBlockWise(ManageResidentDto manageResidentDto) throws ServiceException;

    List<ViewApartmentDto> getApartmentList(long societyId, String searchText);
    List<ViewApartmentOfResidentsDto> getApartmentListOfResident(String email);
    List<ViewComplainerDto> getResidentList(long societyId, long areaId, long apartmentId, String searchText);
 List<ViewApartmentOfResidentsDto> getLocationBySociety(Long societyId, String searchText, int limit, int offset);
}