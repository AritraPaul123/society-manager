package com.propertymanageruae.api.payloads.patrol;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PatrolRouteDto {
    private Long id;
    private String routeName;
    private String description;
    private Long societyId;
    private Boolean isActive;
    private String frequency;
    private List<RouteQRPointDto> qrPoints;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RouteQRPointDto {
        private Long qrPointId;
        private String locationName;
        private Integer sequenceOrder;
        private Boolean isMandatory;
    }
}
