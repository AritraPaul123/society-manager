package com.propertymanageruae.api.payloads.patrol;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QRPointDto {
    private Long id;
    private String qrCode;
    private String locationName;
    private String locationDescription;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Long societyId;
    private Boolean isActive;
}
