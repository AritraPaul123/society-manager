package com.propertymanageruae.api.payloads.location;

import lombok.Data;

@Data
public class LocationDTO {

    private long id;

    private String locationData;


}