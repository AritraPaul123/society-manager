package com.propertymanageruae.api.specificaions;

import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.entities.UserRoleMapping;
import org.springframework.data.jpa.domain.Specification;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import java.util.List;

public class UserSpecification {

    // Filter by Society
    public static Specification<User> hasSocietyId(long societyId) {
        return (root, query, cb) -> {
            Join<User, UserRoleMapping> mapping = root.join("userRoleMappings", JoinType.INNER);
            return cb.equal(mapping.get("society").get("id"), societyId);
        };
    }

    public static Specification<User> hasSocietyOrMaster(long societyId, Long masterRoleId) {
        return (root, query, cb) -> {
            Join<User, UserRoleMapping> mapping = root.join("userRoleMappings", JoinType.INNER);

            return cb.or(
                    cb.equal(mapping.get("society").get("id"), societyId),   // normal users for same society
                    cb.equal(mapping.get("role").get("id"), masterRoleId)    // master user for all societies
            );
        };
    }


    // Filter by Role IDs
    public static Specification<User> hasRoleIds(List<Long> roleIds) {
        return (root, query, cb) -> {
            Join<User, UserRoleMapping> mapping = root.join("userRoleMappings", JoinType.INNER);
            return mapping.get("role").get("id").in(roleIds);
        };
    }

    // User is not deleted
    public static Specification<User> isUserActive() {
        return (root, query, cb) -> cb.isFalse(root.get("isDelete"));
    }

    // Mapping is not deleted
    public static Specification<User> isMappingActive() {
        return (root, query, cb) -> {
            Join<User, UserRoleMapping> mapping = root.join("userRoleMappings", JoinType.INNER);
            return cb.isFalse(mapping.get("isDelete"));
        };
    }

    // Exclude logged-in user
    public static Specification<User> excludeUser(long userId) {
        return (root, query, cb) -> cb.notEqual(root.get("id"), userId);
    }
}