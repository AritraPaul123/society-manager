package com.propertymanageruae.api.services.category;

import com.propertymanageruae.api.entities.Category;
import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.entities.SubCategory;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.exceptions.ResourceNotFoundException;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.category.CategoryDTO;
import com.propertymanageruae.api.payloads.category.SubCategoryDTO;
import com.propertymanageruae.api.payloads.category.ViewCategoryDto;
import com.propertymanageruae.api.repositories.ICategoryRepository;
import com.propertymanageruae.api.repositories.ISocietyRepository;
import com.propertymanageruae.api.repositories.ISubCategoryRepository;
import com.propertymanageruae.api.repositories.IUserRepository;
import com.propertymanageruae.api.services.user.ICustomUserDetailService;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.sql.SQLIntegrityConstraintViolationException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryService implements ICategoryService {
    private static final Logger logger = LoggerFactory.getLogger(CategoryService.class);
    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ICategoryRepository categoryRepository;

    @Autowired
    private ISubCategoryRepository subCategoryRepository;
    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private ICustomUserDetailService customUserDetailService;
    @Autowired
    private ISocietyRepository societyRepository;

    @Override
    @Transactional
    public String addCategory(CategoryDTO categoryDTO) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            Society society = this.societyRepository.findById(categoryDTO.getSocietyId()).orElseThrow(() -> new ResourceNotFoundException("Society No found"));
            User user = this.userRepository
                    .findById(loggedInId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found", "", loggedInId + ""));
            Category category = modelMapper.map(categoryDTO, Category.class);
            category.setSociety(society);
            category.setCreatedBy(user);
            category.getSubCategoryList().forEach(subCategory -> subCategory.setCategory(category));
            Category savedCategory = categoryRepository.save(category);
            if (savedCategory.getId() != 0) {
                return null;
            } else {
                return "Category not added";
            }
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while adding category");
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    @Transactional
    public String editCategory(CategoryDTO categoryDTO, long id) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            User user = this.userRepository
                    .findById(loggedInId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found", "", loggedInId + ""));

            Category existingCategory = categoryRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", Long.toString(id)));
            subCategoryRepository.deleteByCategoryId(id);
            existingCategory.getSubCategoryList().clear();
            existingCategory.setCategory(categoryDTO.getCategory());
            existingCategory.setModifyBy(loggedInId);
            categoryDTO.getSubCategoryList().forEach(subCategoryDTO -> {
                SubCategory subCategory = modelMapper.map(subCategoryDTO, SubCategory.class);
                subCategory.setCategory(existingCategory);
                existingCategory.getSubCategoryList().add(subCategory);
            });
            Category updatedCategory = categoryRepository.save(existingCategory);
            return updatedCategory.getId() != 0 ? null : "category not updated";
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while updating category");
        } catch (Exception ex) {
            throw ex;
        }
    }


    @Override
    @Transactional
    public void deleteCategory(long id) throws SQLIntegrityConstraintViolationException {
        try {
            Category category = categoryRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", Long.toString(id)));
            category.getSubCategoryList().forEach(subCategory -> subCategory.setCategory(null));
            category.getSubCategoryList().clear();
            category.setCreatedBy(null);
            categoryRepository.delete(category);
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while deleting category: " + e.getMessage());
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    @Transactional
    public void softDeleteCategory(long id) throws SQLIntegrityConstraintViolationException {
        try {
            long loggedInId = customUserDetailService.LoggedInUser().getId();
            Category category = categoryRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Category", "id", Long.toString(id)));
            category.setDelete(true);
            category.setDeletedAt(LocalDateTime.now());
            category.setDeleteBy(loggedInId);
            // Update each SubCategory in the existing list
            category.getSubCategoryList().forEach(subCategory -> {
                subCategory.setDelete(true);
                subCategory.setDeletedAt(LocalDateTime.now());
            });

            categoryRepository.save(category);
        } catch (DataIntegrityViolationException e) {
            throw new SQLIntegrityConstraintViolationException("Database constraint violation while soft deleting category: " + e.getMessage());
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    public List<ViewCategoryDto> getCategoryList(long societyId) {
        List<Category> categoryList = this.categoryRepository.findBySocietyIdAndIsDelete(societyId, false);
        return categoryList
                .stream()
                .map(category -> this.modelMapper.map(category, ViewCategoryDto.class))
                .toList();
    }


    @Override
    public PaginationDto<ViewCategoryDto> getCategories(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, long societyId) {
        if (pageNumber < 0 || pageSize <= 0) {
            throw new IllegalArgumentException("Page number must be >= 0 and page size must be > 0");
        }
        Sort.Direction direction = Sort.Direction.fromString(sortDir);
        PageRequest pageable = PageRequest.of(pageNumber, pageSize, Sort.by(direction, sortBy));

        Page<Category> pageCategoryList;
        if (searchText != null && !searchText.trim().isEmpty()) {
            pageCategoryList = this.categoryRepository.findBySocietyIdAndSearchText(societyId, searchText, pageable);
        } else {
            pageCategoryList = this.categoryRepository.findBySocietyIdAndIsDelete(societyId, false, pageable);
        }
        List<ViewCategoryDto> viewCategoryDto = pageCategoryList.getContent()
                .stream()
                .map(category -> modelMapper.map(category, ViewCategoryDto.class))
                .toList();
        PaginationDto<ViewCategoryDto> paginationDto = new PaginationDto<>();
        paginationDto.setContent(viewCategoryDto);
        paginationDto.setPageNumber(pageCategoryList.getNumber());
        paginationDto.setPageSize(pageCategoryList.getSize());
        paginationDto.setTotalPages(pageCategoryList.getTotalPages());
        paginationDto.setTotalElements(pageCategoryList.getTotalElements());
        paginationDto.setLastPage(pageCategoryList.isLast());
        return paginationDto;
    }


    @Override
    public ViewCategoryDto getCategory(long id) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", Long.toString(id)));
        return modelMapper.map(category, ViewCategoryDto.class);
    }

    private CategoryDTO convertToDTO(Category category) {
        CategoryDTO categoryDTO = modelMapper.map(category, CategoryDTO.class);
        List<SubCategoryDTO> subCategoryDTOs = category.getSubCategoryList().stream()
                .map(subCategory -> {
                    return modelMapper.map(subCategory, SubCategoryDTO.class);
                }).collect(Collectors.toList());
        categoryDTO.setSubCategoryList(subCategoryDTOs);
        return categoryDTO;
    }


}