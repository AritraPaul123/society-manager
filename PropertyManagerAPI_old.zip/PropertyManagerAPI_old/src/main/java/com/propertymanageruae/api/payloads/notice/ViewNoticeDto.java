package com.propertymanageruae.api.payloads.notice;

import com.propertymanageruae.api.payloads.master.ViewApartmentDto;
import com.propertymanageruae.api.payloads.master.ViewAreaDto;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.role.RoleDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewNoticeDto {
    private long id;
    private String title;
    private String description;
    private String notificationType;
    private String targetAudience;
    private String notifyTo;
    private boolean isEmailNotification;
    private boolean isScheduleNotification ;
    private ViewApartmentDto apartment;
    private ViewAreaDto area;
    private ViewSocietyDto society;
    private List<ViewNoticeFileDto> noticeFile;
    private boolean isDeleted;
    private ViewUserDto postedBy;
    private long createdBy;
    private long modifiedBy;
    private long deletedBy;
    private LocalDateTime postedAt;
    private LocalDateTime updatedAt;
    private LocalDateTime expiredAt;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
class ViewUserDto{
    private int id;
    private String name;
    private String email;
    private String contactNumber;
    private boolean status;
    private Set<RoleDTO> roles = new HashSet<>();
    private long societyId;
}