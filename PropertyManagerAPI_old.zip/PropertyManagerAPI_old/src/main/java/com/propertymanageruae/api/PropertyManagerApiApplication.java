package com.propertymanageruae.api;

import com.propertymanageruae.api.services.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT30S") // optional default
public class PropertyManagerApiApplication implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    public static void main(String[] args) {
        SpringApplication.run(PropertyManagerApiApplication.class, args);
    }
    @Autowired
    private com.propertymanageruae.api.repositories.IRoleRepository roleRepository;
    @Autowired
    private com.propertymanageruae.api.repositories.ISocietyRepository societyRepository;
    @Autowired
    private com.propertymanageruae.api.repositories.VisitorRepository visitorRepository;
    @Autowired
    private com.propertymanageruae.api.repositories.PatrolRepository patrolRepository;
    @Autowired
    private com.propertymanageruae.api.repositories.IComplaintRepository complaintRepository;
    @Autowired
    private com.propertymanageruae.api.repositories.AttendanceRepository attendanceRepository;
    @Autowired
    private com.propertymanageruae.api.repositories.IUserRepository userRepository;

    @Override
    public void run(String... args) throws Exception {
        try {
            logger.info("Application started successfully. Checking seed data...");
            if (roleRepository.count() == 0) {
                logger.info("Seeding Roles...");
                roleRepository.save(new com.propertymanageruae.api.entities.Role(1, "MASTER_ACCESS_USER", "Master Access", new java.util.ArrayList<>(), false, null, null, null));
                roleRepository.save(new com.propertymanageruae.api.entities.Role(2, "SUPERADMIN_USER", "Super Admin", new java.util.ArrayList<>(), false, null, null, null));
                roleRepository.save(new com.propertymanageruae.api.entities.Role(3, "ADMIN_USER", "Admin", new java.util.ArrayList<>(), false, null, null, null));
                roleRepository.save(new com.propertymanageruae.api.entities.Role(4, "STAFF_USER", "Staff", new java.util.ArrayList<>(), false, null, null, null));
                roleRepository.save(new com.propertymanageruae.api.entities.Role(5, "GROUNDSTAFF_USER", "Ground Staff", new java.util.ArrayList<>(), false, null, null, null));
                roleRepository.save(new com.propertymanageruae.api.entities.Role(6, "RESIDENTIAL_USER", "Residential", new java.util.ArrayList<>(), false, null, null, null));
            }
            if (societyRepository.count() == 0) {
                 logger.info("Seeding Society...");
                 com.propertymanageruae.api.entities.Society defaultSociety = new com.propertymanageruae.api.entities.Society();
                 defaultSociety.setId(1);
                 defaultSociety.setSocietyName("Default Society");
                 defaultSociety.setSocietyEmail("admin@society.com");
                 defaultSociety.setSocietyType(com.propertymanageruae.api.enums.SocietyType.UNPUBLISH);
                 defaultSociety.setSocietyId("1");
                 societyRepository.save(defaultSociety);
            }

            // Mock Data Seeding
            if(visitorRepository.count() == 0) {
                logger.info("Seeding Visitors...");
                var v1 = new com.propertymanageruae.api.entities.Visitor();
                v1.setName("John Doe"); v1.setMobileNumber("1234567890"); v1.setVisitPurpose("Delivery"); v1.setStatus("CHECKED_IN"); v1.setGateNumber("1");
                visitorRepository.save(v1);
                var v2 = new com.propertymanageruae.api.entities.Visitor();
                v2.setName("Jane Smith"); v2.setMobileNumber("0987654321"); v2.setVisitPurpose("Guest"); v2.setStatus("CHECKED_OUT"); v2.setGateNumber("2");
                visitorRepository.save(v2);
            }

            if(patrolRepository.count() == 0) {
                 logger.info("Seeding Patrols...");
                 // Need a user as guard
                 var guard = userRepository.findByEmail("admin@society.com").orElse(null); // use admin as guard fallback
                 if(guard != null) {
                     var p1 = new com.propertymanageruae.api.entities.Patrol();
                     p1.setGuard(guard); p1.setStatus("COMPLETED"); p1.setStartTime(java.time.LocalDateTime.now().minusHours(2)); p1.setEndTime(java.time.LocalDateTime.now().minusHours(1));
                     patrolRepository.save(p1);
                     var p2 = new com.propertymanageruae.api.entities.Patrol();
                     p2.setGuard(guard); p2.setStatus("IN_PROGRESS"); p2.setStartTime(java.time.LocalDateTime.now());
                     patrolRepository.save(p2);
                 }
            }

            if(attendanceRepository.count() == 0) {
                logger.info("Seeding Attendance...");
                var user = userRepository.findByEmail("admin@society.com").orElse(null);
                if(user != null) {
                    var a1 = new com.propertymanageruae.api.entities.Attendance();
                    a1.setUser(user); a1.setStatus("PRESENT"); a1.setCheckInTime(java.time.LocalDateTime.now().minusHours(4));
                    attendanceRepository.save(a1);
                }
            }

        } catch (Exception e) {
            logger.error("Error on seeding/main: {}", e.getLocalizedMessage());
            e.printStackTrace();
        }
    }
}