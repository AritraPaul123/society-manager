package com.propertymanageruae.api.controllers.v1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.master.AddSocietyDto;
import com.propertymanageruae.api.payloads.master.ViewSocietyDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v${api.version}/society")
@SecurityRequirement(name = "auth")
@Tag(name = "Society", description = "Society Management APIs")
public class Society1Controller {

    @Value("${api.version}")
    private String apiVersion;

    private final UnitService _unitService;

    public Society1Controller(UnitService unitService) {
        this._unitService = unitService;
    }

    @Operation(summary = "Add new Society")
    @PostMapping
    public ResponseEntity<ApiResponse<String>> addSociety(@Valid @RequestBody AddSocietyDto dto) {
        String societyId = _unitService.societyService.addSociety(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(societyId, "Society Added Successfully.", null, HttpStatus.CREATED.value()));
    }

    @Operation(summary = "Update existing Society")
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> updateSociety(@PathVariable("id") Long id,
                                                           @Valid @RequestBody AddSocietyDto dto) {
        _unitService.societyService.updateSociety(id, dto);
        return ResponseEntity.ok(ApiResponse.success(null, "Society updated successfully", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Fetched All Society For Web")
    @GetMapping("/all-society")
    public ResponseEntity<ApiResponse<List<ViewSocietyDto>>> getAllSocietyInWeb() {
        List<ViewSocietyDto> societyDTOS = _unitService.societyService.getAllSocietyForWeb();
        return ResponseEntity.ok(
                ApiResponse.success(societyDTOS, "All society fetched successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(description = "Get Society", summary = "This is summary for society get endpoint")
    @GetMapping("/all-society-paginate")
    public ResponseEntity<ApiResponse<List<ViewSocietyDto>>> getAllSocietyInWebWithPaginate(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(value = "searchText", required = false) String searchText
    ) throws JsonProcessingException {
        PaginationDto<ViewSocietyDto> societyDtos = _unitService.societyService.getAllSocietyInWebWithPaginate (pageNumber, pageSize, sortBy, sortDir, searchText);
        List<ViewSocietyDto> societyDto = societyDtos.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", societyDtos.getPageSize());
        metadata.put("PageNumber", societyDtos.getPageNumber());
        metadata.put("TotalPages", societyDtos.getTotalPages());
        metadata.put("TotalElements", societyDtos.getTotalElements());
        metadata.put("IsFirstPage", societyDtos.isFirstPage());
        metadata.put("IsLastPage", societyDtos.isLastPage());
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(societyDto, "Society retrieved successfully", null, HttpStatus.OK.value())
        );
    }

    @Operation(summary = "Get Society By Id (only not-deleted & published)")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ViewSocietyDto>> getSocietyById(@PathVariable Long id) {
        ViewSocietyDto dto = _unitService.societyService.getSocietyById(id);
        return ResponseEntity.ok(ApiResponse.success(dto, "Fetched society", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Soft delete society")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteSociety(@PathVariable Long id, @RequestParam(required = false, defaultValue = "0") long deletedBy) {
        _unitService.societyService.deleteSociety(id, deletedBy);
        return ResponseEntity.ok(ApiResponse.success(null, "Society deleted successfully", null, HttpStatus.OK.value()));
    }

    @Operation(summary = "Toggle publish (patch)")
    @PatchMapping("/{id}/publish")
    public ResponseEntity<ApiResponse<ViewSocietyDto>> togglePublish(@PathVariable Long id,
                                                                     @RequestParam boolean publish,
                                                                     @RequestParam(required = false, defaultValue = "0") long modifyBy) {
        ViewSocietyDto updated = _unitService.societyService.togglePublish(id, publish, modifyBy);
        return ResponseEntity.ok(ApiResponse.success(updated, "Publish state updated", null, HttpStatus.OK.value()));
    }
}