package com.propertymanageruae.api.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "notice")
@ToString
public class Notice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private long id;
    @Column(name = "notice_id", nullable = false, updatable = false)
    private String noticeId;
    @Column(name = "title", nullable = false)
    private String title;
    @Lob
    @Column(name = "description", columnDefinition = "LONGBLOB")
    private byte[] description;
    @Column(name = "notification_type", nullable = false)
    private String notificationType;
    @Column(name = "target_audience", nullable = false)
    private String targetAudience;
    @Column(name = "notify_to")
    private String notifyTo;
    @Builder.Default
    @Column(name = "is_email_notification", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isEmailNotification = false;
    @Builder.Default
    @Column(name = "is_schedule_notification", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isScheduleNotification = false;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "apartment_id", nullable = false)
    @JsonIgnore
    @ToString.Exclude
    private Apartment apartment;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "area_id", nullable = false)
    @JsonIgnore
    @ToString.Exclude
    private Area area;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "society_id", nullable = false)
    @JsonIgnore
    @ToString.Exclude
    private Society society;
    @OneToMany(mappedBy = "notice", cascade = CascadeType.ALL, orphanRemoval = true)
    @ToString.Exclude
    private List<NoticeFiles> noticeFile;
    @Builder.Default
    @Column(name = "is_deleted", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDeleted = false;
    @Column(name = "expired", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean expired = false;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "posted_by", nullable = false)
    @ToString.Exclude
    private User postedBy;
    @Builder.Default
    @Column(name = "created_by", columnDefinition = "BIGINT DEFAULT 0")
    private long createdBy = 0;
    @Builder.Default
    @Column(name = "total_send", columnDefinition = "BIGINT DEFAULT 0")
    private long totalSend = 0;
    @Builder.Default
    @Column(name = "modified_by", columnDefinition = "BIGINT DEFAULT 0")
    private long modifiedBy = 0;
    @Builder.Default
    @Column(name = "deleted_by", columnDefinition = "BIGINT DEFAULT 0")
    private long deletedBy = 0;
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private Instant createdAt;
    @Column(name = "posted_at", updatable = false)
    private Instant  postedAt;
    @Column(name = "updated_at")
    private Instant  updatedAt;
    @Column(name = "expired_at")
    private Instant expiredAt;

    @PreRemove
    protected void onDelete() {
        this.isDeleted = true;
        this.expiredAt = Instant.now();
    }
}