package com.propertymanageruae.api.payloads.inspection;

import com.propertymanageruae.api.entities.InspectionSection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.RequestPart;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SectionImageDTO {
    private Long inspectionId;
    private Long sectionId;
    private String amount;
    private String description;


}
