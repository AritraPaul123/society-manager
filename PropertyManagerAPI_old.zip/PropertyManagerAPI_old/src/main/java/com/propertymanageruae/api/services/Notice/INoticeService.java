package com.propertymanageruae.api.services.Notice;


import com.propertymanageruae.api.entities.Notice;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.notice.AddNoticeDto;
import com.propertymanageruae.api.payloads.notice.ViewNoticeDto;
import com.propertymanageruae.api.payloads.notice.ViewNoticeGroupDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

public interface INoticeService {
    void markNoticeAsRead(long noticeId, long residentId);

    long getReadCountByNoticeId(long noticeId);

    PaginationDto<ViewNoticeDto> getNotices(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, String noticeTimeline, long societyId);

    String postNotice(AddNoticeDto noticeDto, List<MultipartFile> files) throws IOException;

    PaginationDto<ViewNoticeGroupDto> getNoticesGroup(int pageNumber, int pageSize, String sortBy, String sortDir, String searchText, String noticeTimeline, long societyId,String userTimezone);

    void doExpiredNotice(long id) throws SQLIntegrityConstraintViolationException;

    List<ViewNoticeGroupDto> getFilteredNotices(Long societyId, Long areaId, Long apartmentId, String targetAudience);
    ViewNoticeGroupDto getActiveNoticeById(String noticeId);
}