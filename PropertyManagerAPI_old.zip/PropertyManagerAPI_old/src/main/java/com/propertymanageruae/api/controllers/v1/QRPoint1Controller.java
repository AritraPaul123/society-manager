package com.propertymanageruae.api.controllers.v1;

import com.propertymanageruae.api.payloads.patrol.QRPointDto;
import com.propertymanageruae.api.services.QRPointService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/qr-points")
public class QRPoint1Controller {

    @Autowired
    private QRPointService qrPointService;

    @PostMapping("/")
    public ResponseEntity<QRPointDto> createQRPoint(@RequestBody QRPointDto qrPointDto) {
        return new ResponseEntity<>(qrPointService.createQRPoint(qrPointDto), HttpStatus.CREATED);
    }

    @GetMapping("/society/{societyId}")
    public ResponseEntity<List<QRPointDto>> getQRPointsBySociety(@PathVariable Long societyId) {
        return ResponseEntity.ok(qrPointService.getQRPointsBySociety(societyId));
    }

    @GetMapping("/{qrCode}/generate")
    public ResponseEntity<String> generateQRCode(@PathVariable String qrCode) {
        try {
            String base64Image = qrPointService.generateQRCodeImage(qrCode);
            return ResponseEntity.ok(base64Image);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error generating QR code");
        }
    }
}
