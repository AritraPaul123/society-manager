package com.propertymanageruae.api.services.notification;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.propertymanageruae.api.entities.User;
import com.propertymanageruae.api.enums.NotificationType;
import com.propertymanageruae.api.payloads.notification.NotificationDto;

import java.util.List;

public interface INotificationService {
    void sendNotificationToUser(User user, String title, String body) throws FirebaseMessagingException;
    void sendNotificationToUsers(List<User> users, String title, String body) throws FirebaseMessagingException;
    void notifyComplaintStatusChange(User user, Long complaintId, String oldStatus,
                                            String newStatus, String complaintTitle)
            throws FirebaseMessagingException;
    List<com.propertymanageruae.api.entities.Notification> getMyNotifications(Long userId);
    void markAllRead(Long userId);
    NotificationDto createAndPublish(Long userId, String title, String message, NotificationType type) ;
    List<NotificationDto> createAndPublishToUsers(
            List<Long> userIds,
            String title,
            String message,
            NotificationType type
    );
    void markRead(Long notificationId, Long userId);

}