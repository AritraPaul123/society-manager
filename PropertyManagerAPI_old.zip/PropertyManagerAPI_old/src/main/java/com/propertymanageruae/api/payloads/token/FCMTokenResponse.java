package com.propertymanageruae.api.payloads.token;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FCMTokenResponse {
    private Long userId;
    private String fcmToken;
}