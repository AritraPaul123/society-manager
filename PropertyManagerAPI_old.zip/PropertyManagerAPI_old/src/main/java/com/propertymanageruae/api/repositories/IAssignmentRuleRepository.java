package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.AssignmentRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IAssignmentRuleRepository extends JpaRepository<AssignmentRule, Long> {
    @Query("SELECT ar FROM AssignmentRule ar LEFT JOIN FETCH ar.assignmentSlots")
    List<AssignmentRule> findAllWithSlots();

}