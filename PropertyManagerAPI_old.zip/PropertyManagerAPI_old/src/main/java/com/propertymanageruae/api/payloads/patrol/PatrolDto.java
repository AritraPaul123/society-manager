package com.propertymanageruae.api.payloads.patrol;

import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class PatrolDto {
    private Long id;
    private Long guardId;
    private String guardName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
    private Long routeId;
    private String routeName;
    private Boolean isOffline;
    private String syncStatus;
    private LocalDateTime pauseTime;
    private LocalDateTime resumeTime;
    private Integer pausedCount;
    private List<PatrolLogDto> logs;

    @Data
    public static class PatrolLogDto {
        private Long id;
        private String checkpointName;
        private LocalDateTime scannedTime;
        private String comments;
        private Long qrPointId;
        private String photoUrl;
        private Boolean isPhotoMandatory;
        private java.math.BigDecimal latitude;
        private java.math.BigDecimal longitude;
        private String syncStatus;
    }
}
