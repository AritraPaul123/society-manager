package com.propertymanageruae.api.controllers.v1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.propertymanageruae.api.payloads.PaginationDto;
import com.propertymanageruae.api.payloads.category.CategoryDTO;
import com.propertymanageruae.api.payloads.category.ViewCategoryDto;
import com.propertymanageruae.api.payloads.utils.ApiResponse;
import com.propertymanageruae.api.services.UnitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v${api.version}/category")
@SecurityRequirement(name = "auth")
@Tag(name = "Category")
public class Category1Controller {
    @Value("${api.version}")
    private String apiVersion;
    @Autowired
    private UnitService _unitService;

    @Operation(description = "Get endpoint for categories", summary = "This is summary for category get endpoint")
    @GetMapping("/all-category/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewCategoryDto>>> getCategories(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) int pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "5", required = false) int pageSize,//5
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir,
            @RequestParam(value = "searchText", required = false) String searchText,
            @PathVariable("societyId") long societyId
    ) throws JsonProcessingException {
        PaginationDto<ViewCategoryDto> categoryDTOs = this._unitService.categoryService.getCategories(pageNumber, pageSize, sortBy, sortDir, searchText, societyId);
        List<ViewCategoryDto> categoryDto = categoryDTOs.getContent();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("PageSize", categoryDTOs.getPageSize());
        metadata.put("PageNumber", categoryDTOs.getPageNumber());
        metadata.put("TotalPages", categoryDTOs.getTotalPages());
        metadata.put("TotalElements", categoryDTOs.getTotalElements());
        metadata.put("IsFirstPage", categoryDTOs.isFirstPage());
        metadata.put("IsLastPage", categoryDTOs.isLastPage());

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Pagination", new ObjectMapper().writeValueAsString(metadata));
        return ResponseEntity.ok().headers(headers).body(
                ApiResponse.success(categoryDto, "Categories retrieved successfully", null, HttpStatus.OK.value())
        );
    }

    @GetMapping("/category-list/{societyId}")
    public ResponseEntity<ApiResponse<List<ViewCategoryDto>>> getCategoryListBySocietyId(@PathVariable("societyId") long societyId) {
        return ResponseEntity.ok(
          ApiResponse.success(this._unitService.categoryService.getCategoryList(societyId),"Category List retrieved successfully",null, HttpStatus.OK.value())
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ViewCategoryDto>> getCategory(@PathVariable("id") int id) {
        ViewCategoryDto categoryDTO = this._unitService.categoryService.getCategory(id);
        return ResponseEntity.ok(
                ApiResponse.success(categoryDTO, "Category retrieved successfully", null, HttpStatus.OK.value())
        );
    }


    @PostMapping("/add-category")
    public ResponseEntity<ApiResponse<String>> addCategory(@Valid @RequestBody CategoryDTO categoryDTO) throws SQLIntegrityConstraintViolationException {
        String msg = this._unitService.categoryService.addCategory(categoryDTO);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success(null, "Category added successfully", null, HttpStatus.CREATED.value()));
        }
    }


    @PutMapping("/edit-category/{id}")
    public ResponseEntity<ApiResponse<String>> editCategory(@Valid @RequestBody CategoryDTO categoryDTO, @PathVariable("id") int id) throws SQLIntegrityConstraintViolationException {
        String msg = this._unitService.categoryService.editCategory(categoryDTO, id);
        if (msg != null) {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.error(msg, null, null, HttpStatus.OK.value()));
        } else {
            return ResponseEntity.status(HttpStatus.OK)
                    .body(ApiResponse.success(null, "Category updated successfully", null, HttpStatus.OK.value()));
        }

    }

    @PutMapping("/delete-category/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteCategory(@PathVariable("id") int id) throws Exception {
        this._unitService.categoryService.softDeleteCategory(id);
        return ResponseEntity.ok(
                ApiResponse.success(null, "Category deleted successfully", null, HttpStatus.OK.value())
        );
    }
}