package com.propertymanageruae.api.payloads.visitor;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VisitorDraftDto {
    private Long id;
    private Long guardId;
    private String name;
    private String emiratesId;
    private String mobileNumber;
    private String companyName;
    private String visitPurpose;
    private Long apartmentId;
    private String photoUrl;
    private LocalDateTime createdAt;
    private LocalDateTime expiresAt;
}
