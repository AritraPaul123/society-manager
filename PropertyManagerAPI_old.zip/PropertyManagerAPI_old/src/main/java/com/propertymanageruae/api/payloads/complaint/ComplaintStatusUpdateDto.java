package com.propertymanageruae.api.payloads.complaint;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ComplaintStatusUpdateDto {
    private String ticketStatus;
    private Long stuffId;
    private Long categoryId;
    private Long locationId;
    private Long areaId;
    private Long apartmentId;
    private Long societyId;
    private String priority;
    private String complaintVisibility;
}