package com.propertymanageruae.api.config;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class ModelMapperConfig {
    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration()
                .setMatchingStrategy(MatchingStrategies.STRICT)   // For strict field mapping
                .setFieldMatchingEnabled(true)                    // Allow field matching
                .setFieldAccessLevel(org.modelmapper.config.Configuration.AccessLevel.PRIVATE)  // Bypass getters/setters
                .setSkipNullEnabled(true)
                .setPropertyCondition(Conditions.isNotNull())// Skip null values during mapping
                .setAmbiguityIgnored(true);// Avoid ambiguity errors
        modelMapper.getConfiguration()
                .setCollectionsMergeEnabled(false);
        return modelMapper;
    }
}