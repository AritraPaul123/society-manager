package com.propertymanageruae.api.payloads.attendance;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AttendanceDto {
    private Long id;
    private Long userId;
    private String userName;
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private String status;
    private String location;
    private String photoUrl;
}
