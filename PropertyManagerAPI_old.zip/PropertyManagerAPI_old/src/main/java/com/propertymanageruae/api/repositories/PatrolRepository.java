package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Patrol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PatrolRepository extends JpaRepository<Patrol, Long> {
    List<Patrol> findByGuardId(Long guardId);
    List<Patrol> findByStatus(String status);
}
