package com.propertymanageruae.api.services.ExternalService;

import com.propertymanageruae.api.payloads.ExternalDTO.MailDto;
import com.propertymanageruae.api.payloads.ExternalDTO.WelcomeEmailDto;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public interface IMailService {
    CompletableFuture<Boolean> sendMail(MailDto mailModel);
    CompletableFuture<Boolean> sendEmail(MailDto request);
    CompletableFuture<Boolean> sendWelcomeEmail(WelcomeEmailDto welcomeEmail);
    void sendBulkEmail(List<String> recipients, String name,String description, List<MultipartFile> file);
}