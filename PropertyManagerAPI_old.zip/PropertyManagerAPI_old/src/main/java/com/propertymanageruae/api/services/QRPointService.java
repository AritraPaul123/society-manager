package com.propertymanageruae.api.services;

import com.propertymanageruae.api.entities.QRPoint;
import com.propertymanageruae.api.entities.Society;
import com.propertymanageruae.api.payloads.patrol.QRPointDto;
import com.propertymanageruae.api.repositories.QRPointRepository;
import com.propertymanageruae.api.repositories.SocietyRepository;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class QRPointService {

    @Autowired
    private QRPointRepository qrPointRepository;

    @Autowired
    private SocietyRepository societyRepository;

    @Autowired
    private ModelMapper modelMapper;

    public QRPointDto createQRPoint(QRPointDto qrPointDto) {
        QRPoint qrPoint = modelMapper.map(qrPointDto, QRPoint.class);
        Society society = societyRepository.findById(qrPointDto.getSocietyId())
                .orElseThrow(() -> new RuntimeException("Society not found"));
        qrPoint.setSociety(society);
        
        QRPoint saved = qrPointRepository.save(qrPoint);
        return modelMapper.map(saved, QRPointDto.class);
    }

    public List<QRPointDto> getQRPointsBySociety(Long societyId) {
        Society society = societyRepository.findById(societyId)
                .orElseThrow(() -> new RuntimeException("Society not found"));
        return qrPointRepository.findBySociety(society).stream()
                .map(p -> modelMapper.map(p, QRPointDto.class))
                .collect(Collectors.toList());
    }

    public String generateQRCodeImage(String qrCodeText) throws Exception {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, 250, 250);

        ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
        MatrixToImageWriter.writeToStream(bitMatrix, "PNG", pngOutputStream);
        byte[] pngData = pngOutputStream.toByteArray();
        return Base64.getEncoder().encodeToString(pngData);
    }
}
