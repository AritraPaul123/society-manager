package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.AssignmentSlot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IAssignmentSlotRepository extends JpaRepository<AssignmentSlot, Long> {
}