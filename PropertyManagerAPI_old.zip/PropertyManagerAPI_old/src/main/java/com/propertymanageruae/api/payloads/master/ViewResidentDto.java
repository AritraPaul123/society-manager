package com.propertymanageruae.api.payloads.master;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewResidentDto {
    private long id;
    private String bhk;
    private String sqFeetArea;
    private String ownerName;
    private String ownerPhone;
    private String ownerSecondaryPhone;
    private String ownerEmail;
    private String tenantName;
    private String tenantPhone;
    private String tenantSecondaryPhone;
    private String tenantEmail;
    private String residentType;
    private Boolean parking;
    private String accommodationType;
    private String primaryOwnerPhone;
    private String primaryTenantPhone;
    private String meterId;
    private String consumerId;
    private String sanctionedLoadKW;
    private String sanctionedDGLoadKV;
    private Integer numberPipedGasUsers;
    private boolean isDelete;
    private LocalDateTime possessionDate;
    private ViewApartmentDto apartment;
    private ViewAreaDto area;
    private ViewSocietyDto society;

}