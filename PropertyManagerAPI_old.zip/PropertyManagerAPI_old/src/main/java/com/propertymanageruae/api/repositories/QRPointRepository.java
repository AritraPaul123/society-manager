package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.QRPoint;
import com.propertymanageruae.api.entities.Society;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface QRPointRepository extends JpaRepository<QRPoint, Long> {
    Optional<QRPoint> findByQrCode(String qrCode);
    List<QRPoint> findBySocietyAndIsActiveTrue(Society society);
    List<QRPoint> findBySociety(Society society);
}
