package com.propertymanageruae.api.payloads.notification;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ComplaintStatusChangePayload {
    private Long complaintId;
    private String oldStatus;
    private String newStatus;
    private String complaintTitle;
}