package com.propertymanageruae.api.payloads.master;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewSocietyDto {
    private long id;
    private String societyName;
    private String societyPhone;
    private String societyEmail;
    private String societyType;
    private String city;
    private String country;
    private String longitude;
    private String latitude;
    private String societyId;
}