package com.propertymanageruae.api.entities;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SourceType;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "home_inspection")
public class HomeInspection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, updatable = false)
    private Long id;

    @Column(name = "society_id", nullable = false)
    private Long societyId;

    @Column(name = "apartment_id", nullable = false)
    private Long apartmentId;

    @OneToMany(mappedBy = "homeInspection", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<InspectionSection> inspectionSections = new ArrayList<>();

    @Column(name = "floor", nullable = false)
    private String floor;

    @Column(name = "block", nullable = false)
    private String block;

    @Column(name = "society_name", nullable = false)
    private String societyName;

    @Column(name = "flat", nullable = false)
    private String flat;

    @Column(name = "remarks", length = 1000)
    private String remarks;

    @Column(name = "witness", length = 100)
    private String witness;

    @Column(name = "unique_id")
    private String uniqueId;

    @Column(name = "is_move_in", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isMoveIn;

    @Column(name = "status", nullable = false)
    private int status;

    @Column(name = "is_deleted", columnDefinition = "BOOLEAN DEFAULT FALSE")
    private boolean isDeleted = false;

    @Column(name = "created_by", columnDefinition = "BIGINT DEFAULT 0")
    private Long createdBy = 0L;

    @Column(name = "modified_by", columnDefinition = "BIGINT DEFAULT 0")
    private Long modifiedBy = 0L;

    @Column(name = "deleted_by", columnDefinition = "BIGINT DEFAULT 0")
    private Long deletedBy = 0L;

    @CreationTimestamp(source = SourceType.DB)
    @Column(name = "created_at", updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp createdAt;

    @UpdateTimestamp(source = SourceType.DB)
    @Column(name = "updated_at")
    private Timestamp updatedAt;

    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @PreRemove
    protected void onDelete() {
        this.deletedAt = LocalDateTime.now();
    }
}

