package com.propertymanageruae.api.payloads.master;

import com.propertymanageruae.api.entities.Society;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewCommentsDto {
    private long id;
    private String comments;
    private boolean isDelete;
    private long commentBy;
    private String userType;
    private Long societyId;
    private Person person;
    private String imageUrl;
    private List<ViewCommentImageDto> images;
    private Timestamp createdAt;
}

@Data
@AllArgsConstructor
@NoArgsConstructor
class ViewCommentImageDto {
    private long id;
    private String imageName;
    private String awsUrl;
    private Long imageSize;
    private String imageType;
    private String imageCategory;
    private String imageUrl;
    private Timestamp createdAt;
}