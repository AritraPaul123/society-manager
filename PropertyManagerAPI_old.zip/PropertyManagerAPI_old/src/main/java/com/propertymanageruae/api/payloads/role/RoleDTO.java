package com.propertymanageruae.api.payloads.role;


import lombok.Data;

@Data
public class RoleDTO {
    private int id;
    private String name;
    private String title;
}