package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.InspectionSection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IInspectionSectionRepository extends JpaRepository<InspectionSection,Long> {
    Optional<InspectionSection> findByHomeInspectionId(long id);


}
