package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.Area;
import com.propertymanageruae.api.entities.Society;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IAreaRepository extends JpaRepository<Area, Long>, JpaSpecificationExecutor<Area> {
    Optional<Area> findBySocietyAndArea(Society society, String block);
    List<Area> findBySociety(Society society);
    boolean existsByAreaAndTypeAndSociety(
            String area,
            String type,
            Society society
    );

}