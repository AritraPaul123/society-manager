package com.propertymanageruae.api.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.propertymanageruae.api.entities.PaymentInstallment;

public interface PaymentInstallmentRepository extends JpaRepository<PaymentInstallment, Long> {
    List<PaymentInstallment> findByPaymentIdOrderByInstallmentNo(Long paymentId);
}
