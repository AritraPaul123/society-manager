package com.propertymanageruae.api.payloads.master;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewApartmentDto {
    private long id;
    private String block;
    private String floor;
    private String flat;
    private String intercom;
}