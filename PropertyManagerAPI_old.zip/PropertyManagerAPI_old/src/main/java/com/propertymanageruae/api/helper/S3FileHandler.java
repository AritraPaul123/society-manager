package com.propertymanageruae.api.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Component
public class S3FileHandler {
    private final S3Client s3Client;
    private final S3Presigner s3Presigner;
    @Value("${application.bucket.name}")
    private String bucketName;

    public S3FileHandler(S3Client s3Client, S3Presigner s3Presigner) {
        this.s3Client = s3Client;
        this.s3Presigner = s3Presigner;
    }


    public void validateFile(MultipartFile file) {
        if (file.getSize() > 50 * 1024 * 1024) { // 50MB
            throw new IllegalArgumentException("File size exceeds limit of 50MB");
        }
        String contentType = file.getContentType();
//        System.out.println("Content Type: " + contentType);
//        if (!"image/jpeg".equals(contentType)
//                && !"image/jpg".equals(contentType)
//                && !"image/png".equals(contentType)
//                && !"application/pdf".equals(contentType)) {
//            throw new IllegalArgumentException("Only JPG, PNG, and PDF files are allowed");
//        }
        List<String> allowedContentTypes = Arrays.asList(
                "image/jpeg", "image/png", "application/pdf", "application/octet-stream"
        );

        if (!allowedContentTypes.contains(contentType)) {
            throw new IllegalArgumentException("Only JPEG (JPG), PNG, and PDF files are allowed");
        }

    }

    public String storeFile(MultipartFile file) throws IOException {
        String originalFileName = StringUtils.cleanPath(Objects.requireNonNull(file.getOriginalFilename()));
        if (originalFileName.contains("..")) {
            throw new SecurityException("Invalid file path: " + originalFileName);
        }
        String fileExtension = getFileExtension(originalFileName);
        String uniqueFileName = UUID.randomUUID().toString() + "." + fileExtension;

        s3Client.putObject(
                PutObjectRequest.builder()
                        .bucket(bucketName)
                        .key(uniqueFileName)
                        .contentType(file.getContentType())
                        .build(),
                RequestBody.fromInputStream(file.getInputStream(), file.getSize())
        );

        return uniqueFileName;
    }

    public void deleteFile(String fileName) {
        s3Client.deleteObject(DeleteObjectRequest.builder()
                .bucket(bucketName)
                .key(fileName)
                .build());
    }


    public byte[] downloadFile(String fileName) throws IOException {
        try {
            ResponseBytes<GetObjectResponse> objectBytes = s3Client.getObject(
                    GetObjectRequest.builder()
                            .bucket(bucketName)
                            .key(fileName)
                            .build(),
                    ResponseTransformer.toBytes()
            );
            return objectBytes.asByteArray();
        } catch (NoSuchKeyException e) {
            throw new IOException("File not found: " + fileName, e);
        } catch (S3Exception e) {
            throw new IOException("Failed to download file: " + e.awsErrorDetails().errorMessage(), e);
        }
    }


    public URL getFilePath(String fileName) {
        return s3Client.utilities().getUrl(GetUrlRequest.builder()
                .bucket(bucketName)
                .key(fileName)
                .build());
    }

    public InputStream getResource(String fileName) {
        return s3Client.getObject(GetObjectRequest.builder()
                .bucket(bucketName)
                .key(fileName)
                .build());
    }


    private String getFileExtension(String fileName) {
        if (fileName == null) return "";
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex >= 0) ? fileName.substring(dotIndex + 1) : "";
    }

    public String generatePresignedUrl(String objectKey) {
        GetObjectPresignRequest presignRequest = GetObjectPresignRequest.builder()
                .signatureDuration(Duration.ofHours(1)) // 1 hour expiry
                .getObjectRequest(GetObjectRequest.builder()
                        .bucket(bucketName)
                        .key(objectKey)
                        .build())
                .build();

        PresignedGetObjectRequest presignedRequest = s3Presigner.presignGetObject(presignRequest);
        return presignedRequest.url().toString();
    }

//    public String uploadFile(MultipartFile file, String folder) {
//        String key = folder + "/" + UUID.randomUUID() + "-" + file.getOriginalFilename();
//        try {
//            ObjectMetadata metadata = new ObjectMetadata();
//            metadata.setContentLength(file.getSize());
//            s3Client.putObject(bucketName, key, file.getInputStream(), metadata);
//            return s3Client.getUrl(bucketName, key).toString();
//        } catch (IOException e) {
//            throw new RuntimeException("Error uploading file to S3", e);
//        }
//    }
//
//    public void deleteProfileImage(String fileUrl) {
//        String key = fileUrl.substring(fileUrl.indexOf(bucketName) + bucketName.length() + 1);
//        amazonS3.deleteObject(bucketName, key);
//    }
    /*

    {
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::your-bucket-name/profile-pictures/*"
    }
  ]
}

     */
}