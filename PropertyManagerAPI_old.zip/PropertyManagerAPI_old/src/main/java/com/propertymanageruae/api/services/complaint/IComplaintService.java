package com.propertymanageruae.api.services.complaint;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.propertymanageruae.api.payloads.complaint.AddComplaintDTO;
import com.propertymanageruae.api.payloads.complaint.ComplaintFilterDto;
import com.propertymanageruae.api.payloads.complaint.ComplaintStatusUpdateDto;
import com.propertymanageruae.api.payloads.complaint.ViewComplaintDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface IComplaintService {
    ViewComplaintDto addComplaint(AddComplaintDTO complaintDTO, List<MultipartFile> files) throws IOException;
    void deleteComplaint(long id) throws IOException;
    List<ViewComplaintDto> getAllComplaints(ComplaintFilterDto filter, int offset, int limit,String sortBy, String sortDir,long societyId);
    ViewComplaintDto getComplaintById(long id);
    ViewComplaintDto updateComplaintStatus(Long complaintId, ComplaintStatusUpdateDto statusUpdateDTO) throws FirebaseMessagingException;
    public List<ViewComplaintDto> getAllComplaintsBySocietyAndApartment(ComplaintFilterDto filter, int offset, int limit, String sortBy, String sortDir, long societyId,long apartmentId);
}