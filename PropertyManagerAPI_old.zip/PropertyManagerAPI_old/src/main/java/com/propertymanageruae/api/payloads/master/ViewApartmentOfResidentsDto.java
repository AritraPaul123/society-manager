package com.propertymanageruae.api.payloads.master;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ViewApartmentOfResidentsDto {
    private Long id;
    private String block;
    private String flat;
    private String floor;
    private String societyName;
    private Long societyId;
    private Long apartmentId;
    private Long areaId;
    private String residentType;
}