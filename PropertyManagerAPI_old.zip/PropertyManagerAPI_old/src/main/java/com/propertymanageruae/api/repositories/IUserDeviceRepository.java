package com.propertymanageruae.api.repositories;

import com.propertymanageruae.api.entities.UserDevice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IUserDeviceRepository extends JpaRepository<UserDevice, Long> {
    Optional<UserDevice> findByFcmToken(String fcmToken);

    @Query("SELECT ud.fcmToken FROM UserDevice ud WHERE ud.user.id = :userId AND ud.active = true")
    List<String> findActiveTokensByUserId(@Param("userId") Long userId);

    Optional<UserDevice> findByUserIdAndDeviceId(long id, String deviceId);
    List<UserDevice> findByDeviceId(String deviceId);
}