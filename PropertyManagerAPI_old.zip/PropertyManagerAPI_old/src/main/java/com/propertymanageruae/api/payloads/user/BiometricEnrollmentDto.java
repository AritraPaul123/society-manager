package com.propertymanageruae.api.payloads.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BiometricEnrollmentDto {
    private String faceIdData;
    private String passcode;
    private Boolean biometricRequired;
}
